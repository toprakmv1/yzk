"use client";

import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { ADSENSE } from "@/lib/site";
import { cn } from "@/lib/cn";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

export type AdVariant = "leaderboard" | "inArticle" | "sidebar" | "mobileAnchor" | "multiplex" | "inFeed" | "rectangle";

/**
 * Her varyant için rezerve edilen alan. Yükseklik önceden ayrıldığı için
 * reklam yüklenince sayfa kaymaz (CLS ≈ 0) — bu hem Core Web Vitals hem de
 * kullanıcı deneyimi için kritiktir.
 */
type VariantCfg = {
  label: string;
  box: string;
  slot: keyof typeof ADSENSE.slots;
  format?: string;
  layout?: string;
  layoutKey?: string;
  /** Bu biçim yalnızca kendi özel birimiyle çalışır (Multiplex, In-article, In-feed). Yedek slot kullanılırsa "auto"ya düşülür. */
  special?: boolean;
  /** Sabit boyutlu birim (ör. mobil alt panel 320x100) — ekranın %30'undan fazlasını kaplamaması için duyarlı DEĞİL */
  fixed?: { w: number; h: number };
};

const VARIANTS: Record<AdVariant, VariantCfg> = {
  // Sayfa üstü / menü altı — mobilde 320x100, masaüstünde 728x90, geniş ekranda 970x250
  leaderboard: {
    label: "Sayfa üstü reklam alanı",
    box: "mx-auto w-full max-w-[970px] min-h-[100px] md:min-h-[90px] xl:min-h-[250px]",
    slot: "leaderboard",
    format: "horizontal",
  },
  // İçerik ortası — 336x280 / 300x250
  inArticle: {
    label: "İçerik içi reklam alanı",
    box: "mx-auto w-full max-w-[336px] min-h-[280px]",
    slot: "inArticle",
    format: "fluid",
    layout: "in-article",
    special: true,
  },
  // İçerik/bölüm arası dikdörtgen — 300x250 / 336x280 (duyarlı görüntülü reklam). Tek "varsayılan" slotla da çalışır.
  rectangle: {
    label: "Bölüm arası reklam alanı",
    box: "mx-auto w-full max-w-[336px] min-h-[280px]",
    slot: "rectangle",
  },
  // Liste/ızgara içi (In-feed) — kart akışına uyumlu yerel reklam
  inFeed: {
    label: "Liste içi reklam alanı",
    box: "w-full min-h-[250px]",
    slot: "inFeed",
    format: "fluid",
    layoutKey: process.env.NEXT_PUBLIC_AD_LAYOUT_KEY_INFEED || undefined,
    special: true,
  },
  // Masaüstü yapışkan kenar çubuğu — 300x600
  sidebar: {
    label: "Kenar çubuğu reklam alanı",
    box: "w-[300px] min-h-[600px]",
    slot: "sidebar",
    format: "vertical",
  },
  // Sayfa sonu "ilgili içerik" tarzı çoklu reklam (Multiplex) — yüksek sayfa RPM'i
  multiplex: {
    label: "Önerilen içerik reklam alanı",
    box: "w-full min-h-[480px] md:min-h-[320px]",
    slot: "multiplex",
    format: "autorelaxed",
    special: true,
  },
  // Mobil alt panel — 320x100
  mobileAnchor: {
    label: "Mobil reklam alanı",
    box: "mx-auto w-[320px] h-[100px]",
    slot: "mobileAnchor",
    fixed: { w: 320, h: 100 },
  },
};

export interface AdUnitProps {
  variant: AdVariant;
  className?: string;
  /** Geliştirme ortamında yer tutucu kutuyu gösterir. */
  showPlaceholder?: boolean;
}

/**
 * AdUnit — AdSense politika uyumlu reklam bileşeni.
 *
 * Politika notları (onayı riske atmamak için):
 *  - Reklamlar açıkça "Reklam" olarak etiketlenir.
 *  - Tıklamaya teşvik eden metin, ok, buton benzeri yakın öğe YOKTUR.
 *  - Reklamlar kopyala/hesapla butonlarına yapışık konumlanmaz (kazara tıklama riski).
 *  - Görünür alana yaklaşınca yüklenir (lazy) → sayfa hızı korunur.
 *  - Rota değişiminde (SPA) yeniden oluşturulur.
 */
export function AdUnit({ variant, className, showPlaceholder = process.env.NODE_ENV !== "production" }: AdUnitProps) {
  const cfg = VARIANTS[variant];
  const ownSlot = ADSENSE.slots[cfg.slot];
  // Kendi slotu yoksa varsayılan (duyarlı görüntülü) slota düş
  const slotId = ownSlot || ADSENSE.fallback;
  const usingFallback = !ownSlot && Boolean(ADSENSE.fallback);
  // In-feed birimi layout-key olmadan çalışmaz; yedek slot kullanılıyorsa standart duyarlı biçim kullanılır
  const special = cfg.special && !usingFallback && (variant !== "inFeed" || Boolean(cfg.layoutKey));
  const format = special ? cfg.format : cfg.special ? "auto" : (cfg.format ?? "auto");
  const pathname = usePathname();
  const wrapRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  // Lazy yükleme: görünür alana 300px kala başlat
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { rootMargin: "300px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [pathname]);

  useEffect(() => {
    if (!visible || !ADSENSE.client || !slotId) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      /* AdBlock veya çift push — sessizce yoksay */
    }
  }, [visible, slotId, pathname]);

  const live = Boolean(ADSENSE.client && slotId);
  if (!live && !showPlaceholder) return null;

  return (
    <aside ref={wrapRef} aria-label={cfg.label} className={cn("my-8", className)}>
      <p className="mb-1.5 text-center text-[10px] uppercase tracking-[0.2em] text-slate-500">Reklam</p>
      <div className={cn(cfg.box, "overflow-hidden rounded-xl")}>
        {live && visible ? (
          <ins
            key={pathname}
            className="adsbygoogle block"
            style={cfg.fixed ? { display: "inline-block", width: cfg.fixed.w, height: cfg.fixed.h } : { display: "block" }}
            data-ad-client={ADSENSE.client}
            data-ad-slot={slotId}
            data-ad-format={cfg.fixed ? undefined : format}
            data-ad-layout={special ? cfg.layout : undefined}
            data-ad-layout-key={special ? cfg.layoutKey : undefined}
            data-full-width-responsive={special || cfg.fixed ? undefined : "true"}
          />
        ) : live ? (
          // Canlı ama henüz görünür alana gelmedi: boş, yer ayrılmış kutu (CLS ≈ 0)
          <div className={cfg.box} />
        ) : (
          <div className={cn(cfg.box, "grid place-items-center rounded-xl border border-dashed border-white/10 bg-white/[0.02] text-xs text-slate-600")}>
            {variant} · reklam yer tutucusu
          </div>
        )}
      </div>
    </aside>
  );
}

/**
 * Masaüstü kenar çubuğu: üstte 300x250 (sabit), altında kaydırmayla birlikte gelen (sticky) 300x600.
 * Kenar çubuğu içerik boyunca uzadığı için yapışkan birim uzun sayfalarda sürekli görünür kalır (yüksek görünürlük).
 */
export function StickySidebarAd() {
  return (
    <div className="hidden xl:block">
      <AdUnit variant="rectangle" className="mb-8 mt-0" />
      <div className="sticky top-28">
        <AdUnit variant="sidebar" className="my-0" />
      </div>
    </div>
  );
}

/** Mobil alt panel reklamı — 320x100, kapatılabilir */
export function MobileAnchorAd() {
  const [closed, setClosed] = useState(false);
  // Slot kimliği yoksa üretimde boş, yapışkan bir çubuk göstermeyelim
  const live = Boolean(ADSENSE.client && (ADSENSE.slots.mobileAnchor || ADSENSE.fallback));
  if (closed || (!live && process.env.NODE_ENV === "production")) return null;
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-space-950/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl md:hidden">
      <button
        type="button"
        onClick={() => setClosed(true)}
        aria-label="Reklamı kapat"
        className="absolute -top-8 right-2 grid size-8 place-items-center rounded-t-lg border border-b-0 border-white/10 bg-space-950/90 text-slate-400"
      >
        <X className="size-4" />
      </button>
      <AdUnit variant="mobileAnchor" className="my-1" />
    </div>
  );
}

export default AdUnit;
