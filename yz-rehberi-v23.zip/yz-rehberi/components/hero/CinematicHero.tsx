"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import { SearchTrigger } from "@/components/search/SearchTrigger";
import type { Accent, CategoryKey } from "@/lib/model-meta";
import { cn } from "@/lib/cn";

type Props = {
  stats: { total: number; free: number; open: number; isNew: number; categories: number };
  categories: { key: CategoryKey; slug: string; short: string; accent: Accent }[];
};

/**
 * Sinematik 3D giriş — fare tekerleği / dokunmatik kaydırma / ok tuşları ile ilerler.
 *
 * Mimari:
 *  - Bölüm 380vh yüksekliğindedir; içindeki sahne `position: sticky` ile ekrana sabitlenir
 *  - GSAP ScrollTrigger kaydırma ilerlemesini (0–1) okur ve metin katmanlarını "scrub" eder
 *  - İlerleme three.js sahnesine aktarılır; kamera Z ekseninde sinir ağının içinden uçar
 *  - three.js + GSAP yalnızca tarayıcı boştayken dinamik import edilir (LCP'yi etkilemez)
 *  - prefers-reduced-motion veya zayıf cihazda: kısa, statik düzen (sahne yok)
 */
const roundDown = (n: number) => Math.floor(n / 10) * 10;

export function CinematicHero({ stats, categories }: Props) {
  const sectionRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<"cinematic" | "static">("cinematic");
  const [ready, setReady] = useState(false);
  const [stage, setStage] = useState(0);
  const [hint, setHint] = useState(true);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const nav = navigator as Navigator & { deviceMemory?: number; connection?: { saveData?: boolean } };
    // Zayıf cihaz / veri tasarrufu modunda 3D sahne yüklenmez
    const lowEnd = (nav.hardwareConcurrency ?? 8) < 2 || (nav.deviceMemory ?? 4) < 2 || nav.connection?.saveData === true;
    if (reduce || lowEnd) {
      setMode("static");
      return;
    }

    let disposed = false;
    let cleanup: (() => void) | undefined;
    const idle: (cb: () => void) => number = (window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number })
      .requestIdleCallback
      ? (cb) => (window as unknown as { requestIdleCallback: (cb: () => void, o?: { timeout: number }) => number }).requestIdleCallback(cb, { timeout: 1500 })
      : (cb) => window.setTimeout(cb, 250);

    idle(async () => {
      const [{ gsap }, { ScrollTrigger }, { NeuralScene }] = await Promise.all([
        import("gsap"),
        import("gsap/ScrollTrigger"),
        import("@/components/three/NeuralScene"),
      ]);
      if (disposed || !sectionRef.current || !canvasRef.current) return;
      gsap.registerPlugin(ScrollTrigger);

      const section = sectionRef.current;
      const mobile = window.matchMedia("(max-width: 767px)").matches;
      let scene: InstanceType<typeof NeuralScene> | null = null;
      try {
        scene = new NeuralScene(canvasRef.current, { mobile });
      } catch {
        // WebGL desteklenmiyor → yalnızca metin animasyonları çalışır
        scene = null;
      }
      setReady(Boolean(scene));

      /* Metin katmanları: kaydırmaya bağlı (scrub) zaman çizelgesi */
      const q = gsap.utils.selector(section);
      const tl = gsap.timeline({
        defaults: { ease: "none" },
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: "bottom bottom",
          scrub: 0.6,
          onUpdate: (self) => {
            scene?.setProgress(self.progress);
            const pr = self.progress;
            setStage(pr < 0.2 ? 0 : pr < 0.47 ? 1 : pr < 0.73 ? 2 : 3);
            setHint(pr < 0.02);
          },
        },
      });
      tl.to(q("[data-stage='0']"), { opacity: 0, y: -60, scale: 0.96, duration: 0.18 }, 0.06)
        .fromTo(q("[data-stage='1']"), { opacity: 0, y: 70 }, { opacity: 1, y: 0, duration: 0.1 }, 0.24)
        .to(q("[data-stage='1']"), { opacity: 0, y: -70, duration: 0.1 }, 0.44)
        .fromTo(q("[data-stage='2']"), { opacity: 0, y: 70 }, { opacity: 1, y: 0, duration: 0.1 }, 0.5)
        .to(q("[data-stage='2']"), { opacity: 0, y: -70, duration: 0.1 }, 0.68)
        .fromTo(q("[data-stage='3']"), { opacity: 0, y: 70, scale: 0.97 }, { opacity: 1, y: 0, scale: 1, duration: 0.12 }, 0.76)
        .to({}, { duration: 0.12 }, 0.88);

      /* Fare paralaksı */
      const onMove = (e: PointerEvent) => scene?.setPointer((e.clientX / window.innerWidth) * 2 - 1, -((e.clientY / window.innerHeight) * 2 - 1));
      window.addEventListener("pointermove", onMove, { passive: true });

      /* Yeniden boyutlandırma */
      const ro = new ResizeObserver(() => scene?.resize());
      ro.observe(canvasRef.current);

      /* Görünür değilse ya da sekme gizliyse render'ı durdur (pil + INP) */
      let inView = true;
      const io = new IntersectionObserver(([en]) => {
        inView = en.isIntersecting;
        if (inView && !document.hidden) scene?.play();
        else scene?.pause();
      });
      io.observe(section);
      const onVis = () => (document.hidden || !inView ? scene?.pause() : scene?.play());
      document.addEventListener("visibilitychange", onVis);
      scene?.play();

      cleanup = () => {
        tl.scrollTrigger?.kill();
        tl.kill();
        window.removeEventListener("pointermove", onMove);
        document.removeEventListener("visibilitychange", onVis);
        ro.disconnect();
        io.disconnect();
        scene?.dispose();
      };
    });

    return () => {
      disposed = true;
      cleanup?.();
    };
  }, []);

  const cinematic = mode === "cinematic";

  return (
    <section ref={sectionRef} aria-label="Giriş" className={cn("relative isolate", cinematic ? "h-[300vh] md:h-[380vh]" : "")}>
      <div className={cn("relative overflow-hidden", cinematic ? "sticky top-0 h-[100svh]" : "min-h-[100svh] pb-16")}>
        {/* Statik neon arka plan (3D yüklenene kadar ve yedek olarak) */}
        <div aria-hidden className="absolute inset-0 -z-10">
          <div className="absolute left-1/2 top-1/2 size-[560px] max-w-[120vw] -translate-x-1/2 -translate-y-1/2 rounded-full bg-neon-turq/20 blur-[130px]" />
          <div className="absolute left-[62%] top-[30%] size-[340px] rounded-full bg-neon-blue/15 blur-[110px]" />
          <div className="absolute bottom-[10%] left-[18%] size-[260px] rounded-full bg-neon-red/10 blur-[110px]" />
          <div className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black_25%,transparent_72%)]" />
        </div>
        {cinematic && (
          <canvas
            ref={canvasRef}
            aria-hidden
            className={cn(
              "absolute inset-0 -z-10 h-full w-full transition-opacity duration-1000",
              !ready ? "opacity-0" : stage === 0 ? "opacity-40 md:opacity-100" : "opacity-100",
            )}
          />
        )}
        <div aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-t from-space-950 to-transparent" />

        {/* ---------- AŞAMA 0: Başlık + arama (LCP öğesi; hemen görünür) ---------- */}
        <div data-stage="0" className="relative mx-auto flex h-full w-full max-w-7xl flex-col justify-center px-4 pt-20 md:px-6">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-neon-green/30 bg-neon-green/10 px-3.5 py-1.5 text-xs font-medium text-neon-green backdrop-blur-xl">
              <NeonIcon name="spark" className="size-3.5" /> Ekim 2026 güncel · {roundDown(stats.total)}+ yapay zekâ modeli
            </span>
            <h1 className="mt-6 font-display text-[2.6rem] font-bold leading-[1.05] tracking-tight text-white sm:text-6xl md:text-7xl">
              Hangi yapay zekâ <span className="text-neon-gradient">ücretsiz</span>,
              <br className="hidden sm:block" /> hangisi <span className="text-glow-red text-neon-red">en güçlü</span>?
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-slate-300">
              Video, görsel, ses, müzik ve kod için {roundDown(stats.total)}+ modeli tek yerde karşılaştırın. Ücretsiz kotalar, token limitleri ve adım adım
              kullanım rehberleri — Türkçe.
            </p>
            <SearchTrigger variant="hero" className="mt-8 max-w-xl" />
            <div className="mt-6 grid grid-cols-2 gap-3 sm:flex sm:flex-wrap">
              <Link href="/ucretsiz-yapay-zeka" className="btn-neon col-span-2 sm:col-span-1">
                <NeonIcon name="gift" className="size-4.5" /> Ücretsiz modeller
              </Link>
              <Link href="/en-guclu-yapay-zeka" className="btn-ghost px-3 sm:px-6">
                <NeonIcon name="crown" className="size-4.5 text-neon-red" /> En güçlüler
              </Link>
              <Link href="/hangi-yapay-zeka" className="btn-ghost px-3 sm:px-6">
                <NeonIcon name="compass" className="size-4.5 text-neon-turq" /> Bana uygununu bul
              </Link>
            </div>
          </div>
        </div>

        {cinematic && (
          <>
            {/* ---------- AŞAMA 1 ---------- */}
            <div data-stage="1" className="pointer-events-none absolute inset-0 flex items-center px-4 opacity-0 md:px-6">
              <div className="mx-auto w-full max-w-7xl">
                <p className="eyebrow text-neon-turq">01 · Keşfet</p>
                <h2 className="mt-3 max-w-2xl font-display text-4xl font-bold leading-tight text-white md:text-6xl">
                  {roundDown(stats.total)}+ model, <span className="text-neon-gradient">{stats.categories} kategori</span>, tek harita.
                </h2>
                <ul className="pointer-events-auto mt-8 flex max-w-2xl flex-wrap gap-2.5">
                  {categories.map((c) => (
                    <li key={c.key}>
                      <Link
                        href={`/kategori/${c.slug}`}
                        className="group flex items-center gap-2 rounded-xl border border-white/10 bg-space-900/60 py-1.5 pl-1.5 pr-3 text-sm text-slate-200 backdrop-blur-xl transition hover:border-neon-turq/50"
                      >
                        <IconTile name={c.key} accent={c.accent} size="sm" />
                        {c.short}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* ---------- AŞAMA 2 ---------- */}
            <div data-stage="2" className="pointer-events-none absolute inset-0 flex items-center px-4 opacity-0 md:px-6">
              <div className="mx-auto w-full max-w-7xl md:pl-[42%]">
                <p className="eyebrow text-neon-green">02 · Ücretsiz olanı bul</p>
                <h2 className="mt-3 font-display text-4xl font-bold leading-tight text-white md:text-6xl">
                  Para ödemeden <span className="text-glow-green text-neon-green">üretmeye</span> başlayın.
                </h2>
                <dl className="mt-8 grid max-w-xl grid-cols-3 gap-3">
                  {[
                    { v: stats.free, l: "ücretsiz erişim", c: "text-neon-green" },
                    { v: stats.open, l: "açık kaynak", c: "text-neon-turq" },
                    { v: stats.isNew, l: "yeni çıkan", c: "text-neon-red" },
                  ].map((s) => (
                    <div key={s.l} className="glass rounded-2xl p-4 text-center">
                      <dt className="text-xs text-slate-400">{s.l}</dt>
                      <dd className={cn("mt-1 font-display text-3xl font-bold md:text-4xl", s.c)}>{s.v}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>

            {/* ---------- AŞAMA 3 ---------- */}
            <div data-stage="3" className="pointer-events-none absolute inset-0 flex items-center justify-center px-4 text-center opacity-0 md:px-6">
              <div className="max-w-3xl">
                <p className="eyebrow text-neon-blue">03 · Öğren ve üret</p>
                <h2 className="mt-3 font-display text-4xl font-bold leading-tight text-white md:text-6xl">
                  Adım adım rehberlerle <span className="text-neon-gradient">dakikalar içinde</span> ustalaşın.
                </h2>
                <div className="pointer-events-auto mt-8 flex flex-wrap justify-center gap-3">
                  <Link href="/egitimler" className="btn-neon">
                    <NeonIcon name="book" className="size-4.5" /> Rehberlere başla
                  </Link>
                  <Link href="/ai-araclari" className="btn-ghost">
                    Tüm modelleri gör <NeonIcon name="arrow" className="size-4" />
                  </Link>
                </div>
              </div>
            </div>

            {/* İlerleme göstergesi */}
            <ol aria-hidden className="absolute right-4 top-1/2 hidden -translate-y-1/2 flex-col gap-3 md:flex">
              {[0, 1, 2, 3].map((i) => (
                <li key={i} className={cn("h-8 w-1 rounded-full transition-all duration-500", stage === i ? "bg-neon-turq shadow-glow-turq" : "bg-white/15")} />
              ))}
            </ol>
            <div
              aria-hidden
              className={cn(
                "absolute bottom-6 left-1/2 hidden -translate-x-1/2 md:flex flex-col items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-slate-500 transition-opacity",
                !hint && "opacity-0",
              )}
            >
              Kaydır
              <span className="h-10 w-6 rounded-full border border-white/20 p-1">
                <span className="mx-auto block h-2 w-1 animate-float rounded-full bg-neon-turq" />
              </span>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
