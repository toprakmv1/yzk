"use client";

import { useEffect, useMemo, useState } from "react";
import { AdUnit } from "@/components/ads/AdUnit";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import { normalize } from "@/lib/fuzzy";
import type { Accent, CategoryKey, ModelLite } from "@/lib/model-meta";
import { cn } from "@/lib/cn";
import { ModelCard } from "./ModelBits";

type Cat = { key: CategoryKey; short: string; accent: Accent };
type PriceFilter = "all" | "free" | "ucretsiz" | "acik-kaynak" | "ucretli";
type Sort = "power" | "new" | "az";

const PRICE_OPTIONS: { v: PriceFilter; l: string }[] = [
  { v: "all", l: "Tümü" },
  { v: "free", l: "Ücretsiz erişim" },
  { v: "ucretsiz", l: "Tamamen ücretsiz" },
  { v: "acik-kaynak", l: "Açık kaynak" },
  { v: "ucretli", l: "Ücretli" },
];

export function ModelExplorer({ models, categories, initialCategory }: { models: ModelLite[]; categories: Cat[]; initialCategory?: CategoryKey }) {
  const [cat, setCat] = useState<CategoryKey | "all">(initialCategory ?? "all");
  const [price, setPrice] = useState<PriceFilter>("all");
  const [sort, setSort] = useState<Sort>("power");
  const [trOnly, setTrOnly] = useState(false);
  const [newOnly, setNewOnly] = useState(false);
  const [q, setQ] = useState("");
  const [limit, setLimit] = useState(36);

  const list = useMemo(() => {
    const nq = normalize(q);
    const out = models.filter((m) => {
      if (m.status === "kapandi") return false;
      if (cat !== "all" && !m.categories.includes(cat)) return false;
      if (price === "free" && m.pricing === "ucretli") return false;
      if (price !== "all" && price !== "free" && m.pricing !== price) return false;
      if (trOnly && m.turkish !== "iyi") return false;
      if (newOnly && !m.isNew) return false;
      if (nq && !normalize(`${m.name} ${m.vendor} ${m.tagline} ${m.latestVersion}`).includes(nq)) return false;
      return true;
    });
    if (sort === "new") out.sort((a, b) => b.released.localeCompare(a.released) || b.power - a.power);
    else if (sort === "az") out.sort((a, b) => a.name.localeCompare(b.name, "tr"));
    else out.sort((a, b) => b.power - a.power);
    return out;
  }, [models, cat, price, sort, trOnly, newOnly, q]);

  // Filtre değişince sayfalamayı sıfırla
  useEffect(() => setLimit(36), [cat, price, sort, trOnly, newOnly, q]);

  const reset = () => {
    setCat("all");
    setPrice("all");
    setSort("power");
    setTrOnly(false);
    setNewOnly(false);
    setQ("");
  };

  return (
    <div>
      {/* Kategori çipleri */}
      <div
        role="tablist"
        aria-label="Kategori filtresi"
        className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none] md:mx-0 md:flex-wrap md:px-0"
      >
        <button role="tab" aria-selected={cat === "all"} onClick={() => setCat("all")} className={chip(cat === "all")}>
          <span className="grid size-9 place-items-center rounded-xl bg-white/5">
            <NeonIcon name="layers" className="size-4.5 text-neon-turq" />
          </span>
          Tümü
        </button>
        {categories.map((c) => (
          <button key={c.key} role="tab" aria-selected={cat === c.key} onClick={() => setCat(c.key)} className={chip(cat === c.key)}>
            <IconTile name={c.key} accent={c.accent} size="sm" />
            {c.short}
          </button>
        ))}
      </div>

      {/* Filtre çubuğu */}
      <div className="glass sticky top-[4.25rem] z-30 mt-4 flex flex-col gap-3 rounded-2xl p-3 md:top-[5.25rem] lg:flex-row lg:items-center">
        <label className="relative flex-1">
          <span className="sr-only">Modellerde ara</span>
          <NeonIcon name="search" className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            maxLength={80}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Model veya şirket ara…"
            className="h-11 w-full rounded-xl border border-white/10 bg-black/30 pl-10 pr-4 text-white outline-none placeholder:text-slate-500 focus:border-neon-turq"
          />
        </label>
        <div className="flex flex-wrap items-center gap-2">
          <select
            aria-label="Fiyat filtresi"
            value={price}
            onChange={(e) => setPrice(e.target.value as PriceFilter)}
            className="h-11 rounded-xl border border-white/10 bg-space-900 px-3 text-sm text-white"
          >
            {PRICE_OPTIONS.map((o) => (
              <option key={o.v} value={o.v}>
                {o.l}
              </option>
            ))}
          </select>
          <select
            aria-label="Sıralama"
            value={sort}
            onChange={(e) => setSort(e.target.value as Sort)}
            className="h-11 rounded-xl border border-white/10 bg-space-900 px-3 text-sm text-white"
          >
            <option value="power">En güçlü</option>
            <option value="new">En yeni</option>
            <option value="az">A → Z</option>
          </select>
          <Toggle on={trOnly} set={setTrOnly} label="Türkçesi iyi" />
          <Toggle on={newOnly} set={setNewOnly} label="Yeni" />
        </div>
      </div>

      <p className="mt-5 text-sm text-slate-400" aria-live="polite">
        <strong className="text-white">{list.length}</strong> model listeleniyor
        {(cat !== "all" || price !== "all" || trOnly || newOnly || q) && (
          <button onClick={reset} className="ml-3 text-neon-turq underline">
            Filtreleri temizle
          </button>
        )}
      </p>

      <ul className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {list.slice(0, limit).map((m, i) => (
          <li key={m.slug} className={cn(i > 0 && i % 16 === 0 && "contents")}>
            {i > 0 && i % 16 === 0 && (
              <div className="col-span-full">
                <AdUnit variant={i % 32 === 0 ? "rectangle" : "inFeed"} className="my-2" />
              </div>
            )}
            <ModelCard m={m} />
          </li>
        ))}
      </ul>
      {list.length > limit && (
        <div className="mt-8 text-center">
          <button type="button" onClick={() => setLimit((l) => l + 36)} className="btn-ghost">
            Daha fazla model göster ({list.length - limit} kaldı)
          </button>
        </div>
      )}
      {list.length === 0 && <p className="py-16 text-center text-slate-500">Bu filtrelere uygun model yok.</p>}
    </div>
  );
}

function chip(active: boolean) {
  return cn(
    "group flex shrink-0 items-center gap-2.5 rounded-2xl border py-1.5 pl-1.5 pr-4 text-sm font-semibold transition",
    active ? "border-neon-turq/60 bg-neon-turq/10 text-white shadow-glow-turq" : "border-white/10 bg-white/[0.04] text-slate-400 hover:text-white",
  );
}

function Toggle({ on, set, label }: { on: boolean; set: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={() => set(!on)}
      className={cn(
        "h-11 rounded-xl border px-3 text-sm font-medium transition",
        on ? "border-neon-green/60 bg-neon-green/10 text-neon-green" : "border-white/10 bg-white/5 text-slate-400 hover:text-white",
      )}
    >
      {on ? "✓ " : ""}
      {label}
    </button>
  );
}
