import Link from "next/link";
import { CATEGORY_BY_KEY, type Model } from "@/lib/models";
import { cn } from "@/lib/cn";
import { Monogram, NewBadge, PowerBar, PricingBadge } from "./ModelBits";

/**
 * Sıralama tablosu — sunucu bileşeni; tüm satırlar HTML'de (Google ve LLM'ler için okunabilir).
 * Mobilde yatay kaydırılabilir.
 */
export function RankTable({
  models,
  caption,
  showCategory = false,
  startRank = 1,
}: {
  models: Model[];
  caption: string;
  showCategory?: boolean;
  startRank?: number;
}) {
  return (
    <div className="glass overflow-x-auto rounded-2xl">
      <table className="w-full min-w-[760px] text-left text-sm">
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr className="border-b border-white/10 text-xs uppercase tracking-wider text-slate-500">
            <th scope="col" className="p-3 pl-4">
              #
            </th>
            <th scope="col" className="p-3">
              Model
            </th>
            {showCategory && (
              <th scope="col" className="p-3">
                Kategori
              </th>
            )}
            <th scope="col" className="p-3">
              Fiyat
            </th>
            <th scope="col" className="p-3">
              Ücretsiz kullanım
            </th>
            <th scope="col" className="p-3">
              Türkçe
            </th>
            <th scope="col" className="w-40 p-3 pr-4">
              Güç
            </th>
          </tr>
        </thead>
        <tbody>
          {models.map((m, i) => {
            const r = startRank + i;
            return (
              <tr key={m.slug} className="border-b border-white/5 transition last:border-0 hover:bg-white/[0.03]">
                <td className={cn("p-3 pl-4 font-display text-lg font-bold", r === 1 ? "text-neon-red" : r <= 3 ? "text-neon-turq" : "text-slate-500")}>{r}</td>
                <th scope="row" className="p-3 font-normal">
                  <Link href={`/ai-araclari/${m.slug}`} className="group flex items-center gap-3">
                    <Monogram slug={m.slug} name={m.name} size="sm" />
                    <span className="min-w-0">
                      <span className="flex items-center gap-2 font-semibold text-white group-hover:text-neon-turq">
                        {m.name} {m.isNew && <NewBadge />}
                      </span>
                      <span className="block text-xs text-slate-500">
                        {m.vendor} · {m.latestVersion}
                      </span>
                    </span>
                  </Link>
                </th>
                {showCategory && <td className="p-3 text-slate-300">{CATEGORY_BY_KEY[m.primaryCategory]?.short}</td>}
                <td className="p-3">
                  <PricingBadge pricing={m.pricing} />
                </td>
                <td className="max-w-[240px] p-3 text-xs leading-5 text-slate-300">
                  {m.pricing === "ucretli" ? <span className="text-slate-500">{m.paidFrom ?? "Ücretli"}</span> : m.freeQuota}
                </td>
                <td className="p-3 text-xs">
                  <span className={m.turkish === "iyi" ? "text-neon-green" : m.turkish === "orta" ? "text-neon-blue" : "text-slate-500"}>
                    {m.turkish === "iyi" ? "İyi" : m.turkish === "orta" ? "Orta" : "Zayıf"}
                  </span>
                </td>
                <td className="p-3 pr-4">
                  <PowerBar value={m.power} />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
