/**
 * Model kartları ve küçük yapı taşları — sunucu bileşenleri (JS göndermez).
 * İstemci bileşenlerinde de kullanılabilir (hook içermez).
 */
import Link from "next/link";
import type { CSSProperties, ReactNode } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { ACCENT_RGB, CATEGORY_BY_KEY, PRICING_LABEL, accentFor, formatMonth, initials, type ModelLite, type Pricing } from "@/lib/model-meta";
import { cn } from "@/lib/cn";

export function Monogram({ slug, name, size = "md" }: { slug: string; name: string; size?: "sm" | "md" | "lg" | "xl" }) {
  const rgb = ACCENT_RGB[accentFor(slug)];
  const box = { sm: "size-9 text-xs", md: "size-11 text-sm", lg: "size-14 text-lg", xl: "size-20 text-2xl" }[size];
  const style: CSSProperties = {
    borderColor: `rgb(${rgb} / 0.5)`,
    background: `radial-gradient(circle at 30% 20%, rgb(${rgb} / 0.45), rgb(${rgb} / 0.08) 70%)`,
    boxShadow: `inset 0 1px 0 rgba(255,255,255,.35), 0 8px 20px -8px rgb(${rgb} / 0.7)`,
  };
  return (
    <span aria-hidden style={style} className={cn("relative grid shrink-0 place-items-center rounded-2xl border font-display font-bold text-white", box)}>
      {initials(name)}
    </span>
  );
}

const PRICING_STYLE: Record<Pricing, string> = {
  ucretsiz: "border-neon-green/40 bg-neon-green/10 text-neon-green",
  freemium: "border-neon-turq/40 bg-neon-turq/10 text-neon-turq",
  "acik-kaynak": "border-neon-blue/40 bg-neon-blue/10 text-neon-blue",
  ucretli: "border-white/15 bg-white/5 text-slate-300",
};

export function PricingBadge({ pricing, className }: { pricing: Pricing; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-semibold", PRICING_STYLE[pricing], className)}>
      {PRICING_LABEL[pricing]}
    </span>
  );
}

export function NewBadge() {
  return (
    <span className="inline-flex items-center gap-1 rounded-md border border-neon-red/50 bg-neon-red/15 px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide text-neon-red">
      Yeni
    </span>
  );
}

export function ClosedBadge() {
  return (
    <span className="inline-flex items-center rounded-md border border-white/20 bg-white/5 px-2 py-0.5 text-[11px] font-semibold text-slate-400">
      Hizmet dışı
    </span>
  );
}

export function PowerBar({ value, className, label = true }: { value: number; className?: string; label?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className="power-bar flex-1" role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={value} aria-label="Editoryal güç puanı">
        <span style={{ width: `${value}%` }} />
      </div>
      {label && <span className="w-7 text-right font-mono text-xs text-slate-300">{value}</span>}
    </div>
  );
}

export function ModelCard({ m, showQuota = true, className }: { m: ModelLite; showQuota?: boolean; className?: string }) {
  const cat = CATEGORY_BY_KEY[m.primaryCategory];
  return (
    <Link
      href={`/ai-araclari/${m.slug}`}
      className={cn(
        "group relative flex h-full flex-col rounded-2xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl transition duration-300",
        "hover:-translate-y-1 hover:border-neon-turq/50 hover:shadow-[0_0_28px_rgba(0,245,212,0.18)]",
        className,
      )}
    >
      <div className="flex items-start gap-3">
        <Monogram slug={m.slug} name={m.name} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs text-slate-500">{m.vendor}</p>
          <h3 className="truncate font-display text-lg font-semibold text-white group-hover:text-neon-turq">{m.name}</h3>
        </div>
        {m.isNew && <NewBadge />}
      </div>
      <p className="mt-3 line-clamp-2 text-sm leading-6 text-slate-400">{m.tagline}</p>
      <div className="mt-4 flex flex-wrap items-center gap-1.5">
        {m.status === "kapandi" ? <ClosedBadge /> : <PricingBadge pricing={m.pricing} />}
        {cat && (
          <span className="chip">
            <NeonIcon name={cat.key} className="size-3.5 text-neon-blue" />
            {cat.short}
          </span>
        )}
        {m.openWeights && m.primaryCategory !== "acik-kaynak" && <span className="chip">Açık ağırlık</span>}
      </div>
      {showQuota && m.freeQuota && m.pricing !== "ucretli" && (
        <p className="mt-3 flex items-start gap-1.5 text-xs leading-5 text-slate-300">
          <NeonIcon name="gift" className="mt-0.5 size-3.5 shrink-0 text-neon-green" />
          <span className="line-clamp-2">{m.freeQuota}</span>
        </p>
      )}
      <div className="mt-auto pt-4">
        <PowerBar value={m.power} />
        <p className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
          <span className="truncate">{m.latestVersion}</span>
          <span className="shrink-0 pl-2">{formatMonth(m.released)}</span>
        </p>
      </div>
    </Link>
  );
}

/** Numaralı sıralama satırı (Top listeleri) */
export function RankRow({ m, rank, compact }: { m: ModelLite; rank: number; compact?: boolean }) {
  const medal = rank === 1 ? "text-neon-red text-glow-red" : rank === 2 ? "text-neon-turq" : rank === 3 ? "text-neon-blue" : "text-slate-500";
  return (
    <Link href={`/ai-araclari/${m.slug}`} className="group flex items-center gap-3 rounded-xl px-3 py-2.5 transition hover:bg-white/[0.06]">
      <span className={cn("w-7 shrink-0 text-center font-display text-lg font-bold", medal)}>{rank}</span>
      <Monogram slug={m.slug} name={m.name} size="sm" />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="truncate font-semibold text-white group-hover:text-neon-turq">{m.name}</span>
          {m.isNew && !compact && <NewBadge />}
        </span>
        <span className="block truncate text-xs text-slate-500">
          {m.vendor} · {CATEGORY_BY_KEY[m.primaryCategory]?.short}
        </span>
      </span>
      {!compact && <PricingBadge pricing={m.pricing} className="hidden sm:inline-flex" />}
      <PowerBar value={m.power} className="w-24 shrink-0 sm:w-32" />
    </Link>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  href,
  linkLabel,
  accent = "text-neon-turq",
  id,
}: {
  eyebrow: string;
  title: ReactNode;
  href?: string;
  linkLabel?: string;
  accent?: string;
  id?: string;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className={cn("eyebrow", accent)}>{eyebrow}</p>
        <h2 id={id} className="mt-2 font-display text-3xl font-bold text-white md:text-4xl">
          {title}
        </h2>
      </div>
      {href && (
        <Link href={href} className="inline-flex items-center gap-1.5 text-sm font-medium text-neon-turq hover:underline">
          {linkLabel ?? "Tümünü gör"} <NeonIcon name="arrow" className="size-4" />
        </Link>
      )}
    </div>
  );
}
