"use client";

import Link from "next/link";
import { useId, useState } from "react";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import type { Accent, CategoryKey, ModelLite } from "@/lib/model-meta";
import { cn } from "@/lib/cn";
import { ModelCard } from "./ModelBits";

export type TabPanel = { key: CategoryKey; slug: string; label: string; accent: Accent; models: ModelLite[]; total: number };

/**
 * Kategori sekmeli model paneli (ör. "Ücretsiz modeller": Video · Görsel · Ses …).
 * İlk sekme sunucuda HTML olarak üretilir; diğerleri tıklanınca eklenir (her kategorinin kendi sayfası zaten dizine eklenir).
 */
export function CategoryTabs({
  panels,
  hrefPrefix = "/kategori/",
  moreLabel = "Bu kategorideki tümü",
}: {
  panels: TabPanel[];
  hrefPrefix?: string;
  moreLabel?: string;
}) {
  const [active, setActive] = useState(0);
  // Yalnızca açılmış sekmeler DOM'a eklenir → ilk yüklemede küçük HTML (hızlı LCP/INP)
  const [seen, setSeen] = useState<Set<number>>(() => new Set([0]));
  const id = useId();
  const select = (i: number) => {
    setActive(i);
    setSeen((s) => (s.has(i) ? s : new Set(s).add(i)));
  };
  return (
    <div>
      <div role="tablist" aria-label="Kategoriler" className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none] md:mx-0 md:flex-wrap md:px-0">
        {panels.map((p, i) => (
          <button
            key={p.key}
            role="tab"
            id={`${id}-tab-${i}`}
            aria-selected={active === i}
            aria-controls={`${id}-panel-${i}`}
            onClick={() => select(i)}
            onKeyDown={(e) => {
              if (e.key === "ArrowRight") select((active + 1) % panels.length);
              if (e.key === "ArrowLeft") select((active - 1 + panels.length) % panels.length);
            }}
            className={cn(
              "group flex shrink-0 items-center gap-2.5 rounded-2xl border py-1.5 pl-1.5 pr-4 text-sm font-semibold transition",
              active === i
                ? "border-neon-turq/60 bg-neon-turq/10 text-white shadow-glow-turq"
                : "border-white/10 bg-white/[0.04] text-slate-400 hover:text-white",
            )}
          >
            <IconTile name={p.key} accent={p.accent} size="sm" />
            {p.label}
            <span className="rounded-md bg-black/30 px-1.5 py-0.5 font-mono text-[10px] text-slate-400">{p.total}</span>
          </button>
        ))}
      </div>
      {panels.map((p, i) => (
        <div key={p.key} role="tabpanel" id={`${id}-panel-${i}`} aria-labelledby={`${id}-tab-${i}`} hidden={active !== i} className="mt-6">
          {seen.has(i) && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {p.models.map((m) => (
                <ModelCard key={m.slug} m={m} />
              ))}
            </div>
          )}
          <Link href={`${hrefPrefix}${p.slug}`} className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-neon-turq hover:underline">
            {moreLabel}: {p.label} ({p.total}) <NeonIcon name="arrow" className="size-4" />
          </Link>
        </div>
      ))}
    </div>
  );
}
