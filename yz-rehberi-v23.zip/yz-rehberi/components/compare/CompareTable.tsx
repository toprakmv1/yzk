import Link from "next/link";
import type { ReactNode } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { Monogram, PowerBar, PricingBadge } from "@/components/models/ModelBits";
import type { CompareModel } from "@/lib/compare";
import { CATEGORY_BY_KEY, formatMonth } from "@/lib/model-meta";

export type { CompareModel };

const TR = (t: string) => (t === "iyi" ? "İyi" : t === "orta" ? "Orta" : "Zayıf");

const ROWS: { label: string; render: (m: CompareModel) => ReactNode }[] = [
  { label: "Güç puanı", render: (m) => <PowerBar value={m.power} /> },
  { label: "Fiyat modeli", render: (m) => <PricingBadge pricing={m.pricing} /> },
  { label: "Ücretsiz kullanım", render: (m) => m.freeQuota },
  { label: "Ücretsiz planda neler var?", render: (m) => <span className="text-slate-400">{m.freeTier}</span> },
  { label: "Ücretli plan", render: (m) => m.paidFrom ?? "—" },
  { label: "API / token", render: (m) => m.apiFree ?? "—" },
  { label: "Son sürüm", render: (m) => m.latestVersion },
  { label: "Güncelleme", render: (m) => formatMonth(m.released) },
  { label: "Türkçe", render: (m) => TR(m.turkish) },
  { label: "Platformlar", render: (m) => m.platforms?.join(", ") ?? "Web" },
  { label: "Açık ağırlık", render: (m) => (m.openWeights ? "Evet" : "Hayır") },
  { label: "Kategoriler", render: (m) => m.categories.map((k) => CATEGORY_BY_KEY[k]?.short).join(", ") },
  { label: "En iyi olduğu işler", render: (m) => <List items={m.bestFor} icon="check" color="text-neon-turq" /> },
  { label: "Artıları", render: (m) => <List items={m.pros} icon="check" color="text-neon-green" /> },
  { label: "Eksileri", render: (m) => <List items={m.cons} icon="x" color="text-neon-red" /> },
  { label: "Skill / entegrasyon", render: (m) => m.skills.join(", ") },
];

function List({ items, icon, color }: { items: string[]; icon: "check" | "x"; color: string }) {
  return (
    <ul className="space-y-1.5">
      {items.map((x) => (
        <li key={x} className="flex gap-1.5">
          <NeonIcon name={icon} className={`mt-1 size-3.5 shrink-0 ${color}`} />
          {x}
        </li>
      ))}
    </ul>
  );
}

export function CompareTable({ models }: { models: CompareModel[] }) {
  if (!models.length) return null;
  return (
    <div className="glass overflow-x-auto rounded-2xl">
      <table className="w-full min-w-[640px] table-fixed text-left text-sm">
        <caption className="sr-only">{models.map((m) => m.name).join(" ve ")} karşılaştırması</caption>
        <thead>
          <tr className="border-b border-white/10">
            <th scope="col" className="w-40 p-4 text-xs uppercase tracking-wider text-slate-500">
              Özellik
            </th>
            {models.map((m) => (
              <th key={m.slug} scope="col" className="p-4">
                <Link href={`/ai-araclari/${m.slug}`} className="group flex items-center gap-3">
                  <Monogram slug={m.slug} name={m.name} size="sm" />
                  <span className="min-w-0">
                    <span className="block truncate font-display text-base font-semibold text-white group-hover:text-neon-turq">{m.name}</span>
                    <span className="block truncate text-xs font-normal text-slate-500">{m.vendor}</span>
                  </span>
                </Link>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {ROWS.map((r) => (
            <tr key={r.label} className="border-b border-white/5 align-top last:border-0">
              <th scope="row" className="p-4 text-xs font-semibold uppercase tracking-wider text-slate-500">
                {r.label}
              </th>
              {models.map((m) => (
                <td key={m.slug} className="p-4 leading-6 text-slate-200">
                  {r.render(m)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Veriye dayalı kısa karar metni */
export function verdict(a: CompareModel, b: CompareModel) {
  const stronger = a.power === b.power ? null : a.power > b.power ? a : b;
  const freeA = a.pricing !== "ucretli";
  const freeB = b.pricing !== "ucretli";
  const parts: string[] = [];
  parts.push(stronger ? `Editoryal güç puanında ${stronger.name} (${stronger.power}) önde.` : `İki model güç puanında başa baş (${a.power}).`);
  if (freeA && !freeB) parts.push(`Ücretsiz kullanmak istiyorsanız ${a.name} avantajlı (${a.freeQuota}).`);
  else if (freeB && !freeA) parts.push(`Ücretsiz kullanmak istiyorsanız ${b.name} avantajlı (${b.freeQuota}).`);
  else if (freeA && freeB) parts.push(`İkisinin de ücretsiz erişimi var: ${a.name} — ${a.freeQuota}; ${b.name} — ${b.freeQuota}.`);
  if (a.turkish !== b.turkish) {
    const better = ["iyi", "orta", "zayıf"].indexOf(a.turkish) < ["iyi", "orta", "zayıf"].indexOf(b.turkish) ? a : b;
    parts.push(`Türkçe desteği ${better.name} tarafında daha iyi.`);
  }
  if (a.openWeights !== b.openWeights) parts.push(`${a.openWeights ? a.name : b.name} açık ağırlıklı olduğu için kendi bilgisayarınızda çalıştırılabilir.`);
  parts.push(
    `${a.name} özellikle ${a.bestFor[0]?.toLocaleLowerCase("tr-TR")} için, ${b.name} ise ${b.bestFor[0]?.toLocaleLowerCase("tr-TR")} için öne çıkıyor.`,
  );
  return parts.join(" ");
}
