"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import type { CompareModel } from "@/lib/compare";
import { normalize } from "@/lib/fuzzy";
import { CompareTable, verdict } from "./CompareTable";

const MAX = 3;
let cache: Promise<CompareModel[]> | null = null;
const load = () => (cache ??= fetch("/compare-data.json").then((r) => r.json()));

export function CompareTool({ defaults }: { defaults: string[] }) {
  const params = useSearchParams();
  const router = useRouter();
  const [all, setAll] = useState<CompareModel[] | null>(null);
  const [q, setQ] = useState("");
  const fromUrl = (params.get("m") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter((s) => /^[a-z0-9-]{1,60}$/.test(s))
    .slice(0, MAX);
  const [selected, setSelected] = useState<string[]>(fromUrl.length ? fromUrl : defaults);

  useEffect(() => {
    load().then(setAll);
  }, []);

  const sync = (next: string[]) => {
    setSelected(next);
    router.replace(next.length ? `/karsilastir?m=${next.join(",")}` : "/karsilastir", { scroll: false });
  };

  const chosen = useMemo(() => (all ? selected.map((s) => all.find((m) => m.slug === s)).filter((m): m is CompareModel => Boolean(m)) : []), [all, selected]);

  const suggestions = useMemo(() => {
    if (!all) return [];
    const nq = normalize(q);
    return all
      .filter((m) => m.status !== "kapandi" && !selected.includes(m.slug) && (!nq || normalize(`${m.name} ${m.vendor}`).includes(nq)))
      .slice(0, nq ? 12 : 8);
  }, [all, q, selected]);

  return (
    <div>
      <div className="glass rounded-2xl p-4 md:p-5">
        <p className="text-sm text-slate-400">En fazla {MAX} model seçin:</p>
        <ul className="mt-3 flex flex-wrap gap-2">
          {chosen.map((m) => (
            <li key={m.slug}>
              <button
                type="button"
                onClick={() => sync(selected.filter((s) => s !== m.slug))}
                className="flex items-center gap-2 rounded-xl border border-neon-turq/50 bg-neon-turq/10 px-3 py-1.5 text-sm font-medium text-white"
              >
                {m.name}
                <NeonIcon name="x" className="size-3.5 text-neon-turq" />
                <span className="sr-only">kaldır</span>
              </button>
            </li>
          ))}
        </ul>
        {selected.length < MAX && (
          <div className="mt-4">
            <label className="relative block">
              <span className="sr-only">Model ekle</span>
              <NeonIcon name="search" className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-slate-500" />
              <input
                value={q}
                maxLength={60}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Karşılaştırmaya model ekle (ör. Gemini, Kling, Suno)…"
                className="h-11 w-full rounded-xl border border-white/10 bg-black/30 pl-10 pr-4 text-white outline-none placeholder:text-slate-500 focus:border-neon-turq"
              />
            </label>
            <ul className="mt-3 flex flex-wrap gap-2">
              {suggestions.map((m) => (
                <li key={m.slug}>
                  <button
                    type="button"
                    onClick={() => {
                      sync([...selected, m.slug].slice(0, MAX));
                      setQ("");
                    }}
                    className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-slate-300 hover:border-neon-turq/50 hover:text-white"
                  >
                    + {m.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {!all && <div className="mt-6 h-96 animate-pulse rounded-2xl bg-white/[0.03]" />}
      {chosen.length >= 2 && (
        <p className="mt-6 rounded-2xl border border-neon-green/30 bg-neon-green/[0.06] p-5 leading-7 text-slate-200">
          <strong className="text-neon-green">Kısa karar: </strong>
          {verdict(chosen[0], chosen[1])}
        </p>
      )}
      <div className="mt-6">
        <CompareTable models={chosen} />
      </div>
    </div>
  );
}
