/**
 * Özel neon ikon seti (bağımlılıksız, sunucu bileşeni).
 * 24×24 çizgi ikonlar; renk `currentColor`'dan gelir. `IconTile` ile 3D neon karoya yerleştirilir.
 */
import type { CSSProperties, ReactNode, SVGProps } from "react";
import { ACCENT_RGB, type Accent, type CategoryKey } from "@/lib/model-meta";
import { cn } from "@/lib/cn";

const P: Record<string, ReactNode> = {
  sohbet: (
    <>
      <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 4v-4h0A1.5 1.5 0 0 1 4 14.5z" />
      <path d="M8 8.5h8M8 11.5h5" />
    </>
  ),
  kod: (
    <>
      <path d="m8 7-5 5 5 5M16 7l5 5-5 5" />
      <path d="m13.5 4-3 16" />
    </>
  ),
  gorsel: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="2.5" />
      <circle cx="9" cy="9.5" r="1.8" />
      <path d="m3.5 17 5-5 4 4 2.5-2.5L20.5 19" />
    </>
  ),
  video: (
    <>
      <rect x="2.5" y="5" width="14" height="14" rx="2.5" />
      <path d="m16.5 10 5-3v10l-5-3z" />
      <path d="m8 9.5 4 2.5-4 2.5z" />
    </>
  ),
  ses: (
    <>
      <path d="M3 12h1.5M7 8v8M10.5 5v14M14 9v6M17.5 6.5v11M21 12h-1" />
    </>
  ),
  muzik: (
    <>
      <path d="M9 18V6l11-2v12" />
      <circle cx="6.5" cy="18" r="2.5" />
      <circle cx="17.5" cy="16" r="2.5" />
    </>
  ),
  "3d": (
    <>
      <path d="m12 2.8 8.5 4.8v8.8L12 21.2l-8.5-4.8V7.6z" />
      <path d="m3.8 7.7 8.2 4.6 8.2-4.6M12 12.3v8.8" />
    </>
  ),
  sunum: (
    <>
      <rect x="3" y="3.5" width="18" height="12.5" rx="2" />
      <path d="M12 16v3.5M8 21h8M7 12l3-3 2.5 2 4-4.5" />
    </>
  ),
  avatar: (
    <>
      <circle cx="12" cy="8.5" r="4" />
      <path d="M4.5 20.5c1.3-3.8 4.3-5.5 7.5-5.5s6.2 1.7 7.5 5.5" />
      <path d="M17.5 3.5c1 .7 1.6 1.7 1.8 3M19.8 2c1.4 1.1 2.2 2.6 2.3 4.4" />
    </>
  ),
  arastirma: (
    <>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m15.5 15.5 5 5M8 10.5h5M10.5 8v5" />
    </>
  ),
  ajan: (
    <>
      <rect x="4" y="7" width="16" height="12" rx="3" />
      <path d="M12 3v4M9 12.5v1.5M15 12.5v1.5M2 12v3M22 12v3" />
      <circle cx="12" cy="3" r="1" />
    </>
  ),
  "acik-kaynak": (
    <>
      <circle cx="6" cy="5.5" r="2.3" />
      <circle cx="6" cy="18.5" r="2.3" />
      <circle cx="18" cy="8" r="2.3" />
      <path d="M6 7.8v8.4M18 10.3c0 4-6 3.2-11 6.3" />
    </>
  ),
  spark: (
    <path d="M12 2.5c.6 4.3 2.9 6.6 7.2 7.2-4.3.6-6.6 2.9-7.2 7.2-.6-4.3-2.9-6.6-7.2-7.2 4.3-.6 6.6-2.9 7.2-7.2ZM19 15.5c.3 1.9 1.2 2.8 3 3-1.8.3-2.7 1.2-3 3-.3-1.8-1.2-2.7-3-3 1.8-.2 2.7-1.1 3-3Z" />
  ),
  bolt: <path d="M13.5 2 4.5 13.5H12L10.5 22l9-11.5H12z" />,
  crown: (
    <>
      <path d="m3 8 4.5 4L12 5l4.5 7L21 8l-2 10H5z" />
      <path d="M5 21h14" />
    </>
  ),
  gift: (
    <>
      <rect x="3" y="8" width="18" height="4" rx="1" />
      <path d="M5 12v8.5h14V12M12 8v12.5M12 8C10.5 4 6.5 4 7 6.5S12 8 12 8Zm0 0c1.5-4 5.5-4 5-1.5S12 8 12 8Z" />
    </>
  ),
  fire: (
    <path d="M12 21.5c-4 0-7-2.8-7-6.7 0-3.2 2-5.2 3.6-7 .4 1.7 1.4 2.8 2.6 3.3C11 7 12.6 4.3 15.4 2.5c-.4 3 .8 4.8 2.3 6.6 1.3 1.6 2.3 3.3 2.3 5.7 0 3.9-3 6.7-8 6.7Z" />
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m16.5 16.5 4.5 4.5" />
    </>
  ),
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  check: <path d="m4.5 12.5 5 5 10-11" />,
  x: <path d="M6 6l12 12M18 6 6 18" />,
  star: <path d="m12 3 2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 16.8l-5.4 2.9 1.1-6.1L3.2 9.4l6.1-.8z" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5.5l3.5 2" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.5 2.6 3.7 5.6 3.7 9s-1.2 6.4-3.7 9c-2.5-2.6-3.7-5.6-3.7-9S9.5 5.6 12 3Z" />
    </>
  ),
  book: (
    <>
      <path d="M4 5.5C4 4.1 5.1 3 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z" />
      <path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20v3H6.5A2.5 2.5 0 0 1 4 20.5ZM8.5 7.5h7" />
    </>
  ),
  wand: (
    <>
      <path d="m4 20 11-11M13 7l4 4" />
      <path d="M18 2.5v3M16.5 4h3M20.5 8.5v2M19.5 9.5h2M10 3v2M9 4h2" />
    </>
  ),
  chart: (
    <>
      <path d="M3.5 20.5h17" />
      <rect x="5" y="11" width="3" height="7" rx="1" />
      <rect x="10.5" y="6" width="3" height="12" rx="1" />
      <rect x="16" y="13" width="3" height="5" rx="1" />
    </>
  ),
  calculator: (
    <>
      <rect x="5" y="2.5" width="14" height="19" rx="2.5" />
      <path d="M8 6.5h8M8.5 11h.01M12 11h.01M15.5 11h.01M8.5 14.5h.01M12 14.5h.01M15.5 14.5h.01M8.5 18h.01M12 18h3.5" />
    </>
  ),
  compare: (
    <>
      <rect x="2.5" y="4" width="8" height="16" rx="2" />
      <rect x="13.5" y="4" width="8" height="16" rx="2" />
      <path d="M5 9h3M5 12h3M16 9h3M16 12h3" />
    </>
  ),
  compass: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="m15.5 8.5-2 5-5 2 2-5z" />
    </>
  ),
  copy: (
    <>
      <rect x="8" y="8" width="13" height="13" rx="2.5" />
      <path d="M16 8V5.5A2.5 2.5 0 0 0 13.5 3h-8A2.5 2.5 0 0 0 3 5.5v8A2.5 2.5 0 0 0 5.5 16H8" />
    </>
  ),
  external: <path d="M14 4h6v6M20 4l-9 9M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10" />,
  menu: <path d="M4 7h16M4 12h16M4 17h10" />,
  play: <path d="M7 4.5v15l12.5-7.5z" />,
  pause: <path d="M7 4.5v15M17 4.5v15" />,
  token: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M8.5 9h7M12 9v7" />
    </>
  ),
  layers: (
    <>
      <path d="m12 3 9 5-9 5-9-5z" />
      <path d="m3 13 9 5 9-5" />
    </>
  ),
  shield: (
    <>
      <path d="M12 2.5 4 5.5v6c0 5 3.4 8.6 8 10 4.6-1.4 8-5 8-10v-6z" />
      <path d="m8.5 12 2.5 2.5 4.5-5" />
    </>
  ),
  cpu: (
    <>
      <rect x="6" y="6" width="12" height="12" rx="2" />
      <rect x="9.5" y="9.5" width="5" height="5" rx="1" />
      <path d="M9 2.5V6M15 2.5V6M9 18v3.5M15 18v3.5M2.5 9H6M2.5 15H6M18 9h3.5M18 15h3.5" />
    </>
  ),
  lightbulb: (
    <>
      <path d="M9 18h6M10 21.5h4M12 2.5a6.5 6.5 0 0 0-4 11.6c.7.6 1 1.4 1 2.4h6c0-1 .3-1.8 1-2.4a6.5 6.5 0 0 0-4-11.6Z" />
    </>
  ),
  warning: (
    <>
      <path d="M12 3 2 20.5h20z" />
      <path d="M12 9.5v5M12 17.5h.01" />
    </>
  ),
  plug: (
    <>
      <path d="M9 2.5v5M15 2.5v5M6 7.5h12v3a6 6 0 0 1-12 0zM12 16.5v5" />
    </>
  ),
};

export type IconName = keyof typeof P | CategoryKey;

export function NeonIcon({ name, className, ...rest }: { name: IconName } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className={cn("size-5", className)}
      {...rest}
    >
      {P[name] ?? P.spark}
    </svg>
  );
}

/** 3D görünümlü neon ikon karosu */
export function IconTile({
  name,
  accent = "turq",
  size = "md",
  className,
}: {
  name: IconName;
  accent?: Accent;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const box = size === "sm" ? "size-9" : size === "lg" ? "size-14" : "size-11";
  const icon = size === "sm" ? "size-4.5" : size === "lg" ? "size-7" : "size-5.5";
  return (
    <span className={cn("icon-tile shrink-0", box, className)} style={{ "--tile-rgb": ACCENT_RGB[accent] } as CSSProperties}>
      <NeonIcon name={name} className={icon} />
    </span>
  );
}
