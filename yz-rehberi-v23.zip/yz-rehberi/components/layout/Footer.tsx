import Link from "next/link";
import { IconTile } from "@/components/icons/NeonIcon";
import { CATEGORIES } from "@/lib/models";
import { NAV, SITE, TOOL_LINKS } from "@/lib/site";

const LEGAL = [
  { href: "/hakkimizda", label: "Hakkımızda" },
  { href: "/iletisim", label: "İletişim" },
  { href: "/gizlilik-politikasi", label: "Gizlilik Politikası" },
  { href: "/cerez-politikasi", label: "Çerez Politikası" },
  { href: "/kullanim-kosullari", label: "Kullanım Koşulları" },
  { href: "/editoryal-ilkeler", label: "Editoryal İlkeler" },
];

export function Footer() {
  return (
    <footer className="relative mt-24 border-t border-white/10 bg-space-950 pb-32 pt-16 md:pb-12">
      <div aria-hidden className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-neon-turq/60 to-transparent" />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 md:grid-cols-2 md:px-6 lg:grid-cols-5">
        <div className="lg:col-span-1">
          <Link href="/" className="flex items-center gap-2.5">
            <IconTile name="cpu" accent="turq" size="sm" />
            <span className="font-display text-xl font-bold text-white">
              YZ<span className="text-neon-gradient">Rehberi</span>
            </span>
          </Link>
          <p className="mt-4 text-sm leading-6 text-slate-400">{SITE.description}</p>
          <p className="mt-4 text-xs text-slate-500">Son veri güncellemesi: {new Date(SITE.lastReviewed).toLocaleDateString("tr-TR", { dateStyle: "long" })}</p>
        </div>
        <FooterCol
          title="Keşfet"
          links={[...NAV, { href: "/sozluk", label: "Yapay Zekâ Sözlüğü" }, { href: "/trendler", label: "Ekosistem İstatistikleri" }]}
        />
        <FooterCol title="Kategoriler" links={CATEGORIES.map((c) => ({ href: `/kategori/${c.slug}`, label: c.label }))} />
        <FooterCol title="Ücretsiz Araçlar" links={[...TOOL_LINKS]} />
        {/* AdSense onayı için yasal sayfalar ZORUNLUDUR */}
        <FooterCol title="Kurumsal" links={LEGAL} />
      </div>
      <p className="mx-auto mt-12 max-w-7xl px-4 text-xs leading-6 text-slate-500 md:px-6">
        © {new Date().getFullYear()} {SITE.name}. Model bilgileri resmi sayfalar ve güvenilir kaynaklardan derlenir; fiyat ve kotalar sık değiştiği için
        kullanmadan önce sağlayıcının sitesinden doğrulayın. Ürün adları ilgili şirketlerin ticari markalarıdır; sitemiz bu şirketlerle bağlantılı değildir.
      </p>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: readonly { href: string; label: string }[] }) {
  return (
    <div>
      <p className="mb-4 text-sm font-semibold uppercase tracking-wider text-white">{title}</p>
      <ul className="space-y-2.5">
        {links.map((l) => (
          <li key={l.href + l.label}>
            <Link href={l.href} className="text-sm text-slate-400 transition hover:text-neon-turq">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
