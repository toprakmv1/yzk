"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import { SearchTrigger } from "@/components/search/SearchTrigger";
import { CATEGORIES } from "@/lib/model-meta";
import { NAV, SITE } from "@/lib/site";
import { cn } from "@/lib/cn";

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [mega, setMega] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const barRef = useRef<HTMLDivElement>(null);
  const megaTimer = useRef<number | undefined>(undefined);

  useEffect(() => {
    setOpen(false);
    setMega(false);
  }, [pathname]);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        setScrolled(window.scrollY > 12);
        const h = document.documentElement.scrollHeight - window.innerHeight;
        if (barRef.current) barRef.current.style.transform = `scaleX(${h > 0 ? Math.min(1, window.scrollY / h) : 0})`;
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const openMega = () => {
    window.clearTimeout(megaTimer.current);
    setMega(true);
  };
  const closeMega = () => {
    megaTimer.current = window.setTimeout(() => setMega(false), 120);
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-[background-color,border-color] duration-300",
        scrolled || open || mega ? "border-b border-white/10 bg-space-950/90 backdrop-blur-xl" : "border-b border-transparent bg-transparent",
      )}
      onKeyDown={(e) => e.key === "Escape" && (setMega(false), setOpen(false))}
    >
      <a
        href="#icerik"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:rounded-lg focus:bg-neon-turq focus:px-3 focus:py-2 focus:text-black"
      >
        İçeriğe geç
      </a>
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 md:h-20 md:px-6">
        <Link href="/" className="flex shrink-0 items-center gap-2.5" aria-label={`${SITE.name} ana sayfa`}>
          <IconTile name="cpu" accent="turq" size="sm" />
          <span className="font-display text-lg font-bold tracking-tight text-white">
            YZ<span className="text-neon-gradient">Rehberi</span>
          </span>
        </Link>

        <nav aria-label="Ana menü" className="hidden items-center gap-0.5 xl:flex">
          {NAV.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/") || (item.href === "/ai-araclari" && pathname.startsWith("/kategori"));
            const isMega = "mega" in item && item.mega;
            return (
              <div key={item.href} className="relative" onMouseEnter={isMega ? openMega : undefined} onMouseLeave={isMega ? closeMega : undefined}>
                <Link
                  href={item.href}
                  aria-current={active ? "page" : undefined}
                  aria-haspopup={isMega ? "true" : undefined}
                  aria-expanded={isMega ? mega : undefined}
                  onFocus={isMega ? openMega : undefined}
                  className={cn(
                    "relative flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium transition",
                    active ? "bg-white/[0.07] text-white" : "text-slate-400 hover:text-white",
                  )}
                >
                  {item.label}
                  {isMega && (
                    <span aria-hidden className={cn("text-[10px] transition", mega && "rotate-180")}>
                      ▾
                    </span>
                  )}
                  {item.href === "/ucretsiz-yapay-zeka" && <span className="ml-1 size-1.5 rounded-full bg-neon-green shadow-glow-green" />}
                </Link>
              </div>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          <SearchTrigger variant="compact" className="hidden md:flex" />
          <SearchTrigger variant="icon" className="md:hidden" />
          <Link href="/hangi-yapay-zeka" className="btn-neon hidden h-10 px-4 py-0 text-sm 2xl:inline-flex">
            Bana uygun YZ
          </Link>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls="mobil-menu"
            aria-label={open ? "Menüyü kapat" : "Menüyü aç"}
            className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white xl:hidden"
          >
            <NeonIcon name={open ? "x" : "menu"} className="size-5" />
          </button>
        </div>
      </div>

      {/* ---------- Masaüstü mega menü ---------- */}
      {mega && (
        <div
          onMouseEnter={openMega}
          onMouseLeave={closeMega}
          className="absolute inset-x-0 top-full hidden border-b border-white/10 bg-space-950/[0.98] shadow-[0_30px_60px_-20px_rgba(0,0,0,0.8)] backdrop-blur-xl xl:block"
        >
          <div className="mx-auto grid max-w-7xl grid-cols-[1fr_280px] gap-8 px-6 py-8">
            <ul className="grid grid-cols-3 gap-2">
              {CATEGORIES.map((c) => (
                <li key={c.key}>
                  <Link href={`/kategori/${c.slug}`} className="group flex items-center gap-3 rounded-xl p-2.5 transition hover:bg-white/5">
                    <IconTile name={c.key} accent={c.accent} size="sm" />
                    <span>
                      <span className="block text-sm font-semibold text-white">{c.label}</span>
                      <span className="block text-xs text-slate-500">{c.job} için en iyiler</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
            <div className="space-y-2 border-l border-white/10 pl-8">
              {[
                { href: "/ucretsiz-yapay-zeka", icon: "gift" as const, label: "Ücretsiz modeller", accent: "green" as const },
                { href: "/en-guclu-yapay-zeka", icon: "crown" as const, label: "En güçlü modeller", accent: "red" as const },
                { href: "/yeni-yapay-zeka-modelleri", icon: "fire" as const, label: "Yeni çıkanlar", accent: "turq" as const },
                { href: "/hangi-yapay-zeka", icon: "compass" as const, label: "Bana uygun olanı bul", accent: "blue" as const },
                { href: "/araclar/token-hesaplama", icon: "token" as const, label: "Token hesaplayıcı", accent: "turq" as const },
              ].map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className="group flex items-center gap-3 rounded-xl p-2 text-sm font-medium text-slate-200 hover:bg-white/5 hover:text-white"
                >
                  <IconTile name={l.icon} accent={l.accent} size="sm" />
                  {l.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ---------- Mobil menü ---------- */}
      {open && (
        <nav id="mobil-menu" aria-label="Mobil menü" className="max-h-[calc(100svh-4rem)] overflow-y-auto border-t border-white/10 px-4 pb-6 pt-3 xl:hidden">
          <ul className="grid grid-cols-2 gap-2">
            {NAV.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="block rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100">
                  {item.label}
                </Link>
              </li>
            ))}
            <li className="col-span-2">
              <Link href="/hangi-yapay-zeka" className="btn-neon w-full text-sm">
                Bana uygun yapay zekâyı bul
              </Link>
            </li>
          </ul>
          <p className="eyebrow mb-2 mt-6 text-slate-500">Kategoriler</p>
          <ul className="grid grid-cols-2 gap-1.5">
            {CATEGORIES.map((c) => (
              <li key={c.key}>
                <Link href={`/kategori/${c.slug}`} className="flex items-center gap-2.5 rounded-xl p-2 text-sm text-slate-200 hover:bg-white/5">
                  <IconTile name={c.key} accent={c.accent} size="sm" />
                  {c.short}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}

      {/* Okuma ilerleme çubuğu */}
      <div
        aria-hidden
        ref={barRef}
        style={{ transform: "scaleX(0)" }}
        className="h-px origin-left bg-gradient-to-r from-neon-turq via-neon-blue to-neon-green"
      />
    </header>
  );
}
