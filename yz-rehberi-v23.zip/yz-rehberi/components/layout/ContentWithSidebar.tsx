import Link from "next/link";
import type { ReactNode } from "react";
import { AdUnit, StickySidebarAd } from "@/components/ads/AdUnit";

/**
 * Araç / makale sayfaları için iki sütunlu düzen:
 * sol: içerik (max ~760px okunabilir satır uzunluğu)
 * sağ: masaüstünde yapışkan 300x600 reklam
 */
export function ContentWithSidebar({ children }: { children: ReactNode }) {
  return (
    <div className="mx-auto max-w-7xl px-4 md:px-6">
      <AdUnit variant="leaderboard" className="mt-0" />
      <div className="grid gap-12 xl:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0">{children}</div>
        <StickySidebarAd />
      </div>
    </div>
  );
}

/** Basit ekmek kırıntısı navigasyonu */
export function Breadcrumbs({ items }: { items: { name: string; path: string }[] }) {
  return (
    <nav aria-label="Konum" className="mb-6 text-sm text-slate-500">
      <ol className="flex flex-wrap items-center gap-1.5">
        {items.map((it, i) => (
          <li key={it.path} className="flex items-center gap-1.5">
            {i > 0 && <span aria-hidden>/</span>}
            {i === items.length - 1 ? (
              <span aria-current="page" className="text-slate-300">
                {it.name}
              </span>
            ) : (
              <Link href={it.path} className="hover:text-neon-blue">
                {it.name}
              </Link>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
