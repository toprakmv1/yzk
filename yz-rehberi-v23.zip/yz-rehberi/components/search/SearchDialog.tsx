"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { prepare, search, type Prepared, type SearchDoc } from "@/lib/fuzzy";
import { cn } from "@/lib/cn";
import { OPEN_SEARCH_EVENT } from "./SearchTrigger";

let indexPromise: Promise<Prepared[]> | null = null;
export function loadIndex() {
  if (!indexPromise) {
    indexPromise = fetch("/search-index.json")
      .then((r) => (r.ok ? r.json() : []))
      .then((docs: SearchDoc[]) => prepare(docs))
      .catch(() => {
        indexPromise = null;
        return [];
      });
  }
  return indexPromise;
}

const SUGGESTIONS = ["ücretsiz video", "görsel oluşturma", "ChatGPT", "Claude", "seslendirme", "kod yazma", "açık kaynak", "token nedir"];

/** Ctrl/⌘ + K veya "/" ile açılan, anlık bulanık arama penceresi */
export function SearchDialog() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [index, setIndex] = useState<Prepared[] | null>(null);
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);

  const show = useCallback((query = "") => {
    setQ(query);
    setActive(0);
    setOpen(true);
    loadIndex().then(setIndex);
  }, []);

  useEffect(() => {
    const onOpen = (e: Event) => show((e as CustomEvent<{ query?: string }>).detail?.query ?? "");
    const onKey = (e: KeyboardEvent) => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target as HTMLElement)?.tagName) || (e.target as HTMLElement)?.isContentEditable;
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        show();
      } else if (e.key === "/" && !typing) {
        e.preventDefault();
        show();
      }
    };
    window.addEventListener(OPEN_SEARCH_EVENT, onOpen);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener(OPEN_SEARCH_EVENT, onOpen);
      window.removeEventListener("keydown", onKey);
    };
  }, [show]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => inputRef.current?.focus());
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  const results = useMemo(() => (index && q.trim() ? search(index, q, 24) : []), [index, q]);

  const go = (url: string) => {
    setOpen(false);
    router.push(url);
  };

  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-i="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-start justify-center bg-space-950/80 px-3 pt-[8vh] backdrop-blur-md"
      onMouseDown={(e) => e.target === e.currentTarget && setOpen(false)}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Sitede ara"
        className="w-full max-w-2xl overflow-hidden rounded-2xl border border-neon-turq/30 bg-space-900/95 shadow-glow-turq"
      >
        <div className="flex items-center gap-3 border-b border-white/10 px-4">
          <NeonIcon name="search" className="size-5 text-neon-turq" />
          <input
            ref={inputRef}
            value={q}
            maxLength={120}
            onChange={(e) => {
              setQ(e.target.value);
              setActive(0);
            }}
            onKeyDown={(e) => {
              if (e.key === "Escape") setOpen(false);
              else if (e.key === "ArrowDown") {
                e.preventDefault();
                setActive((a) => Math.min(a + 1, Math.max(results.length - 1, 0)));
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                setActive((a) => Math.max(a - 1, 0));
              } else if (e.key === "Enter") {
                if (results[active]) go(results[active].doc.u);
                else if (q.trim()) go(`/ara?q=${encodeURIComponent(q.trim())}`);
              }
            }}
            role="combobox"
            aria-expanded={results.length > 0}
            aria-controls="arama-sonuclari"
            aria-activedescendant={results[active] ? `sonuc-${active}` : undefined}
            placeholder="Model, kategori, rehber veya kavram ara…"
            className="h-14 w-full bg-transparent text-base text-white placeholder:text-slate-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="rounded-md border border-white/10 px-2 py-1 font-mono text-[10px] text-slate-400 hover:text-white"
          >
            ESC
          </button>
        </div>

        <div className="max-h-[62vh] overflow-y-auto overscroll-contain p-2">
          {!q.trim() && (
            <div className="p-3">
              <p className="mb-3 text-xs uppercase tracking-widest text-slate-500">Popüler aramalar</p>
              <div className="flex flex-wrap gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setQ(s)}
                    className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-slate-300 hover:border-neon-turq/50 hover:text-white"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          {q.trim() && !index && <p className="p-6 text-center text-sm text-slate-500">Dizin yükleniyor…</p>}
          {q.trim() && index && results.length === 0 && (
            <p className="p-6 text-center text-sm text-slate-400">
              &quot;{q}&quot; için sonuç bulunamadı. Farklı bir kelime deneyin veya{" "}
              <a className="text-neon-turq underline" href="/ai-araclari">
                tüm modellere
              </a>{" "}
              göz atın.
            </p>
          )}
          {results.length > 0 && (
            <ul id="arama-sonuclari" ref={listRef} role="listbox" className="space-y-1">
              {results.map(({ doc }, i) => (
                <li key={doc.u + i} id={`sonuc-${i}`} data-i={i} role="option" aria-selected={i === active}>
                  <a
                    href={doc.u}
                    onClick={(e) => {
                      e.preventDefault();
                      go(doc.u);
                    }}
                    onMouseEnter={() => setActive(i)}
                    className={cn(
                      "flex items-start gap-3 rounded-xl px-3 py-2.5 transition",
                      i === active ? "bg-neon-turq/10 ring-1 ring-neon-turq/40" : "hover:bg-white/5",
                    )}
                  >
                    <span className="mt-0.5 shrink-0 rounded-md border border-white/10 bg-black/30 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-neon-blue">
                      {doc.k}
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate font-medium text-white">{doc.t}</span>
                      <span className="block truncate text-sm text-slate-400">{doc.d}</span>
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="flex items-center justify-between border-t border-white/10 px-4 py-2 text-[11px] text-slate-500">
          <span>↑↓ gezin · Enter aç · Esc kapat</span>
          <span>Türkçe karakter ve yazım hatası toleranslı</span>
        </div>
      </div>
    </div>
  );
}
