"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { search, type Prepared } from "@/lib/fuzzy";
import { loadIndex } from "./SearchDialog";

export function SearchPageClient() {
  const params = useSearchParams();
  const router = useRouter();
  const initial = (params.get("q") ?? "").slice(0, 120);
  const [q, setQ] = useState(initial);
  const [index, setIndex] = useState<Prepared[] | null>(null);

  useEffect(() => {
    loadIndex().then(setIndex);
  }, []);
  useEffect(() => setQ(initial), [initial]);

  const results = useMemo(() => (index && q.trim() ? search(index, q, 50) : []), [index, q]);

  return (
    <>
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          router.replace(`/ara?q=${encodeURIComponent(q.trim())}`);
        }}
        className="glass flex items-center gap-3 rounded-2xl p-2 pl-4"
      >
        <NeonIcon name="search" className="size-5 text-neon-turq" />
        <label className="sr-only" htmlFor="ara-q">
          Arama
        </label>
        <input
          id="ara-q"
          value={q}
          maxLength={120}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Örn: ücretsiz müzik yapay zekâ"
          className="h-11 w-full bg-transparent text-white placeholder:text-slate-500 focus:outline-none"
          autoFocus
        />
        <button className="btn-neon h-11 px-5 py-0 text-sm">Ara</button>
      </form>

      <p className="mt-6 text-sm text-slate-500" aria-live="polite">
        {q.trim() ? (index ? `${results.length} sonuç` : "Yükleniyor…") : "Aramaya başlamak için yazın."}
      </p>
      <ul className="mt-4 space-y-3">
        {results.map(({ doc }) => (
          <li key={doc.u}>
            <Link href={doc.u} className="glass block rounded-2xl p-4 transition hover:border-neon-turq/50">
              <span className="text-[11px] font-medium uppercase tracking-wider text-neon-blue">{doc.k}</span>
              <span className="mt-1 block font-semibold text-white">{doc.t}</span>
              <span className="mt-1 block text-sm leading-6 text-slate-400">{doc.d}</span>
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}
