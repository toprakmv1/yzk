"use client";

import { NeonIcon } from "@/components/icons/NeonIcon";
import { cn } from "@/lib/cn";

export const OPEN_SEARCH_EVENT = "yz:open-search";

export function openSearch(query = "") {
  window.dispatchEvent(new CustomEvent(OPEN_SEARCH_EVENT, { detail: { query } }));
}

/**
 * Arama tetikleyicisi. JavaScript olmadan da çalışır: form /ara sayfasına GET ile gider.
 * JS varken anlık sonuç veren arama penceresini açar.
 */
export function SearchTrigger({ variant = "compact", className }: { variant?: "hero" | "compact" | "icon"; className?: string }) {
  if (variant === "icon") {
    return (
      <button
        type="button"
        onClick={() => openSearch()}
        aria-label="Sitede ara"
        className={cn(
          "grid size-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-200 transition hover:border-neon-turq/50 hover:text-neon-turq",
          className,
        )}
      >
        <NeonIcon name="search" className="size-5" />
      </button>
    );
  }
  if (variant === "compact") {
    return (
      <button
        type="button"
        onClick={() => openSearch()}
        className={cn(
          "flex h-10 items-center gap-2.5 rounded-xl border border-white/10 bg-white/5 pl-3 pr-2 text-sm text-slate-400 transition hover:border-neon-turq/50 hover:text-white",
          className,
        )}
      >
        <NeonIcon name="search" className="size-4 text-neon-turq" />
        <span>Model, rehber ara…</span>
        <kbd className="ml-3 rounded-md border border-white/10 bg-black/30 px-1.5 py-0.5 font-mono text-[10px] text-slate-500">Ctrl K</kbd>
      </button>
    );
  }
  return (
    <form
      action="/ara"
      method="get"
      role="search"
      onSubmit={(e) => {
        const q = new FormData(e.currentTarget).get("q");
        e.preventDefault();
        openSearch(typeof q === "string" ? q : "");
      }}
      className={cn("group relative", className)}
    >
      <div
        aria-hidden
        className="absolute -inset-px rounded-2xl bg-gradient-to-r from-neon-turq via-neon-blue to-neon-green opacity-60 blur-[2px] transition group-focus-within:opacity-100"
      />
      <label className="relative flex items-center gap-3 rounded-2xl bg-space-900/90 p-2 pl-4 backdrop-blur-xl">
        <span className="sr-only">Yapay zekâ ara</span>
        <NeonIcon name="search" className="size-5 shrink-0 text-neon-turq" />
        <input
          name="q"
          type="search"
          autoComplete="off"
          enterKeyHint="search"
          maxLength={120}
          placeholder="Örn: ücretsiz video oluşturma, Claude, token nedir…"
          onFocus={(e) => {
            if (window.matchMedia("(min-width: 768px)").matches) {
              const v = e.currentTarget.value;
              e.currentTarget.blur();
              openSearch(v);
            }
          }}
          className="h-11 w-full min-w-0 bg-transparent text-base text-white placeholder:text-slate-500 focus:outline-none"
        />
        <button type="submit" className="btn-neon h-11 shrink-0 px-5 py-0 text-sm">
          Ara
        </button>
      </label>
    </form>
  );
}
