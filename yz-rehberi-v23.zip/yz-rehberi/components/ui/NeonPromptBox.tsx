"use client";

import { useCallback, useState } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import type { Accent } from "@/lib/model-meta";
import { cn } from "@/lib/cn";
import { GlassCard } from "./GlassCard";

export interface NeonPromptBoxProps {
  id?: string;
  title: string;
  prompt: string;
  category?: string;
  tool?: string;
  description?: string;
  accent?: Accent;
  /** Uzun promptlar başlangıçta kısaltılmış gösterilir. */
  collapsible?: boolean;
  delay?: number;
}

const BADGE: Record<Accent, string> = {
  blue: "text-neon-blue border-neon-blue/40 bg-neon-blue/10",
  green: "text-neon-green border-neon-green/40 bg-neon-green/10",
  turq: "text-neon-turq border-neon-turq/40 bg-neon-turq/10",
  red: "text-neon-red border-neon-red/40 bg-neon-red/10",
};

/**
 * NeonPromptBox — "Tek Tıkla Kopyala" özellikli prompt kartı (kütüphanesiz, hafif).
 * - Clipboard API + eski tarayıcılar için textarea yedeği
 * - Ekran okuyucular için aria-live durum bildirimi
 * - [KÖŞELİ PARANTEZ] yer tutucuları vurgulanır
 */
export function NeonPromptBox({ id, title, prompt, category, tool, description, accent = "turq", collapsible = true }: NeonPromptBoxProps) {
  const [copied, setCopied] = useState(false);
  const long = collapsible && prompt.length >= 280;
  const [open, setOpen] = useState(!long);

  const copy = useCallback(async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(prompt);
      } else {
        const ta = document.createElement("textarea");
        ta.value = prompt;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
      }
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  }, [prompt]);

  const parts = prompt.split(/(\[[^\]]+\])/g);

  return (
    <div id={id} className="h-full scroll-mt-28">
      <GlassCard accent={accent} tilt={false} className="flex h-full flex-col">
        <div className="mb-4 flex flex-wrap items-center gap-2 pr-6">
          {category && <span className={cn("rounded-full border px-2.5 py-0.5 text-xs font-medium", BADGE[accent])}>{category}</span>}
          {tool && <span className="text-xs text-slate-400">{tool}</span>}
        </div>

        <h3 className="font-display text-lg font-semibold text-white">{title}</h3>
        {description && <p className="mt-1.5 line-clamp-2 text-sm leading-6 text-slate-400">{description}</p>}

        <div className="relative mt-4 flex-1">
          <pre
            className={cn(
              "overflow-hidden whitespace-pre-wrap break-words rounded-xl border border-white/10 bg-black/40 p-4 font-mono text-[13px] leading-6 text-slate-200 transition-[max-height] duration-300",
              open ? "max-h-[2000px]" : "max-h-[132px]",
            )}
          >
            {parts.map((p, i) =>
              /^\[[^\]]+\]$/.test(p) ? (
                <mark key={i} className="rounded bg-neon-green/15 px-1 text-neon-green">
                  {p}
                </mark>
              ) : (
                <span key={i}>{p}</span>
              ),
            )}
          </pre>
          {!open && <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 rounded-b-xl bg-gradient-to-t from-black/80 to-transparent" />}
        </div>

        <div className="mt-4 flex items-center justify-between gap-3">
          {long ? (
            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              aria-expanded={open}
              className="inline-flex items-center gap-1 text-sm text-slate-400 transition hover:text-white"
            >
              {open ? "Daralt" : "Tamamını gör"}
              <span aria-hidden className={cn("transition-transform", open && "rotate-180")}>
                ▾
              </span>
            </button>
          ) : (
            <span />
          )}

          <button
            type="button"
            onClick={copy}
            aria-label={`${title} promptunu kopyala`}
            className={cn(
              "inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-95",
              copied ? "bg-neon-green text-black shadow-glow-green" : "bg-gradient-to-r from-neon-turq to-neon-blue text-space-950 hover:shadow-glow-turq",
            )}
          >
            <NeonIcon name={copied ? "check" : "copy"} className="size-4" />
            {copied ? "Kopyalandı" : "Tek tıkla kopyala"}
          </button>
        </div>

        <span className="sr-only" aria-live="polite">
          {copied ? "Prompt panoya kopyalandı" : ""}
        </span>
        <NeonIcon name="spark" className="absolute right-0 top-0 size-4 text-white/20" />
      </GlassCard>
    </div>
  );
}

export default NeonPromptBox;
