import type { CSSProperties, ReactNode } from "react";
import { ACCENT_RGB, type Accent } from "@/lib/model-meta";
import { cn } from "@/lib/cn";

export interface GlassCardProps {
  children: ReactNode;
  className?: string;
  accent?: Accent;
  /** Geriye dönük uyumluluk — artık CSS ile hafif hover derinliği uygulanır */
  tilt?: boolean;
  spotlight?: boolean;
  reveal?: boolean;
  delay?: number;
  padding?: "none" | "sm" | "md" | "lg";
}

const PADDING = { none: "", sm: "p-4", md: "p-6", lg: "p-8 md:p-10" };

/**
 * GlassCard — sitenin temel yüzeyi. Sunucu bileşeni (JS göndermez).
 * Hover'da neon kenar + hafif yükselme; yalnızca transform/box-shadow animasyonu.
 */
export function GlassCard({ children, className, accent = "blue", tilt = true, padding = "md" }: GlassCardProps) {
  return (
    <div
      style={{ "--card-rgb": ACCENT_RGB[accent] } as CSSProperties}
      className={cn(
        "group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.045] backdrop-blur-xl shadow-glass",
        "transition duration-300 hover:border-[rgb(var(--card-rgb)/0.5)] hover:shadow-[0_0_24px_rgb(var(--card-rgb)/0.25)]",
        tilt && "hover:-translate-y-1",
        PADDING[padding],
        className,
      )}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 size-40 rounded-full opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100"
        style={{ background: "rgb(var(--card-rgb) / 0.25)" }}
      />
      <div aria-hidden className="pointer-events-none absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
      <div className="relative">{children}</div>
    </div>
  );
}

export default GlassCard;
