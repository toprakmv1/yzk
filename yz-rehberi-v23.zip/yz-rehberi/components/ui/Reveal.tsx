"use client";

import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import { cn } from "@/lib/cn";

/**
 * Görünür alana girince yukarı kayarak beliren sarmalayıcı.
 * Kütüphanesiz: tek bir IntersectionObserver + CSS geçişi (yalnızca transform/opacity → GPU).
 */
export function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "li";
}) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) {
      el.classList.add("is-visible");
      return;
    }
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          el.classList.add("is-visible");
          io.disconnect();
        }
      },
      { rootMargin: "0px 0px -60px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    <Tag ref={ref as any} className={cn("reveal", className)} style={{ "--reveal-delay": `${Math.round(delay * 1000)}ms` } as CSSProperties}>
      {children}
    </Tag>
  );
}

/** Sayfa başlığı (hero dışı sayfalar için) — sunucuda da çalışır, animasyon CSS ile */
export function PageHero({ eyebrow, title, subtitle, children }: { eyebrow: string; title: ReactNode; subtitle?: ReactNode; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden pb-10 pt-32 md:pt-40">
      <div aria-hidden className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
      <div aria-hidden className="absolute left-1/2 top-10 h-72 w-[42rem] max-w-full -translate-x-1/2 rounded-full bg-neon-turq/15 blur-[120px]" />
      <div aria-hidden className="absolute right-[10%] top-24 h-40 w-64 rounded-full bg-neon-blue/10 blur-[100px]" />
      <div className="relative mx-auto max-w-5xl px-4 text-center md:px-6">
        <p className="eyebrow text-neon-turq">{eyebrow}</p>
        <h1 className="mt-4 font-display text-4xl font-bold leading-tight text-white md:text-6xl">{title}</h1>
        {subtitle && <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-400">{subtitle}</p>}
        {children}
      </div>
    </section>
  );
}
