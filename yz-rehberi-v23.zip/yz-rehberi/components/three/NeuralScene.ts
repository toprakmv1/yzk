/**
 * NeuralScene — kaydırmaya bağlı sinematik 3D yapay zekâ sahnesi (vanilla three.js).
 *
 * Sahne akışı (progress 0 → 1):
 *   0.00  Neon "YZ çekirdeği" + yörünge halkaları
 *   0.10  Çekirdek açılır, halkalar portal gibi genişler, kamera içinden geçer
 *   0.30  Z ekseni boyunca uzanan sinir ağı (düğümler + bağlantılar) içinde uçuş
 *   0.60  Veri akışı tüneli hızlanır (warp), FOV genişler
 *   0.85  Sonda küresel "küresel beyin" kümesi ve kategori küreleri
 *
 * Performans:
 *   - Tüm hareketli parçacıklar GPU'da (vertex shader) hesaplanır → JS döngüsü çok hafif
 *   - Görünür alan dışında / sekme gizliyken render durur
 *   - dispose() ile tüm geometri, materyal ve WebGL bağlamı serbest bırakılır
 */
import {
  AdditiveBlending,
  BufferAttribute,
  BufferGeometry,
  Color,
  FogExp2,
  Group,
  IcosahedronGeometry,
  LineBasicMaterial,
  LineSegments,
  Mesh,
  MeshBasicMaterial,
  PerspectiveCamera,
  Points,
  Scene,
  ShaderMaterial,
  TorusGeometry,
  WebGLRenderer,
} from "three";

const PALETTE = ["#00f5d4", "#5cd6ff", "#3dff8f", "#ffffff", "#ff4566"].map((c) => new Color(c));

const smooth = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

/* ---------------------------- Shaderlar ---------------------------- */
const coreVertex = /* glsl */ `
  uniform float uTime;
  uniform float uBurst;
  varying vec3 vNormal;
  varying vec3 vView;
  varying float vDisp;
  float wave(vec3 p) {
    return sin(p.x * 3.1 + uTime * 1.2) * 0.5 + sin(p.y * 2.7 - uTime * 0.9) * 0.35 + sin(p.z * 3.7 + uTime * 1.5) * 0.25;
  }
  void main() {
    float d = wave(normal * 1.4) * (0.13 + uBurst * 0.5);
    vDisp = d;
    vec3 pos = position + normal * d;
    vec4 mv = modelViewMatrix * vec4(pos, 1.0);
    vNormal = normalize(normalMatrix * normal);
    vView = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv;
  }
`;
const coreFragment = /* glsl */ `
  uniform vec3 uTurq;
  uniform vec3 uBlue;
  uniform vec3 uGreen;
  uniform vec3 uRed;
  uniform float uTime;
  uniform float uOpacity;
  varying vec3 vNormal;
  varying vec3 vView;
  varying float vDisp;
  void main() {
    float fres = pow(1.0 - max(dot(vNormal, vView), 0.0), 2.2);
    vec3 base = mix(vec3(0.0, 0.03, 0.06), uTurq * 0.35, smoothstep(-0.15, 0.25, vDisp));
    vec3 rim = mix(uBlue, uGreen, 0.5 + 0.5 * sin(uTime * 0.6));
    float pulse = smoothstep(0.92, 1.0, sin(uTime * 1.7 + vDisp * 12.0));
    vec3 col = base + rim * fres * 1.7 + uRed * pulse * 0.35;
    gl_FragColor = vec4(col, uOpacity);
  }
`;

const pointVertex = /* glsl */ `
  attribute float aSize;
  attribute vec3 aColor;
  attribute float aSeed;
  uniform float uTime;
  uniform float uPixel;
  uniform float uSpeed;
  uniform float uLength;
  uniform float uFlow;
  uniform float uScale;
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    vec3 p = position;
    // Akış: parçacıklar kameraya doğru akar ve tünelin sonunda başa sarar
    if (uFlow > 0.5) {
      p.z = mod(p.z + uTime * uSpeed + aSeed * uLength, uLength) - uLength + 10.0;
    }
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    float tw = 0.65 + 0.35 * sin(uTime * 2.0 + aSeed * 40.0);
    gl_PointSize = aSize * uPixel * tw * (uScale / -mv.z);
    vColor = aColor;
    vAlpha = smoothstep(-120.0, -6.0, mv.z) * (1.0 - smoothstep(-1.5, 0.0, mv.z));
    gl_Position = projectionMatrix * mv;
  }
`;
const pointFragment = /* glsl */ `
  uniform float uOpacity;
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    float core = smoothstep(0.5, 0.0, d);
    float glow = pow(core, 2.2);
    gl_FragColor = vec4(vColor * (0.6 + glow), glow * vAlpha * uOpacity);
  }
`;

/* ---------------------------- Yardımcılar ---------------------------- */
function makePoints(positions: Float32Array, sizes: Float32Array, opts: { flow?: boolean; speed?: number; length?: number; pixel: number; scale?: number }) {
  const n = positions.length / 3;
  const g = new BufferGeometry();
  const colors = new Float32Array(n * 3);
  const seeds = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const c = PALETTE[Math.random() < 0.06 ? 4 : Math.floor(Math.random() * 4)];
    colors.set([c.r, c.g, c.b], i * 3);
    seeds[i] = Math.random();
  }
  g.setAttribute("position", new BufferAttribute(positions, 3));
  g.setAttribute("aSize", new BufferAttribute(sizes, 1));
  g.setAttribute("aColor", new BufferAttribute(colors, 3));
  g.setAttribute("aSeed", new BufferAttribute(seeds, 1));
  const m = new ShaderMaterial({
    vertexShader: pointVertex,
    fragmentShader: pointFragment,
    transparent: true,
    depthWrite: false,
    blending: AdditiveBlending,
    uniforms: {
      uTime: { value: 0 },
      uPixel: { value: opts.pixel },
      uSpeed: { value: opts.speed ?? 0 },
      uLength: { value: opts.length ?? 100 },
      uFlow: { value: opts.flow ? 1 : 0 },
      uOpacity: { value: 1 },
      uScale: { value: opts.scale ?? 14 },
    },
  });
  return new Points(g, m);
}

export type NeuralSceneOptions = { mobile?: boolean };

export class NeuralScene {
  private renderer: WebGLRenderer;
  private scene = new Scene();
  private camera: PerspectiveCamera;
  private core: Group;
  private coreMat: ShaderMaterial;
  private shellMat: MeshBasicMaterial;
  private rings: Group;
  private network: Points;
  private links: LineSegments;
  private stream: Points;
  private brain: Points;
  private brainLinks!: LineSegments;
  private wide = false;
  private size = { w: 1, h: 1 };
  private stars: Points;
  private raf = 0;
  private running = false;
  private start = performance.now();
  private last = performance.now();
  private target = 0;
  private progress = 0;
  private velocity = 0;
  private pointer = { x: 0, y: 0, sx: 0, sy: 0 };
  private disposables: { dispose: () => void }[] = [];

  constructor(
    private canvas: HTMLCanvasElement,
    opts: NeuralSceneOptions = {},
  ) {
    const mobile = !!opts.mobile;
    this.renderer = new WebGLRenderer({ canvas, antialias: !mobile, alpha: true, powerPreference: "high-performance" });
    const dpr = Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 1.75);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setClearColor(0x000000, 0);
    this.scene.fog = new FogExp2(0x020a14, 0.028);

    this.camera = new PerspectiveCamera(50, 1, 0.1, 220);
    this.camera.position.set(0, 0, 8);

    /* --- YZ çekirdeği --- */
    this.core = new Group();
    const coreGeo = new IcosahedronGeometry(1, mobile ? 20 : 40);
    this.coreMat = new ShaderMaterial({
      vertexShader: coreVertex,
      fragmentShader: coreFragment,
      transparent: true,
      uniforms: {
        uTime: { value: 0 },
        uBurst: { value: 0 },
        uOpacity: { value: 1 },
        uTurq: { value: PALETTE[0] },
        uBlue: { value: PALETTE[1] },
        uGreen: { value: PALETTE[2] },
        uRed: { value: PALETTE[4] },
      },
    });
    const coreMesh = new Mesh(coreGeo, this.coreMat);
    coreMesh.scale.setScalar(1.55);
    const shellGeo = new IcosahedronGeometry(1, 2);
    this.shellMat = new MeshBasicMaterial({ color: 0x5cd6ff, wireframe: true, transparent: true, opacity: 0.16 });
    const shell = new Mesh(shellGeo, this.shellMat);
    shell.scale.setScalar(2.1);
    this.core.add(coreMesh, shell);
    this.scene.add(this.core);
    this.disposables.push(coreGeo, this.coreMat, shellGeo, this.shellMat);

    /* --- Yörünge halkaları (portal) --- */
    this.rings = new Group();
    const ringDefs: [number, number, number, [number, number, number]][] = [
      [2.7, 0.014, 0x00f5d4, [Math.PI / 2.3, 0, 0]],
      [3.2, 0.011, 0x5cd6ff, [Math.PI / 1.7, 0.4, 0]],
      [3.7, 0.009, 0x3dff8f, [Math.PI / 2.8, -0.6, 0]],
      [4.3, 0.006, 0xff4566, [Math.PI / 2, 0.2, 0.3]],
    ];
    for (const [r, tube, color, rot] of ringDefs) {
      const g = new TorusGeometry(r, tube, 10, mobile ? 120 : 220);
      const m = new MeshBasicMaterial({ color, transparent: true, opacity: 1, toneMapped: false });
      const mesh = new Mesh(g, m);
      mesh.rotation.set(...rot);
      this.rings.add(mesh);
      this.disposables.push(g, m);
    }
    this.scene.add(this.rings);

    const pixel = dpr;

    /* --- Sinir ağı: Z boyunca uzanan düğümler --- */
    const nodeCount = mobile ? 150 : 320;
    const npos = new Float32Array(nodeCount * 3);
    const nsize = new Float32Array(nodeCount);
    for (let i = 0; i < nodeCount; i++) {
      const z = -4 - Math.random() * 66;
      const a = Math.random() * Math.PI * 2;
      const r = 2.2 + Math.pow(Math.random(), 0.7) * 7.5;
      npos.set([Math.cos(a) * r, Math.sin(a) * r * 0.7, z], i * 3);
      nsize[i] = 2.2 + Math.random() * 3.2;
    }
    this.network = makePoints(npos, nsize, { pixel, scale: 26 });
    this.scene.add(this.network);

    // Her düğümü en yakın 2 komşusuna bağla
    const seg: number[] = [];
    const col: number[] = [];
    for (let i = 0; i < nodeCount; i++) {
      const best: [number, number][] = [];
      for (let j = 0; j < nodeCount; j++) {
        if (i === j) continue;
        const dx = npos[i * 3] - npos[j * 3];
        const dy = npos[i * 3 + 1] - npos[j * 3 + 1];
        const dz = npos[i * 3 + 2] - npos[j * 3 + 2];
        const d = dx * dx + dy * dy + dz * dz;
        if (best.length < 2) best.push([d, j]);
        else if (d < best[1][0]) best[1] = [d, j];
        best.sort((a, b) => a[0] - b[0]);
      }
      for (const [d, j] of best) {
        if (j < i || d > 70) continue;
        seg.push(npos[i * 3], npos[i * 3 + 1], npos[i * 3 + 2], npos[j * 3], npos[j * 3 + 1], npos[j * 3 + 2]);
        const c = PALETTE[(i + j) % 3];
        col.push(c.r, c.g, c.b, c.r, c.g, c.b);
      }
    }
    const lg = new BufferGeometry();
    lg.setAttribute("position", new BufferAttribute(new Float32Array(seg), 3));
    lg.setAttribute("color", new BufferAttribute(new Float32Array(col), 3));
    const lm = new LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0, blending: AdditiveBlending, depthWrite: false });
    this.links = new LineSegments(lg, lm);
    this.scene.add(this.links);
    this.disposables.push(lg, lm);

    /* --- Veri akışı tüneli (GPU'da hareket) --- */
    const streamCount = mobile ? 700 : 1600;
    const spos = new Float32Array(streamCount * 3);
    const ssize = new Float32Array(streamCount);
    for (let i = 0; i < streamCount; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = 4 + Math.random() * 10;
      spos.set([Math.cos(a) * r, Math.sin(a) * r, -Math.random() * 110], i * 3);
      ssize[i] = 0.8 + Math.random() * 1.6;
    }
    this.stream = makePoints(spos, ssize, { flow: true, speed: 6, length: 110, pixel, scale: 18 });
    this.scene.add(this.stream);

    /* --- Final: küresel beyin (fibonacci küresi) --- */
    const brainCount = mobile ? 260 : 520;
    const bpos = new Float32Array(brainCount * 3);
    const bsize = new Float32Array(brainCount);
    const golden = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < brainCount; i++) {
      const y = 1 - (i / (brainCount - 1)) * 2;
      const rr = Math.sqrt(1 - y * y);
      const th = golden * i;
      const R = 7 + (Math.random() - 0.5) * 0.6;
      bpos.set([Math.cos(th) * rr * R, y * R, Math.sin(th) * rr * R], i * 3);
      bsize[i] = 1.6 + Math.random() * 2.4;
    }
    this.brain = makePoints(bpos, bsize, { pixel, scale: 30 });
    this.scene.add(this.brain);

    // Küre üzerindeki komşu düğümleri bağla → parlayan "küresel beyin" ağı
    const bseg: number[] = [];
    const bcol: number[] = [];
    for (let i = 0; i < brainCount; i++) {
      for (let j = i + 1; j < Math.min(brainCount, i + 40); j++) {
        const dx = bpos[i * 3] - bpos[j * 3];
        const dy = bpos[i * 3 + 1] - bpos[j * 3 + 1];
        const dz = bpos[i * 3 + 2] - bpos[j * 3 + 2];
        if (dx * dx + dy * dy + dz * dz < (mobile ? 3.2 : 1.9)) {
          bseg.push(bpos[i * 3], bpos[i * 3 + 1], bpos[i * 3 + 2], bpos[j * 3], bpos[j * 3 + 1], bpos[j * 3 + 2]);
          const c = PALETTE[(i >> 3) % 3];
          bcol.push(c.r, c.g, c.b, c.r, c.g, c.b);
        }
      }
    }
    const blg = new BufferGeometry();
    blg.setAttribute("position", new BufferAttribute(new Float32Array(bseg), 3));
    blg.setAttribute("color", new BufferAttribute(new Float32Array(bcol), 3));
    const blm = new LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0, blending: AdditiveBlending, depthWrite: false });
    this.brainLinks = new LineSegments(blg, blm);
    this.brain.add(this.brainLinks);
    this.disposables.push(blg, blm);

    /* --- Yıldız alanı --- */
    const starCount = mobile ? 900 : 2000;
    const stpos = new Float32Array(starCount * 3);
    const stsize = new Float32Array(starCount);
    for (let i = 0; i < starCount; i++) {
      const r = 60 + Math.random() * 60;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      stpos.set([r * Math.sin(ph) * Math.cos(th), r * Math.sin(ph) * Math.sin(th), r * Math.cos(ph) - 40], i * 3);
      stsize[i] = 1 + Math.random() * 1.5;
    }
    this.stars = makePoints(stpos, stsize, { pixel, scale: 40 });
    this.scene.add(this.stars);

    for (const p of [this.network, this.stream, this.brain, this.stars]) {
      this.disposables.push(p.geometry, p.material as ShaderMaterial);
    }

    this.resize();
  }

  /** Kaydırma ilerlemesi (0–1). Gerçek değer render döngüsünde yumuşatılır → "fiziksel ağırlık" hissi */
  setProgress(p: number) {
    this.target = Math.min(1, Math.max(0, p));
  }

  setPointer(x: number, y: number) {
    this.pointer.x = x;
    this.pointer.y = y;
  }

  resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.wide = w / h > 1.25 && w >= 900;
    this.size = { w, h };
    this.camera.updateProjectionMatrix();
  }

  play() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const loop = () => {
      if (!this.running) return;
      this.frame();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  pause() {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }

  /** Tek kare çiz (hareket azaltılmış modda statik görüntü için) */
  renderOnce() {
    this.frame();
  }

  private frame() {
    const now = performance.now();
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    const t = (now - this.start) / 1000;

    // Yay benzeri yumuşatma: ilerleme hedefe ataletle yaklaşır
    const prev = this.progress;
    this.progress += (this.target - this.progress) * Math.min(1, dt * 4.2);
    const p = this.progress;
    this.velocity = lerp(this.velocity, Math.abs(p - prev) / Math.max(dt, 0.001), 0.1);

    this.pointer.sx += (this.pointer.x - this.pointer.sx) * 0.05;
    this.pointer.sy += (this.pointer.y - this.pointer.sy) * 0.05;

    /* Kamera yolu */
    const e = easeInOut(p);
    const cam = this.camera;
    cam.position.z = lerp(8, -64, e);
    cam.position.x = Math.sin(p * Math.PI * 1.3) * 1.6 + this.pointer.sx * 0.8;
    cam.position.y = Math.cos(p * Math.PI) * 0.4 - 0.4 + this.pointer.sy * 0.5;
    cam.fov = 50 + smooth(0.25, 0.6, p) * 22 - smooth(0.7, 1, p) * 14 + Math.min(this.velocity * 6, 8);
    // Geniş ekranda giriş sahnesinde çekirdek sağa kayar → başlık okunur kalır; uçuş başlayınca merkeze döner
    const shift = this.wide ? (1 - smooth(0.02, 0.16, p)) * 0.24 : 0;
    if (shift > 0.001) cam.setViewOffset(this.size.w, this.size.h, -this.size.w * shift, 0, this.size.w, this.size.h);
    else cam.clearViewOffset();
    cam.updateProjectionMatrix();
    cam.lookAt(cam.position.x * 0.25, cam.position.y * 0.25, cam.position.z - 12);
    cam.rotation.z = Math.sin(p * Math.PI * 2) * 0.06;

    /* Çekirdek: açılır ve kaybolur */
    const open = smooth(0.04, 0.2, p);
    this.coreMat.uniforms.uTime.value = t;
    this.coreMat.uniforms.uBurst.value = open;
    this.coreMat.uniforms.uOpacity.value = 1 - open;
    this.shellMat.opacity = 0.16 * (1 - open);
    this.core.visible = open < 0.999;
    this.core.rotation.y += dt * (0.18 + open * 2);
    this.core.rotation.x += (this.pointer.sy * 0.3 - this.core.rotation.x) * 0.04;
    this.core.position.y = Math.sin(t * 0.9) * 0.12;
    this.core.scale.setScalar(1 + open * 0.8);

    /* Halkalar: portal gibi genişler */
    const ringOpen = smooth(0.02, 0.22, p);
    this.rings.scale.setScalar(1 + ringOpen * 5);
    this.rings.rotation.z += dt * (0.08 + ringOpen * 0.6);
    this.rings.rotation.y += (this.pointer.sx * 0.5 - this.rings.rotation.y) * 0.03;
    this.rings.children.forEach((r) => (((r as Mesh).material as MeshBasicMaterial).opacity = 1 - smooth(0.03, 0.13, p)));
    this.rings.visible = p < 0.14;

    /* Ağ + bağlantılar */
    const netIn = smooth(0.06, 0.25, p) * (1 - smooth(0.82, 0.97, p) * 0.7);
    (this.network.material as ShaderMaterial).uniforms.uTime.value = t;
    (this.network.material as ShaderMaterial).uniforms.uOpacity.value = 0.25 + netIn * 0.9;
    (this.links.material as LineBasicMaterial).opacity = netIn * 0.42;

    /* Akış: kaydırma hızıyla "warp" */
    const sm = this.stream.material as ShaderMaterial;
    sm.uniforms.uTime.value = t;
    sm.uniforms.uSpeed.value = 4 + smooth(0.3, 0.65, p) * 18 + Math.min(this.velocity * 120, 30);
    sm.uniforms.uOpacity.value = 0.35 + smooth(0.2, 0.5, p) * 0.65 - smooth(0.85, 1, p) * 0.5;

    /* Final küresi */
    const bm = this.brain.material as ShaderMaterial;
    bm.uniforms.uTime.value = t;
    bm.uniforms.uOpacity.value = smooth(0.6, 0.9, p);
    (this.brainLinks.material as LineBasicMaterial).opacity = smooth(0.7, 0.95, p) * 0.55;
    this.brain.rotation.y = t * 0.08;
    this.brain.position.set(0, 0, -80);

    (this.stars.material as ShaderMaterial).uniforms.uTime.value = t;
    this.stars.rotation.y = t * 0.005;

    this.renderer.render(this.scene, cam);
  }

  dispose() {
    this.pause();
    for (const d of this.disposables) d.dispose();
    this.renderer.dispose();
    this.renderer.forceContextLoss();
  }
}
