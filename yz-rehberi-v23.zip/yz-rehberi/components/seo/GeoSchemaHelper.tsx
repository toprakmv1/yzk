/**
 * GeoSchemaHelper — Schema.org JSON-LD üreticileri + enjeksiyon bileşeni.
 *
 * Sunucu bileşenidir (RSC): JSON-LD HTML'in ilk yanıtında gelir, böylece
 * Googlebot, Bingbot ve LLM tarayıcıları (GPTBot, ClaudeBot, PerplexityBot,
 * Google-Extended) JavaScript çalıştırmadan okuyabilir.
 *
 * Kullanım:
 *   <GeoSchema data={[
 *     articleSchema({...}),
 *     faqSchema(faqs),
 *     breadcrumbSchema([{ name: "Ana Sayfa", path: "/" }, ...]),
 *   ]} />
 */
import { SITE, absoluteUrl } from "@/lib/site";

type Json = Record<string, unknown>;

/* ------------------------------------------------------------------ */
/* Yardımcı: XSS güvenli serileştirme ("</script>" kaçışı)            */
/* ------------------------------------------------------------------ */
function safeJson(data: unknown) {
  return JSON.stringify(data)
    .replace(/</g, "\\u003c")
    .replace(/>/g, "\\u003e")
    .replace(/&/g, "\\u0026")
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
}

/* ------------------------------------------------------------------ */
/* Kuruluş & site                                                     */
/* ------------------------------------------------------------------ */
export function organizationSchema(): Json {
  return {
    "@type": "Organization",
    "@id": absoluteUrl("/#organization"),
    name: SITE.name,
    legalName: SITE.legalName,
    url: SITE.url,
    // Google logo için kare, en az 112x112 piksel raster görsel ister (SVG yerine PNG)
    logo: { "@type": "ImageObject", url: absoluteUrl("/logo.png"), width: 512, height: 512 },
    image: absoluteUrl("/opengraph-image"),
    description: SITE.description,
    email: SITE.contactEmail,
    contactPoint: { "@type": "ContactPoint", contactType: "customer support", email: SITE.contactEmail, availableLanguage: ["Turkish"] },
    // Sosyal medya profilleri (.env → NEXT_PUBLIC_SOCIAL_LINKS) — E-E-A-T sinyali
    ...(SITE.socials.length ? { sameAs: SITE.socials } : {}),
  };
}

export function websiteSchema(): Json {
  return {
    "@type": "WebSite",
    "@id": absoluteUrl("/#website"),
    url: SITE.url,
    name: SITE.name,
    description: SITE.description,
    inLanguage: "tr-TR",
    publisher: { "@id": absoluteUrl("/#organization") },
    potentialAction: {
      "@type": "SearchAction",
      target: { "@type": "EntryPoint", urlTemplate: `${SITE.url}/ara?q={search_term_string}` },
      "query-input": "required name=search_term_string",
    },
  };
}

/* ------------------------------------------------------------------ */
/* Makale                                                             */
/* ------------------------------------------------------------------ */
export interface ArticleInput {
  title: string;
  description: string;
  path: string;
  datePublished: string;
  dateModified?: string;
  image?: string;
  authorName?: string;
  authorUrl?: string;
  section?: string;
  keywords?: string[];
  /** Makalede atıf yapılan kaynak URL'leri — GEO için güçlü sinyal */
  citations?: string[];
}

export function articleSchema(a: ArticleInput): Json {
  return {
    "@type": "Article",
    "@id": absoluteUrl(`${a.path}#article`),
    headline: a.title.slice(0, 110),
    description: a.description,
    url: absoluteUrl(a.path),
    mainEntityOfPage: absoluteUrl(a.path),
    datePublished: a.datePublished,
    dateModified: a.dateModified ?? a.datePublished,
    inLanguage: "tr-TR",
    image: a.image ? absoluteUrl(a.image) : absoluteUrl("/opengraph-image"),
    articleSection: a.section,
    keywords: a.keywords?.join(", "),
    // Yazar gerçek bir kişi değilse (editör ekibi) Organization türü kullanılmalı — Google'ın önerisi
    author: a.authorName
      ? { "@type": "Person", name: a.authorName, url: absoluteUrl(a.authorUrl ?? SITE.author.url) }
      : { "@type": "Organization", name: SITE.author.name, url: absoluteUrl(SITE.author.url) },
    publisher: { "@id": absoluteUrl("/#organization") },
    citation: a.citations?.map((url) => ({ "@type": "CreativeWork", url })),
    isPartOf: { "@id": absoluteUrl("/#website") },
  };
}

/* ------------------------------------------------------------------ */
/* SSS                                                                */
/* ------------------------------------------------------------------ */
export function faqSchema(items: { q: string; a: string }[]): Json {
  return {
    "@type": "FAQPage",
    mainEntity: items.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
}

/* ------------------------------------------------------------------ */
/* Yazılım / web aracı (KDV hesaplama vb.)                            */
/* ------------------------------------------------------------------ */
export interface SoftwareInput {
  name: string;
  description: string;
  path: string;
  category?: "FinanceApplication" | "BusinessApplication" | "UtilitiesApplication" | "EducationalApplication";
  featureList?: string[];
}

export function softwareAppSchema(s: SoftwareInput): Json {
  return {
    "@type": "WebApplication",
    "@id": absoluteUrl(`${s.path}#app`),
    name: s.name,
    description: s.description,
    url: absoluteUrl(s.path),
    applicationCategory: s.category ?? "UtilitiesApplication",
    operatingSystem: "Any (web tarayıcı)",
    browserRequirements: "JavaScript gerektirir",
    inLanguage: "tr-TR",
    isAccessibleForFree: true,
    offers: { "@type": "Offer", price: "0", priceCurrency: "TRY" },
    featureList: s.featureList,
    publisher: { "@id": absoluteUrl("/#organization") },
  };
}

/** "$20/ay (Pro)" → 20 ; "$29,99/ay" → 29.99 ; ayrıştırılamazsa null */
export function parseUsdMonthly(text?: string | null): number | null {
  if (!text) return null;
  const m = text.match(/\$\s?(\d+(?:[.,]\d{1,2})?)\s*\/\s*(?:ay|kullanıcı)/i);
  if (!m) return null;
  const n = Number(m[1].replace(",", "."));
  return Number.isFinite(n) && n > 0 ? n : null;
}

/**
 * Bir YZ ürününün inceleme sayfası için (ChatGPT, Claude ...).
 * Google, SoftwareApplication için `offers` (veya puan/inceleme) ister; fiyat bilinmiyorsa şema hiç üretilmez (null)
 * — eksik alanlı şema Search Console'da "geçersiz öğe" hatasına yol açar.
 */
export function productReviewSchema(p: {
  name: string;
  vendor: string;
  description: string;
  path: string;
  /** Ücretsiz planı varsa 0 TL teklif eklenir */
  free?: boolean;
  os?: string;
  category?: string;
  version?: string;
  sameAs?: string;
  /** "$20/ay (Pro)" biçiminde ücretli plan metni */
  paidFrom?: string | null;
}): Json | null {
  const monthly = parseUsdMonthly(p.paidFrom);
  const offers: Json[] = [];
  if (p.free) offers.push({ "@type": "Offer", price: "0", priceCurrency: "USD", description: "Ücretsiz plan" });
  if (monthly)
    offers.push({
      "@type": "Offer",
      price: monthly.toFixed(2),
      priceCurrency: "USD",
      description: `Ücretli plan: ${p.paidFrom}`,
      priceSpecification: { "@type": "UnitPriceSpecification", price: monthly.toFixed(2), priceCurrency: "USD", unitCode: "MON" },
    });
  if (!offers.length) return null;
  return {
    "@type": "SoftwareApplication",
    "@id": absoluteUrl(`${p.path}#software`),
    name: p.name,
    applicationCategory: p.category ?? "BusinessApplication",
    operatingSystem: p.os ?? "Web, iOS, Android",
    description: p.description,
    url: absoluteUrl(p.path),
    softwareVersion: p.version,
    sameAs: p.sameAs,
    author: { "@type": "Organization", name: p.vendor },
    offers: offers.length === 1 ? offers[0] : offers,
  };
}

export function definedTermSetSchema(name: string, path: string, terms: { id: string; term: string; short: string }[]): Json {
  return {
    "@type": "DefinedTermSet",
    "@id": absoluteUrl(`${path}#terms`),
    name,
    url: absoluteUrl(path),
    inLanguage: "tr-TR",
    hasDefinedTerm: terms.map((t) => ({
      "@type": "DefinedTerm",
      "@id": absoluteUrl(`${path}#${t.id}`),
      name: t.term,
      description: t.short,
      inDefinedTermSet: absoluteUrl(`${path}#terms`),
    })),
  };
}

/* ------------------------------------------------------------------ */
/* HowTo, Breadcrumb, ItemList                                        */
/* ------------------------------------------------------------------ */
export function howToSchema(name: string, steps: (string | { name: string; text: string })[], totalMinutes?: number): Json {
  return {
    "@type": "HowTo",
    name,
    inLanguage: "tr-TR",
    totalTime: totalMinutes ? `PT${totalMinutes}M` : undefined,
    step: steps.map((s, i) =>
      typeof s === "string"
        ? { "@type": "HowToStep", position: i + 1, name: `Adım ${i + 1}`, text: s }
        : { "@type": "HowToStep", position: i + 1, name: s.name, text: s.text },
    ),
  };
}

export function breadcrumbSchema(items: { name: string; path: string }[]): Json {
  return {
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: absoluteUrl(it.path),
    })),
  };
}

export function itemListSchema(name: string, items: { name: string; path: string }[]): Json {
  return {
    "@type": "ItemList",
    name,
    itemListElement: items.map((it, i) => ({ "@type": "ListItem", position: i + 1, name: it.name, url: absoluteUrl(it.path) })),
  };
}

/* ------------------------------------------------------------------ */
/* Enjeksiyon bileşeni                                                */
/* ------------------------------------------------------------------ */
export function GeoSchema({ data, id }: { data: Json | (Json | null | undefined | false)[]; id?: string }) {
  const graph = (Array.isArray(data) ? data : [data]).filter(Boolean) as Json[];
  const payload = { "@context": "https://schema.org", "@graph": graph };
  return <script id={id} type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJson(payload) }} />;
}

export default GeoSchema;
