/**
 * GEO (Generative Engine Optimization) içerik blokları.
 *
 * Princeton / Georgia Tech / Allen AI "GEO" çalışması (Aggarwal ve ark., KDD 2024)
 * üretken motorlarda görünürlüğü en çok artıran yöntemler olarak şunları raporlar:
 *   1) İstatistik ekleme (Statistics Addition)
 *   2) Alıntı ekleme (Quotation Addition)
 *   3) Kaynak gösterme (Cite Sources)
 *   4) Akıcılık ve anlaşılırlık
 *
 * Bu bileşenler bu içerik türlerini hem görsel olarak hem de makine tarafından
 * okunabilir biçimde (anlamsal HTML + microdata) işaretler. Tümü sunucu bileşenidir;
 * metin ilk HTML yanıtında gelir.
 *
 * ÖNEMLİ: Etki, işaretlemeden değil içeriğin DOĞRU ve KAYNAKLI olmasından gelir.
 * Uydurma veri bu bileşenlere konulmamalıdır.
 */
import { BookOpenCheck, ExternalLink, Quote, Zap } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

/* ------------------------------------------------------------------ */
/* QuickAnswer — sayfanın en üstünde, 40-60 kelimelik doğrudan yanıt  */
/* ------------------------------------------------------------------ */
export function QuickAnswer({ question, children, updated }: { question: string; children: ReactNode; updated?: string }) {
  return (
    <section
      aria-labelledby="quick-answer"
      data-geo="quick-answer"
      className="relative overflow-hidden rounded-2xl border border-neon-green/30 bg-neon-green/[0.06] p-6 backdrop-blur-xl md:p-7"
    >
      <div aria-hidden className="absolute -left-10 -top-10 size-40 rounded-full bg-neon-green/20 blur-3xl" />
      <div className="relative">
        <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-neon-green">
          <Zap className="size-4" /> Hızlı Cevap
        </div>
        <h2 id="quick-answer" className="font-display text-lg font-semibold text-white md:text-xl">
          {question}
        </h2>
        <div className="mt-3 text-[16px] leading-7 text-slate-200">{children}</div>
        {updated && (
          <p className="mt-4 text-xs text-slate-500">
            Son kontrol: <time dateTime={updated}>{new Date(updated).toLocaleDateString("tr-TR", { dateStyle: "long" })}</time>
          </p>
        )}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* StatisticBox — kaynaklı veri noktası                               */
/* ------------------------------------------------------------------ */
export interface StatisticBoxProps {
  value: string;
  label: string;
  context?: string;
  sourceName: string;
  sourceUrl?: string;
  year?: string | number;
  accent?: "blue" | "green" | "turq";
  /** true ise "örnek veri" uyarısı gösterilir — yayından önce kaldırın */
  placeholder?: boolean;
}

const STAT_ACCENT = {
  blue: "text-neon-blue text-glow-blue",
  green: "text-neon-green text-glow-green",
  turq: "text-neon-turq text-glow-turq",
};

export function StatisticBox({ value, label, context, sourceName, sourceUrl, year, accent = "blue", placeholder }: StatisticBoxProps) {
  return (
    <figure data-geo="statistic" itemScope itemType="https://schema.org/Observation" className="glass relative my-6 rounded-2xl p-6">
      {placeholder && (
        <span className="absolute right-4 top-4 rounded-md border border-amber-400/40 bg-amber-400/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber-300">
          Örnek veri
        </span>
      )}
      <div className={cn("font-display text-4xl font-bold md:text-5xl", STAT_ACCENT[accent])} itemProp="value">
        {value}
      </div>
      <p className="mt-2 font-medium text-white" itemProp="name">
        {label}
      </p>
      {context && <p className="mt-1 text-sm leading-6 text-slate-400">{context}</p>}
      <figcaption className="mt-4 border-t border-white/10 pt-3 text-xs text-slate-500">
        Kaynak:{" "}
        {sourceUrl ? (
          <a
            href={sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-slate-300 underline decoration-white/20 underline-offset-2 hover:text-white"
          >
            {sourceName}
          </a>
        ) : (
          <span className="text-slate-300">{sourceName}</span>
        )}
        {year && <span> · {year}</span>}
      </figcaption>
    </figure>
  );
}

/* ------------------------------------------------------------------ */
/* ExpertQuote — uzman alıntısı                                       */
/* ------------------------------------------------------------------ */
export interface ExpertQuoteProps {
  quote: string;
  name: string;
  title: string;
  sourceUrl?: string;
  placeholder?: boolean;
}

export function ExpertQuote({ quote, name, title, sourceUrl, placeholder }: ExpertQuoteProps) {
  return (
    <figure data-geo="quotation" className="relative my-8 overflow-hidden rounded-2xl border border-neon-turq/30 bg-neon-turq/[0.06] p-7 backdrop-blur-xl">
      <Quote aria-hidden className="absolute -right-2 -top-2 size-24 text-neon-turq/10" />
      {placeholder && (
        <span className="mb-3 inline-block rounded-md border border-amber-400/40 bg-amber-400/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber-300">
          Yer tutucu alıntı — gerçek uzman görüşüyle değiştirin
        </span>
      )}
      <blockquote cite={sourceUrl} className="relative font-display text-xl leading-9 text-white md:text-2xl">
        “{quote}”
      </blockquote>
      <figcaption className="relative mt-5 flex items-center gap-3">
        <span aria-hidden className="grid size-10 place-items-center rounded-full bg-gradient-to-br from-neon-turq to-neon-blue font-bold text-white">
          {name.charAt(0)}
        </span>
        <span>
          <cite className="block not-italic font-semibold text-white">{name}</cite>
          <span className="text-sm text-slate-400">{title}</span>
        </span>
      </figcaption>
    </figure>
  );
}

/* ------------------------------------------------------------------ */
/* AuthoritativeCitation — birincil kaynak kartı                      */
/* ------------------------------------------------------------------ */
export interface CitationProps {
  title: string;
  publisher: string;
  url: string;
  year?: string | number;
  note?: string;
  index?: number;
}

export function AuthoritativeCitation({ title, publisher, url, year, note, index }: CitationProps) {
  return (
    <li
      data-geo="citation"
      id={index ? `kaynak-${index}` : undefined}
      itemScope
      itemType="https://schema.org/CreativeWork"
      className="glass flex gap-4 rounded-xl p-4"
    >
      <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-neon-blue/15 text-sm font-bold text-neon-blue">
        {index ?? <BookOpenCheck className="size-4" />}
      </span>
      <div className="min-w-0">
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          itemProp="url"
          className="inline-flex items-start gap-1.5 font-medium text-white hover:text-neon-blue"
        >
          <span itemProp="name" className="[overflow-wrap:anywhere]">
            {title}
          </span>
          <ExternalLink className="mt-1 size-3.5 shrink-0 opacity-60" />
        </a>
        <p className="mt-0.5 text-sm text-slate-400">
          <span itemProp="publisher">{publisher}</span>
          {year && <span> · {year}</span>}
        </p>
        {note && <p className="mt-1 text-sm text-slate-500">{note}</p>}
      </div>
    </li>
  );
}

export function CitationList({ items }: { items: Omit<CitationProps, "index">[] }) {
  return (
    <section aria-labelledby="kaynaklar" className="mt-14">
      <h2 id="kaynaklar" className="font-display text-2xl font-bold text-white">
        Kaynaklar ve Referanslar
      </h2>
      <ol className="mt-5 grid gap-3">
        {items.map((c, i) => (
          <AuthoritativeCitation key={c.url} {...c} index={i + 1} />
        ))}
      </ol>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Yazar / inceleme kutusu — E-E-A-T                                  */
/* ------------------------------------------------------------------ */
export function AuthorBox({ name, role, reviewed, bio }: { name: string; role: string; reviewed: string; bio: string }) {
  return (
    <aside className="glass mt-12 flex gap-4 rounded-2xl p-6" aria-label="Yazar bilgisi">
      <span aria-hidden className="grid size-12 shrink-0 place-items-center rounded-full bg-gradient-to-br from-neon-blue to-neon-green font-bold text-black">
        {name.charAt(0)}
      </span>
      <div>
        <p className="font-semibold text-white">{name}</p>
        <p className="text-sm text-neon-blue">{role}</p>
        <p className="mt-2 text-sm leading-6 text-slate-400">{bio}</p>
        <p className="mt-2 text-xs text-slate-500">
          Son editoryal inceleme: <time dateTime={reviewed}>{new Date(reviewed).toLocaleDateString("tr-TR", { dateStyle: "long" })}</time>
        </p>
      </div>
    </aside>
  );
}
