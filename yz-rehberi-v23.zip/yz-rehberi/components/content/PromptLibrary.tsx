"use client";

import { Fragment, useEffect, useMemo, useState } from "react";
import { AdUnit } from "@/components/ads/AdUnit";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { NeonPromptBox } from "@/components/ui/NeonPromptBox";
import type { MegaPrompt } from "@/lib/data";
import { normalize } from "@/lib/fuzzy";
import { cn } from "@/lib/cn";

const ACCENTS = ["turq", "blue", "green"] as const;
const PAGE = 24;

export function PromptLibrary({ prompts }: { prompts: MegaPrompt[] }) {
  const categories = useMemo(() => {
    const counts = new Map<string, number>();
    for (const p of prompts) counts.set(p.category, (counts.get(p.category) ?? 0) + 1);
    return [["Tümü", prompts.length] as const, ...Array.from(counts.entries()).sort((a, b) => b[1] - a[1])];
  }, [prompts]);
  const [cat, setCat] = useState("Tümü");
  const [q, setQ] = useState("");
  const [limit, setLimit] = useState(PAGE);

  // #prompt-id ile gelindiyse ilgili promptu görünür yap
  useEffect(() => {
    const hash = decodeURIComponent(window.location.hash.slice(1));
    if (!hash) return;
    const i = prompts.findIndex((p) => p.id === hash);
    if (i >= PAGE) setLimit(i + 1);
    window.setTimeout(() => document.getElementById(hash)?.scrollIntoView({ block: "start" }), 50);
  }, [prompts]);

  const filtered = useMemo(() => {
    const nq = normalize(q);
    return prompts.filter(
      (p) => (cat === "Tümü" || p.category === cat) && (!nq || normalize(`${p.title} ${p.description} ${p.tool} ${p.prompt}`).includes(nq)),
    );
  }, [prompts, cat, q]);

  return (
    <>
      <div className="glass sticky top-[4.25rem] z-30 mb-10 flex flex-col gap-4 rounded-2xl p-4 md:top-[5.25rem]">
        <label className="relative">
          <span className="sr-only">Prompt ara</span>
          <NeonIcon name="search" className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            maxLength={80}
            onChange={(e) => {
              setQ(e.target.value);
              setLimit(PAGE);
            }}
            placeholder={`${prompts.length} prompt içinde ara: banner, kod, e-posta, video…`}
            className="w-full rounded-xl border border-white/10 bg-black/40 py-3 pl-10 pr-4 text-white outline-none placeholder:text-slate-500 focus:border-neon-turq"
          />
        </label>
        <div role="tablist" aria-label="Kategoriler" className="-mx-1 flex gap-2 overflow-x-auto px-1 [scrollbar-width:none]">
          {categories.map(([c, n]) => (
            <button
              key={c}
              role="tab"
              aria-selected={cat === c}
              onClick={() => {
                setCat(c);
                setLimit(PAGE);
              }}
              className={cn(
                "shrink-0 rounded-lg px-3.5 py-2 text-sm font-medium transition",
                cat === c ? "bg-neon-turq text-space-950 shadow-glow-turq" : "bg-white/5 text-slate-400 hover:text-white",
              )}
            >
              {c} <span className="opacity-60">{n}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-5 md:grid-cols-2">
        {filtered.slice(0, limit).map((p, i) => (
          <Fragment key={p.id}>
            {/* Her 10 promptta bir, iki sütunu kaplayan liste içi reklam (kopyala butonlarına yapışık değil) */}
            {i > 0 && i % 10 === 0 && (
              <div className="md:col-span-2">
                <AdUnit variant="inFeed" className="my-2" />
              </div>
            )}
            <NeonPromptBox {...p} accent={ACCENTS[i % 3]} />
          </Fragment>
        ))}
      </div>
      {filtered.length > limit && (
        <div className="mt-8 text-center">
          <button type="button" onClick={() => setLimit((l) => l + PAGE)} className="btn-ghost">
            Daha fazla göster ({filtered.length - limit} kaldı)
          </button>
        </div>
      )}
      {filtered.length === 0 && <p className="py-16 text-center text-slate-500">Sonuç bulunamadı.</p>}
    </>
  );
}
