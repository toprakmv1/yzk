import type { ReactNode } from "react";
import { AdUnit } from "@/components/ads/AdUnit";

/**
 * SeoGuide — Araç sayfalarının altındaki "Detaylı SEO ve Kullanım Rehberi" kabuğu.
 *
 * AdSense "Düşük Değerli İçerik" reddinin asıl nedeni sitede yalnızca araç/form
 * bulunması ve özgün, kullanıcıya değer katan metnin olmamasıdır. Bu bileşen:
 *  - Otomatik içindekiler tablosu (H2 başlıklarından)
 *  - Anlamsal <article> yapısı
 *  - İçerik ortasına politika uyumlu tek bir in-article reklam
 * sağlar. İçeriğin kendisi (children) özgün ve doğru olmalıdır.
 */
export interface GuideSection {
  id: string;
  title: string;
  content: ReactNode;
}

export function SeoGuide({
  title,
  intro,
  sections,
  adAfter = 2,
}: {
  title: string;
  intro?: ReactNode;
  sections: GuideSection[];
  /** Kaçıncı bölümden sonra reklam gösterilsin */
  adAfter?: number;
}) {
  return (
    <article className="relative" aria-labelledby="rehber-baslik">
      <header className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-neon-turq">Detaylı Rehber</p>
        <h2 id="rehber-baslik" className="mt-2 font-display text-3xl font-bold text-white md:text-4xl">
          {title}
        </h2>
        {intro && <div className="mt-4 text-lg leading-8 text-slate-300">{intro}</div>}
      </header>

      <nav aria-label="İçindekiler" className="glass mb-10 rounded-2xl p-6">
        <p className="mb-3 font-semibold text-white">İçindekiler</p>
        <ol className="grid gap-1.5 text-sm sm:grid-cols-2">
          {sections.map((s, i) => (
            <li key={s.id}>
              <a href={`#${s.id}`} className="text-slate-400 transition hover:text-neon-blue">
                <span className="mr-2 font-mono text-neon-turq">{String(i + 1).padStart(2, "0")}</span>
                {s.title}
              </a>
            </li>
          ))}
        </ol>
      </nav>

      <div className="prose-neon">
        {sections.map((s, i) => (
          <section key={s.id} aria-labelledby={s.id}>
            <h2 id={s.id}>{s.title}</h2>
            {s.content}
            {i + 1 === adAfter && <AdUnit variant="inArticle" />}
          </section>
        ))}
      </div>
    </article>
  );
}
