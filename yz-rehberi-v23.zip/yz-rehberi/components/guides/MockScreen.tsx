import type { CSSProperties, ReactNode } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import type { Mock } from "@/lib/guides";
import { cn } from "@/lib/cn";

/**
 * MockScreen — rehber adımlarının "video tarzı" canlandırılmış ekran maketi.
 * Saf CSS animasyonları (globals.css → .mock-*). Bileşen `key` ile yeniden bağlandığında animasyon baştan oynar.
 * Gerçek ürün arayüzünün birebir kopyası değil; adımı anlatan sade, markasız bir temsildir.
 */
export function MockScreen({ mock, tool, step, className }: { mock: Mock; tool: string; step: number; className?: string }) {
  return (
    <figure
      className={cn(
        "overflow-hidden rounded-2xl border border-white/15 bg-space-900/90 shadow-[0_30px_80px_-30px_rgba(0,245,212,0.35)] backdrop-blur-xl",
        className,
      )}
      aria-label={`Adım ${step} ekran canlandırması: ${mock.label}`}
    >
      {/* Pencere çubuğu */}
      <div className="flex items-center gap-2 border-b border-white/10 bg-black/30 px-4 py-2.5">
        <span className="size-2.5 rounded-full bg-neon-red/80" />
        <span className="size-2.5 rounded-full bg-amber-300/80" />
        <span className="size-2.5 rounded-full bg-neon-green/80" />
        <span className="ml-3 flex min-w-0 flex-1 items-center gap-2 truncate rounded-md bg-white/5 px-3 py-1 font-mono text-[11px] text-slate-400">
          <NeonIcon name="shield" className="size-3 shrink-0 text-neon-green" />
          <span className="truncate">{mock.label}</span>
        </span>
        <span className="hidden rounded-md bg-neon-turq/10 px-2 py-0.5 text-[10px] font-semibold text-neon-turq sm:inline">Adım {step}</span>
      </div>
      <div className="relative min-h-[340px] p-5 text-sm">
        <Body mock={mock} tool={tool} />
      </div>
      <figcaption className="sr-only">{mock.label}</figcaption>
    </figure>
  );
}

const d = (ms: number) => ({ "--d": `${ms}ms` }) as CSSProperties;

function Bubble({ who, children, delay }: { who: "user" | "ai"; children: ReactNode; delay: number }) {
  return (
    <div className={cn("mock-in flex", who === "user" ? "justify-end" : "justify-start")} style={d(delay)}>
      <div
        className={cn(
          "max-w-[85%] rounded-2xl px-4 py-2.5 leading-6",
          who === "user"
            ? "rounded-br-md bg-neon-turq/15 text-white ring-1 ring-neon-turq/30"
            : "rounded-bl-md bg-white/[0.06] text-slate-200 ring-1 ring-white/10",
        )}
      >
        {who === "ai" && (
          <span className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold text-neon-blue">
            <NeonIcon name="spark" className="size-3" /> Yanıt
          </span>
        )}
        <span className="line-clamp-5">{children}</span>
      </div>
    </div>
  );
}

function Thinking({ delay }: { delay: number }) {
  return (
    <div className="mock-in flex gap-1.5 pl-2" style={d(delay)} aria-hidden>
      {[0, 1, 2].map((i) => (
        <span key={i} className="size-1.5 animate-pulse-glow rounded-full bg-neon-blue" style={{ animationDelay: `${i * 150}ms` }} />
      ))}
    </div>
  );
}

function Composer({ text, delay = 0 }: { text?: string; delay?: number }) {
  return (
    <div className="mock-in absolute inset-x-5 bottom-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-black/40 px-4 py-3" style={d(delay)}>
      <NeonIcon name="spark" className="size-4 shrink-0 text-slate-500" />
      <span className="min-w-0 flex-1 truncate text-slate-300">
        {text ? (
          <>
            <span className="mock-type max-w-full" style={d(delay + 150)}>
              {text}
            </span>
            <span className="mock-caret" />
          </>
        ) : (
          <span className="text-slate-500">Mesaj yazın…</span>
        )}
      </span>
      <span className="grid size-8 shrink-0 place-items-center rounded-full bg-neon-turq text-space-950">
        <NeonIcon name="arrow" className="size-4 -rotate-90" />
      </span>
    </div>
  );
}

function Cursor() {
  return (
    <svg
      aria-hidden
      viewBox="0 0 24 24"
      className="pointer-events-none absolute z-10 size-6 drop-shadow-[0_0_6px_rgba(0,245,212,0.9)]"
      style={{ animation: "mock-cursor 1s cubic-bezier(.22,1,.36,1) both", animationDelay: "250ms" }}
    >
      <path d="M4 3l7 17 2.5-7L21 10.5z" fill="#fff" stroke="#00f5d4" strokeWidth="1.2" />
    </svg>
  );
}

function Body({ mock, tool }: { mock: Mock; tool: string }) {
  const items = mock.items ?? [];
  switch (mock.kind) {
    case "browser":
      return (
        <div className="flex min-h-[300px] flex-col items-center justify-center text-center">
          <div
            className="mock-in grid size-14 place-items-center rounded-2xl bg-gradient-to-br from-neon-turq/40 to-neon-blue/20 font-display text-xl font-bold text-white ring-1 ring-neon-turq/40"
            style={d(0)}
          >
            {tool.slice(0, 2)}
          </div>
          <p className="mock-in mt-3 font-display text-lg font-semibold text-white" style={d(120)}>
            {tool}
          </p>
          <ul className="mt-5 w-full max-w-xs space-y-2.5">
            {items.map((it, i) => (
              <li key={it} className="mock-in relative" style={d(260 + i * 120)}>
                <span
                  className={cn(
                    "block rounded-xl border px-4 py-2.5 text-left",
                    i === 0 ? "mock-click border-neon-turq/60 bg-neon-turq/10 text-white" : "border-white/10 bg-white/[0.04] text-slate-300",
                  )}
                  style={i === 0 ? d(1300) : undefined}
                >
                  {it}
                </span>
                {i === 0 && (
                  <span className="absolute right-6 top-3">
                    <Cursor />
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      );
    case "settings":
      return (
        <div className="grid min-h-[300px] grid-cols-[150px_1fr] gap-4">
          <ul className="space-y-1.5 border-r border-white/10 pr-3">
            {items.map((it, i) => (
              <li
                key={it}
                className={cn(
                  "mock-in truncate rounded-lg px-3 py-2 text-xs",
                  i === items.length - 1 || i === 0 ? "" : "",
                  i === Math.min(1, items.length - 1) ? "bg-neon-turq/15 text-white ring-1 ring-neon-turq/40" : "text-slate-400",
                )}
                style={d(i * 90)}
              >
                {it}
              </li>
            ))}
          </ul>
          <div className="space-y-3">
            <p className="mock-in text-xs uppercase tracking-widest text-slate-500" style={d(200)}>
              {items[Math.min(1, items.length - 1)] ?? "Ayarlar"}
            </p>
            {[0, 1, 2].map((i) => (
              <div key={i} className="mock-in flex items-center justify-between rounded-xl bg-white/[0.04] px-3 py-3" style={d(350 + i * 140)}>
                <span className="h-2 rounded bg-white/15" style={{ width: `${55 - i * 10}%` }} />
                <span className={cn("relative h-5 w-9 rounded-full transition", i === 0 ? "bg-neon-turq/70" : "bg-white/15")}>
                  <span className={cn("absolute top-0.5 size-4 rounded-full bg-white", i === 0 ? "right-0.5" : "left-0.5")} />
                </span>
              </div>
            ))}
            {mock.ai && (
              <p className="mock-in rounded-xl border border-neon-blue/30 bg-neon-blue/[0.06] p-3 text-xs leading-5 text-slate-300" style={d(900)}>
                {mock.ai}
              </p>
            )}
          </div>
        </div>
      );
    case "upload":
      return (
        <div className="min-h-[300px] space-y-3 pb-16">
          <div className="mock-in flex items-center gap-3 rounded-xl border border-dashed border-neon-turq/50 bg-neon-turq/[0.06] p-3" style={d(0)}>
            <span className="grid size-9 place-items-center rounded-lg bg-neon-turq/20 text-neon-turq">
              <NeonIcon name="layers" className="size-4.5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-xs text-white">{(mock.user ?? "dosya.pdf").split(/[—-]/)[0].trim()}</span>
              <span className="mt-1.5 block h-1 overflow-hidden rounded bg-white/10">
                <span className="block h-full bg-neon-turq" style={{ animation: "mock-progress 1.2s ease-out both", animationDelay: "200ms" }} />
              </span>
            </span>
          </div>
          {items.length > 0 && (
            <div className="mock-in flex flex-wrap gap-2" style={d(300)}>
              {items.map((it) => (
                <span key={it} className="rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1 text-xs text-slate-300">
                  {it}
                </span>
              ))}
            </div>
          )}
          {mock.user && (
            <Bubble who="user" delay={1300}>
              {mock.user}
            </Bubble>
          )}
          <Thinking delay={1700} />
          {mock.ai && (
            <Bubble who="ai" delay={2300}>
              {mock.ai}
            </Bubble>
          )}
        </div>
      );
    case "voice":
      return (
        <div className="flex min-h-[300px] flex-col items-center gap-4">
          <div className="relative mt-2 grid size-24 place-items-center">
            <span className="absolute inset-0 rounded-full bg-neon-turq/30" style={{ animation: "mock-pulse-ring 1.8s ease-out infinite" }} />
            <span
              className="absolute inset-0 rounded-full bg-neon-blue/20"
              style={{ animation: "mock-pulse-ring 1.8s ease-out infinite", animationDelay: "0.6s" }}
            />
            <span className="relative grid size-20 place-items-center rounded-full bg-gradient-to-br from-neon-turq to-neon-blue text-space-950">
              <NeonIcon name="ses" className="size-8" />
            </span>
          </div>
          <div className="flex h-10 items-center gap-1" aria-hidden>
            {Array.from({ length: 24 }).map((_, i) => (
              <span
                key={i}
                className="w-1 rounded-full bg-neon-turq/80"
                style={{ height: `${30 + ((i * 37) % 70)}%`, animation: "mock-wave 0.9s ease-in-out infinite", animationDelay: `${(i % 8) * 90}ms` }}
              />
            ))}
          </div>
          <div className="w-full space-y-2.5">
            {mock.user && (
              <Bubble who="user" delay={400}>
                {mock.user}
              </Bubble>
            )}
            {mock.ai && (
              <Bubble who="ai" delay={1400}>
                {mock.ai}
              </Bubble>
            )}
          </div>
        </div>
      );
    case "image":
      return (
        <div className="min-h-[300px] space-y-3">
          {mock.user && (
            <Bubble who="user" delay={0}>
              {mock.user}
            </Bubble>
          )}
          <div className="grid grid-cols-2 gap-2.5">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="mock-in relative aspect-square overflow-hidden rounded-xl ring-1 ring-white/10" style={d(500 + i * 120)}>
                <span className="mock-shimmer absolute inset-0" />
                <span
                  className="absolute inset-0"
                  style={{
                    background: [
                      "radial-gradient(circle at 30% 30%, #00f5d4aa, transparent 55%), radial-gradient(circle at 70% 75%, #ff4566aa, transparent 50%), #0a1b30",
                      "radial-gradient(circle at 60% 40%, #5cd6ffaa, transparent 55%), radial-gradient(circle at 25% 80%, #3dff8f88, transparent 50%), #0a1b30",
                      "linear-gradient(160deg, #00f5d455, transparent 60%), radial-gradient(circle at 50% 70%, #ffffff55, transparent 40%), #0a1b30",
                      "radial-gradient(circle at 50% 50%, #ff456688, transparent 50%), linear-gradient(20deg, #5cd6ff55, transparent 70%), #0a1b30",
                    ][i],
                    animation: "mock-in 0.8s ease both",
                    animationDelay: `${1400 + i * 180}ms`,
                  }}
                />
              </div>
            ))}
          </div>
          {mock.ai && (
            <Bubble who="ai" delay={2300}>
              {mock.ai}
            </Bubble>
          )}
        </div>
      );
    case "video":
      return (
        <div className="min-h-[300px] space-y-3">
          {mock.user && (
            <Bubble who="user" delay={0}>
              {mock.user}
            </Bubble>
          )}
          <div className="mock-in relative aspect-video overflow-hidden rounded-xl ring-1 ring-white/15" style={d(500)}>
            <span
              className="absolute inset-0"
              style={{
                background:
                  "radial-gradient(ellipse at 30% 60%, #00f5d466, transparent 55%), radial-gradient(ellipse at 75% 30%, #ff456655, transparent 50%), linear-gradient(180deg,#061223,#0a1b30)",
              }}
            />
            <span className="absolute inset-0 animate-pulse-glow bg-[radial-gradient(circle_at_50%_120%,#5cd6ff44,transparent_60%)]" />
            <span className="absolute left-1/2 top-1/2 grid size-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white/15 text-white backdrop-blur">
              <NeonIcon name="play" className="size-5" />
            </span>
            <span className="absolute inset-x-3 bottom-3 h-1 overflow-hidden rounded bg-white/20">
              <span className="block h-full bg-neon-turq" style={{ animation: "mock-progress 4s linear both", animationDelay: "900ms" }} />
            </span>
          </div>
          {items.length > 0 && (
            <div className="mock-in flex flex-wrap gap-2" style={d(900)}>
              {items.map((it) => (
                <span key={it} className="rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1 text-xs text-slate-300">
                  {it}
                </span>
              ))}
            </div>
          )}
          {mock.ai && (
            <Bubble who="ai" delay={1500}>
              {mock.ai}
            </Bubble>
          )}
        </div>
      );
    case "flow":
      return (
        <div className="flex min-h-[300px] flex-col items-center gap-0 py-2">
          {(items.length ? items : ["Tetikleyici", "Eylem"]).map((it, i, arr) => (
            <div key={it} className="flex flex-col items-center">
              <div
                className={cn(
                  "mock-in flex w-64 items-center gap-3 rounded-xl border px-4 py-3",
                  i === 0 ? "border-neon-green/50 bg-neon-green/10" : "border-neon-blue/40 bg-neon-blue/[0.07]",
                )}
                style={d(i * 350)}
              >
                <span
                  className={cn(
                    "grid size-7 place-items-center rounded-lg text-xs font-bold",
                    i === 0 ? "bg-neon-green/20 text-neon-green" : "bg-neon-blue/20 text-neon-blue",
                  )}
                >
                  {i + 1}
                </span>
                <span className="truncate text-xs text-white">{it}</span>
              </div>
              {i < arr.length - 1 && (
                <svg width="2" height="26" aria-hidden className="overflow-visible">
                  <line
                    x1="1"
                    y1="0"
                    x2="1"
                    y2="26"
                    stroke="#00f5d4"
                    strokeWidth="2"
                    strokeDasharray="26"
                    strokeDashoffset="26"
                    style={{ animation: "mock-dash 0.4s ease forwards", animationDelay: `${i * 350 + 250}ms` }}
                  />
                </svg>
              )}
            </div>
          ))}
          {mock.ai && (
            <p
              className="mock-in mt-4 max-w-sm rounded-xl bg-white/[0.05] p-3 text-center text-xs leading-5 text-slate-300"
              style={d(items.length * 350 + 200)}
            >
              {mock.ai}
            </p>
          )}
        </div>
      );
    case "result":
      return (
        <div className="min-h-[300px] space-y-3">
          <div className="mock-in rounded-xl border border-white/10 bg-white/[0.04] p-4" style={d(0)}>
            <span className="flex items-center gap-2 text-xs font-semibold text-neon-green">
              <NeonIcon name="check" className="size-4" /> Hazır
            </span>
            <p className="mt-2 line-clamp-6 leading-6 text-slate-200">{mock.ai}</p>
            <div className="mt-3 space-y-1.5">
              {[80, 95, 60].map((w, i) => (
                <span key={i} className="mock-shimmer block h-2 rounded" style={{ width: `${w}%` }} />
              ))}
            </div>
          </div>
          {items.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {items.map((it, i) => (
                <span
                  key={it}
                  className={cn(
                    "mock-in rounded-lg border px-3 py-1.5 text-xs",
                    i === 0 ? "mock-click border-neon-turq/60 bg-neon-turq/10 text-white" : "border-white/10 bg-white/[0.04] text-slate-300",
                  )}
                  style={d(500 + i * 100)}
                >
                  {it}
                </span>
              ))}
            </div>
          )}
        </div>
      );
    case "chat":
    default:
      return (
        <div className="min-h-[300px] space-y-3 pb-16">
          {mock.user && (
            <Bubble who="user" delay={1500}>
              {mock.user}
            </Bubble>
          )}
          {mock.user && <Thinking delay={1900} />}
          {mock.ai && (
            <Bubble who="ai" delay={2500}>
              {mock.ai}
            </Bubble>
          )}
          {items.length > 0 && (
            <div className="mock-in flex flex-wrap gap-2" style={d(2900)}>
              {items.map((it) => (
                <span key={it} className="rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1 text-xs text-slate-300">
                  {it}
                </span>
              ))}
            </div>
          )}
          <Composer text={mock.user} delay={0} />
        </div>
      );
  }
}
