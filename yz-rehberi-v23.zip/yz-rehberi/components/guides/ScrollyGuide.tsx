"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";
import type { GuideStep } from "@/lib/guides";
import { cn } from "@/lib/cn";
import { MockScreen } from "./MockScreen";

const AUTOPLAY_MS = 7000;

/**
 * Scrollytelling rehber: sol sütunda adımlar akar, sağda yapışkan "ekran" etkin adımı canlandırır.
 * - Fare tekerleği / dokunmatik / ok tuşları ile doğal kaydırma
 * - "Video gibi izle" düğmesi adımları otomatik ilerletir (kullanıcı kaydırınca durur)
 * - Tüm adım metinleri sunucuda HTML olarak üretilir (SEO)
 */
export function ScrollyGuide({ steps, tool }: { steps: GuideStep[]; tool: string }) {
  const [active, setActive] = useState(0);
  const [playing, setPlaying] = useState(false);
  const refs = useRef<(HTMLLIElement | null)[]>([]);
  const programmatic = useRef(false);

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActive(Number((e.target as HTMLElement).dataset.step));
        }
      },
      { rootMargin: "-45% 0px -45% 0px" },
    );
    refs.current.forEach((el) => el && io.observe(el));
    return () => io.disconnect();
  }, []);

  const goTo = useCallback((i: number) => {
    const el = refs.current[i];
    if (!el) return;
    programmatic.current = true;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    window.setTimeout(() => (programmatic.current = false), 900);
  }, []);

  // Otomatik oynatma
  useEffect(() => {
    if (!playing) return;
    const t = window.setTimeout(() => {
      if (active >= steps.length - 1) setPlaying(false);
      else goTo(active + 1);
    }, AUTOPLAY_MS);
    return () => window.clearTimeout(t);
  }, [playing, active, steps.length, goTo]);

  // Kullanıcı elle kaydırırsa otomatik oynatmayı durdur
  useEffect(() => {
    if (!playing) return;
    const stop = () => !programmatic.current && setPlaying(false);
    window.addEventListener("wheel", stop, { passive: true });
    window.addEventListener("touchmove", stop, { passive: true });
    window.addEventListener("keydown", stop);
    return () => {
      window.removeEventListener("wheel", stop);
      window.removeEventListener("touchmove", stop);
      window.removeEventListener("keydown", stop);
    };
  }, [playing]);

  const current = steps[active];

  return (
    <div className="relative">
      {/* Kontrol çubuğu */}
      <div className="glass sticky top-[4.25rem] z-20 mb-6 flex items-center gap-3 rounded-2xl px-3 py-2 md:top-[5.25rem]">
        <button
          type="button"
          onClick={() => {
            if (!playing && active === steps.length - 1) goTo(0);
            setPlaying((p) => !p);
          }}
          className={cn(
            "flex h-9 shrink-0 items-center gap-2 rounded-xl px-3 text-sm font-semibold transition",
            playing ? "bg-neon-red/20 text-neon-red" : "bg-neon-turq text-space-950",
          )}
        >
          <NeonIcon name={playing ? "pause" : "play"} className="size-4" />
          {playing ? "Durdur" : "Video gibi izle"}
        </button>
        <ol className="flex flex-1 items-center gap-1" aria-label="Adımlar">
          {steps.map((s, i) => (
            <li key={s.title} className="flex-1">
              <button
                type="button"
                onClick={() => goTo(i)}
                aria-label={`Adım ${i + 1}: ${s.title}`}
                aria-current={i === active ? "step" : undefined}
                className="block h-6 w-full py-2.5"
              >
                <span className="relative block h-1 overflow-hidden rounded-full bg-white/10">
                  <span
                    className={cn("absolute inset-y-0 left-0 rounded-full bg-neon-turq", i < active && "w-full", i > active && "w-0")}
                    style={
                      i === active
                        ? { width: playing ? undefined : "100%", animation: playing ? `mock-progress ${AUTOPLAY_MS}ms linear both` : undefined }
                        : undefined
                    }
                  />
                </span>
              </button>
            </li>
          ))}
        </ol>
        <span className="hidden shrink-0 font-mono text-xs text-slate-400 sm:block">
          {active + 1}/{steps.length}
        </span>
      </div>

      <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]">
        <ol className="space-y-6 lg:space-y-0">
          {steps.map((s, i) => (
            <li
              key={s.title}
              ref={(el) => {
                refs.current[i] = el;
              }}
              data-step={i}
              className="flex min-h-0 flex-col justify-center lg:min-h-[78vh]"
            >
              <article
                className={cn(
                  "rounded-2xl border p-6 transition duration-500",
                  i === active ? "border-neon-turq/50 bg-neon-turq/[0.06] shadow-glow-turq" : "border-white/10 bg-white/[0.03] lg:opacity-45",
                )}
              >
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-neon-turq">
                  <span className="grid size-7 place-items-center rounded-full bg-neon-turq/20 font-display text-sm">{i + 1}</span>
                  Adım {i + 1}
                </p>
                <h3 className="mt-3 font-display text-2xl font-bold text-white">{s.title}</h3>
                <p className="mt-3 leading-7 text-slate-300">{s.body}</p>
                {s.tip && (
                  <p className="mt-4 flex gap-2.5 rounded-xl border border-neon-green/30 bg-neon-green/[0.06] p-3 text-sm leading-6 text-slate-200">
                    <NeonIcon name="lightbulb" className="mt-0.5 size-4 shrink-0 text-neon-green" />
                    <span>
                      <strong className="text-neon-green">İpucu: </strong>
                      {s.tip}
                    </span>
                  </p>
                )}
                {/* Mobil: maket adımın içinde */}
                {s.mock && (
                  <div className="mt-5 lg:hidden">
                    <MockScreen key={`${i}-${i === active}`} mock={s.mock} tool={tool} step={i + 1} />
                  </div>
                )}
              </article>
            </li>
          ))}
        </ol>

        {/* Masaüstü: yapışkan ekran */}
        <div className="hidden lg:block">
          <div className="sticky top-36">
            <div
              aria-hidden
              className="absolute -inset-6 -z-10 rounded-[2rem] bg-[radial-gradient(circle_at_50%_40%,rgba(0,245,212,0.18),transparent_65%)] blur-2xl"
            />
            {current?.mock ? (
              <MockScreen key={active} mock={current.mock} tool={tool} step={active + 1} />
            ) : (
              <div className="grid min-h-[380px] place-items-center rounded-2xl border border-white/10 text-slate-500">Adım {active + 1}</div>
            )}
            <p className="mt-4 text-center text-xs text-slate-500">Canlandırma temsilidir; arayüz zamanla değişebilir.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
