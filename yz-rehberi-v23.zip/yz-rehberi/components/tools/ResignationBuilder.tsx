"use client";

import { Check, Copy, Printer } from "lucide-react";
import { useMemo, useState, type ReactNode } from "react";
import { cn } from "@/lib/cn";

type Reason = "standart" | "hakli" | "emeklilik";

const REASONS: Record<Reason, { label: string; body: (d: FormState) => string }> = {
  standart: {
    label: "Standart istifa (ihbar süreli)",
    body: (d) =>
      `Şirketinizde ${d.baslangic ? formatDate(d.baslangic) + " tarihinden bu yana " : ""}${d.pozisyon || "[POZİSYON]"} olarak görev yapmaktayım. Kişisel nedenlerle iş sözleşmemi 4857 sayılı İş Kanunu'nun 17. maddesinde belirtilen ihbar süresine uyarak feshetmek istiyorum.\n\nİhbar sürem ${d.ihbar} hafta olup son çalışma günüm ${d.sonGun ? formatDate(d.sonGun) : "[SON ÇALIŞMA GÜNÜ]"} olacaktır. Bu süre içinde iş devrinin sorunsuz yapılması için gereken desteği vereceğim.`,
  },
  hakli: {
    label: "Haklı nedenle fesih (İş K. md. 24)",
    body: (d) =>
      `Şirketinizde ${d.pozisyon || "[POZİSYON]"} olarak çalışmaktayım. ${d.gerekce || "[HAKLI NEDENİ AÇIK VE TARİHLERİYLE YAZIN — örn. ... aylarına ait ücretlerim ödenmemiştir]"}\n\nBu nedenle iş sözleşmemi 4857 sayılı İş Kanunu'nun 24. maddesi uyarınca haklı nedenle derhal feshediyorum. Kıdem tazminatım başta olmak üzere ödenmemiş ücret, fazla mesai ve yıllık izin alacaklarımın tarafıma ödenmesini talep ederim.`,
  },
  emeklilik: {
    label: "Emeklilik nedeniyle ayrılma",
    body: (d) =>
      `Şirketinizde ${d.pozisyon || "[POZİSYON]"} olarak çalışmaktayım. Sosyal Güvenlik Kurumu'ndan aldığım yazı ile emekliliğe hak kazanmış bulunmaktayım.\n\nBu nedenle iş sözleşmemi ${d.sonGun ? formatDate(d.sonGun) : "[TARİH]"} tarihi itibarıyla sona erdiriyorum. 1475 sayılı Kanun'un yürürlükteki 14. maddesi uyarınca kıdem tazminatımın ve diğer yasal haklarımın ödenmesini talep ederim.`,
  },
};

type FormState = {
  adSoyad: string;
  tc: string;
  sirket: string;
  pozisyon: string;
  baslangic: string;
  sonGun: string;
  ihbar: number;
  sebep: Reason;
  gerekce: string;
};

function formatDate(iso: string) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

/** İş Kanunu md. 17 — kıdeme göre ihbar süresi (hafta) */
function ihbarHafta(baslangic: string): number {
  if (!baslangic) return 2;
  const months = (Date.now() - new Date(baslangic).getTime()) / (1000 * 60 * 60 * 24 * 30.44);
  if (months < 6) return 2;
  if (months < 18) return 4;
  if (months < 36) return 6;
  return 8;
}

export function ResignationBuilder() {
  const [d, setD] = useState<FormState>({
    adSoyad: "",
    tc: "",
    sirket: "",
    pozisyon: "",
    baslangic: "",
    sonGun: "",
    ihbar: 2,
    sebep: "standart",
    gerekce: "",
  });
  const [copied, setCopied] = useState(false);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) =>
    setD((prev) => {
      const next = { ...prev, [k]: v };
      if (k === "baslangic") next.ihbar = ihbarHafta(String(v));
      return next;
    });

  const text = useMemo(() => {
    const today = new Date().toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit", year: "numeric" });
    return `${(d.sirket || "[ŞİRKET ADI]").toLocaleUpperCase("tr-TR")}\nİNSAN KAYNAKLARI MÜDÜRLÜĞÜNE\n\n${" ".repeat(60)}${today}\n\nKonu: İstifa bildirimi\n\n${REASONS[d.sebep].body(d)}\n\nGereğinin yapılmasını saygılarımla arz ederim.\n\n${" ".repeat(50)}${d.adSoyad || "[AD SOYAD]"}\n${" ".repeat(50)}İmza\n${d.tc ? `\nT.C. Kimlik No: ${d.tc}` : ""}`;
  }, [d]);

  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function print() {
    // Not: "noopener" verilirse window.open null döner ve yazdırma penceresine erişilemez.
    const w = window.open("", "_blank", "width=800,height=900");
    if (!w) return;
    w.document.write(
      `<pre style="font:15px/1.7 'Times New Roman',serif;white-space:pre-wrap;padding:48px">${text.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]!)}</pre>`,
    );
    w.document.close();
    w.print();
  }

  const input = "w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-white outline-none transition focus:border-neon-blue";

  return (
    <div className="glass grid gap-8 rounded-3xl p-6 md:p-8 lg:grid-cols-2">
      <form className="space-y-4" onSubmit={(e) => e.preventDefault()} aria-label="Dilekçe bilgileri">
        <Field label="Ad Soyad">
          <input className={input} value={d.adSoyad} onChange={(e) => set("adSoyad", e.target.value)} autoComplete="name" />
        </Field>
        <Field label="T.C. Kimlik No (isteğe bağlı)">
          <input className={input} value={d.tc} onChange={(e) => set("tc", e.target.value.replace(/\D/g, "").slice(0, 11))} inputMode="numeric" />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Şirket adı">
            <input className={input} value={d.sirket} onChange={(e) => set("sirket", e.target.value)} autoComplete="organization" />
          </Field>
          <Field label="Pozisyon">
            <input className={input} value={d.pozisyon} onChange={(e) => set("pozisyon", e.target.value)} autoComplete="organization-title" />
          </Field>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="İşe başlama tarihi">
            <input type="date" className={input} value={d.baslangic} onChange={(e) => set("baslangic", e.target.value)} />
          </Field>
          <Field label="Son çalışma günü">
            <input type="date" className={input} value={d.sonGun} onChange={(e) => set("sonGun", e.target.value)} />
          </Field>
        </div>
        <Field label="Ayrılma türü">
          <select className={input} value={d.sebep} onChange={(e) => set("sebep", e.target.value as Reason)}>
            {Object.entries(REASONS).map(([k, v]) => (
              <option key={k} value={k} className="bg-space-900">
                {v.label}
              </option>
            ))}
          </select>
        </Field>
        {d.sebep === "hakli" && (
          <Field label="Haklı neden (somut ve tarihli yazın)">
            <textarea rows={4} className={input} value={d.gerekce} onChange={(e) => set("gerekce", e.target.value)} />
          </Field>
        )}
        {d.sebep === "standart" && (
          <p className="rounded-xl border border-neon-blue/20 bg-neon-blue/5 p-3 text-sm text-slate-300">
            Kıdeminize göre yasal ihbar süreniz: <strong className="text-neon-blue">{d.ihbar} hafta</strong>
          </p>
        )}
      </form>

      <div className="flex flex-col">
        <div className="flex-1 rounded-2xl bg-slate-100 p-6 text-slate-900 shadow-2xl">
          <pre className="whitespace-pre-wrap font-serif text-[14px] leading-7">{text}</pre>
        </div>
        <div className="mt-4 flex gap-3">
          <button
            type="button"
            onClick={copy}
            className={cn(
              "inline-flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 font-semibold transition",
              copied ? "bg-neon-green text-black" : "bg-gradient-to-r from-neon-blue to-neon-turq text-white hover:shadow-glow-turq",
            )}
          >
            {copied ? <Check className="size-4" /> : <Copy className="size-4" />} {copied ? "Kopyalandı" : "Metni kopyala"}
          </button>
          <button
            type="button"
            onClick={print}
            className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-3 font-semibold text-white hover:border-white/40"
          >
            <Printer className="size-4" /> Yazdır / PDF
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-slate-300">{label}</span>
      {children}
    </label>
  );
}
