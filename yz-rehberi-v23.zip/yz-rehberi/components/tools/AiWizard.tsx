"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import { Monogram, PowerBar, PricingBadge } from "@/components/models/ModelBits";
import type { CompareModel } from "@/lib/compare";
import type { Accent, CategoryKey } from "@/lib/model-meta";
import { cn } from "@/lib/cn";

type Budget = "free" | "paid" | "local";
type Level = "new" | "pro";

const GOALS: { key: CategoryKey; label: string; accent: Accent }[] = [
  { key: "sohbet", label: "Yazı, soru-cevap, sohbet", accent: "turq" },
  { key: "gorsel", label: "Görsel / resim oluşturma", accent: "blue" },
  { key: "video", label: "Video oluşturma", accent: "red" },
  { key: "ses", label: "Seslendirme, ses klonlama", accent: "green" },
  { key: "muzik", label: "Şarkı / müzik yapma", accent: "turq" },
  { key: "kod", label: "Kod yazma, uygulama yapma", accent: "blue" },
  { key: "sunum", label: "Sunum ve belge hazırlama", accent: "red" },
  { key: "arastirma", label: "Araştırma, kaynaklı bilgi", accent: "turq" },
  { key: "ajan", label: "İşleri otomatikleştirme", accent: "green" },
  { key: "avatar", label: "Konuşan avatar videosu", accent: "blue" },
  { key: "3d", label: "3D model üretimi", accent: "green" },
];

let cache: Promise<CompareModel[]> | null = null;
const load = () => (cache ??= fetch("/compare-data.json").then((r) => r.json()));

export function AiWizard() {
  const [step, setStep] = useState(0);
  const [goal, setGoal] = useState<CategoryKey | null>(null);
  const [budget, setBudget] = useState<Budget | null>(null);
  const [turkish, setTurkish] = useState<boolean | null>(null);
  const [level, setLevel] = useState<Level | null>(null);
  const [all, setAll] = useState<CompareModel[] | null>(null);

  useEffect(() => {
    load().then(setAll);
  }, []);

  const results = useMemo(() => {
    if (!all || !goal || !budget || turkish === null || !level) return [];
    return all
      .filter((m) => m.status !== "kapandi" && m.categories.includes(goal))
      .filter((m) => (budget === "free" ? m.pricing !== "ucretli" : budget === "local" ? m.openWeights : true))
      .map((m) => {
        let score = m.power;
        const why: string[] = [];
        if (m.primaryCategory === goal) score += 12; // uzman araçlar öne çıkar
        if (turkish) {
          if (m.turkish === "iyi") {
            score += 8;
            why.push("Türkçesi iyi");
          } else if (m.turkish === "zayıf") score -= 10;
        }
        if (budget === "free" && (m.pricing === "ucretsiz" || m.pricing === "acik-kaynak")) {
          score += 3;
          why.push("tamamen ücretsiz");
        } else if (budget !== "local" && m.pricing !== "ucretli") why.push("ücretsiz planı var");
        if (level === "new") {
          if (m.platforms?.some((p) => /web/i.test(p))) score += 4;
          if (m.openWeights && budget !== "local") score -= 6;
        } else if (m.openWeights || m.apiFree) score += 2;
        if (m.openWeights) why.push("bilgisayarınızda çalışır");
        why.unshift(m.bestFor[0] ?? "");
        return { m, score, why: why.filter(Boolean).slice(0, 3) };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  }, [all, goal, budget, turkish, level]);

  const reset = () => {
    setStep(0);
    setGoal(null);
    setBudget(null);
    setTurkish(null);
    setLevel(null);
  };

  const Option = ({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) => (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "group flex items-center gap-3 rounded-2xl border p-3 text-left text-sm font-medium transition",
        active ? "border-neon-turq/60 bg-neon-turq/10 text-white shadow-glow-turq" : "border-white/10 bg-white/[0.04] text-slate-200 hover:border-neon-turq/40",
      )}
    >
      {children}
    </button>
  );

  return (
    <div className="glass rounded-3xl p-5 md:p-8">
      {/* İlerleme */}
      <ol className="mb-6 flex gap-2" aria-label="Sihirbaz adımları">
        {["Amaç", "Bütçe", "Dil", "Seviye", "Sonuç"].map((l, i) => (
          <li key={l} className="flex-1">
            <span className={cn("block h-1 rounded-full", i <= step ? "bg-neon-turq" : "bg-white/10")} />
            <span className={cn("mt-1.5 block text-[11px]", i === step ? "text-neon-turq" : "text-slate-500")}>{l}</span>
          </li>
        ))}
      </ol>

      {step === 0 && (
        <fieldset>
          <legend className="font-display text-2xl font-bold text-white">1. Yapay zekâyla ne yapmak istiyorsunuz?</legend>
          <div className="mt-5 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {GOALS.map((g) => (
              <Option
                key={g.key}
                active={goal === g.key}
                onClick={() => {
                  setGoal(g.key);
                  setStep(1);
                }}
              >
                <IconTile name={g.key} accent={g.accent} size="sm" />
                {g.label}
              </Option>
            ))}
          </div>
        </fieldset>
      )}

      {step === 1 && (
        <fieldset>
          <legend className="font-display text-2xl font-bold text-white">2. Bütçeniz nedir?</legend>
          <div className="mt-5 grid gap-2.5 sm:grid-cols-3">
            {(
              [
                { v: "free", l: "Sadece ücretsiz", d: "Ücretsiz plan veya günlük kredi yeterli", i: "gift" },
                { v: "paid", l: "Ödeme yapabilirim", d: "En iyi sonucu istiyorum", i: "crown" },
                { v: "local", l: "Kendi bilgisayarımda", d: "Açık kaynak, internetsiz, gizli", i: "cpu" },
              ] as const
            ).map((o) => (
              <Option
                key={o.v}
                active={budget === o.v}
                onClick={() => {
                  setBudget(o.v);
                  setStep(2);
                }}
              >
                <IconTile name={o.i} accent={o.v === "free" ? "green" : o.v === "paid" ? "red" : "blue"} size="sm" />
                <span>
                  <span className="block">{o.l}</span>
                  <span className="block text-xs font-normal text-slate-500">{o.d}</span>
                </span>
              </Option>
            ))}
          </div>
        </fieldset>
      )}

      {step === 2 && (
        <fieldset>
          <legend className="font-display text-2xl font-bold text-white">3. Türkçe kullanmak sizin için önemli mi?</legend>
          <div className="mt-5 grid gap-2.5 sm:grid-cols-2">
            <Option
              active={turkish === true}
              onClick={() => {
                setTurkish(true);
                setStep(3);
              }}
            >
              <IconTile name="globe" accent="turq" size="sm" /> Evet, Türkçe yazacağım
            </Option>
            <Option
              active={turkish === false}
              onClick={() => {
                setTurkish(false);
                setStep(3);
              }}
            >
              <IconTile name="globe" accent="blue" size="sm" /> Fark etmez / İngilizce de olur
            </Option>
          </div>
        </fieldset>
      )}

      {step === 3 && (
        <fieldset>
          <legend className="font-display text-2xl font-bold text-white">4. Deneyim seviyeniz?</legend>
          <div className="mt-5 grid gap-2.5 sm:grid-cols-2">
            <Option
              active={level === "new"}
              onClick={() => {
                setLevel("new");
                setStep(4);
              }}
            >
              <IconTile name="book" accent="green" size="sm" /> Yeni başlıyorum, kolay olsun
            </Option>
            <Option
              active={level === "pro"}
              onClick={() => {
                setLevel("pro");
                setStep(4);
              }}
            >
              <IconTile name="cpu" accent="red" size="sm" /> Deneyimliyim, güç önemli
            </Option>
          </div>
        </fieldset>
      )}

      {step === 4 && (
        <section aria-live="polite">
          <h2 className="font-display text-2xl font-bold text-white">Size en uygun {results.length} yapay zekâ</h2>
          {!all && <p className="mt-4 text-slate-400">Hesaplanıyor…</p>}
          {all && results.length === 0 && (
            <p className="mt-4 text-slate-400">
              Bu kombinasyona uyan model bulunamadı. Bütçe seçimini &quot;Ödeme yapabilirim&quot; olarak değiştirmeyi deneyin.
            </p>
          )}
          <ol className="mt-5 space-y-3">
            {results.map(({ m, why }, i) => (
              <li key={m.slug}>
                <Link
                  href={`/ai-araclari/${m.slug}`}
                  className={cn(
                    "group flex flex-col gap-4 rounded-2xl border p-4 transition sm:flex-row sm:items-center",
                    i === 0 ? "border-neon-turq/60 bg-neon-turq/[0.07] shadow-glow-turq" : "border-white/10 bg-white/[0.03] hover:border-neon-turq/40",
                  )}
                >
                  <span className="flex items-center gap-3">
                    <span className={cn("w-6 text-center font-display text-xl font-bold", i === 0 ? "text-neon-red" : "text-slate-500")}>{i + 1}</span>
                    <Monogram slug={m.slug} name={m.name} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-lg font-semibold text-white group-hover:text-neon-turq">{m.name}</span>
                      <PricingBadge pricing={m.pricing} />
                      {i === 0 && <span className="rounded-md bg-neon-red/20 px-2 py-0.5 text-[11px] font-bold text-neon-red">En iyi eşleşme</span>}
                    </span>
                    <span className="mt-1 block text-sm text-slate-400">{why.join(" · ")}</span>
                    <span className="mt-1 block text-xs text-slate-500">Ücretsiz: {m.freeQuota}</span>
                  </span>
                  <PowerBar value={m.power} className="w-full sm:w-36" />
                </Link>
              </li>
            ))}
          </ol>
          <div className="mt-6 flex flex-wrap gap-3">
            <button type="button" onClick={reset} className="btn-ghost py-2.5 text-sm">
              Baştan başla
            </button>
            {results.length >= 2 && (
              <Link
                href={`/karsilastir?m=${results
                  .slice(0, 3)
                  .map((r) => r.m.slug)
                  .join(",")}`}
                className="btn-neon py-2.5 text-sm"
              >
                <NeonIcon name="compare" className="size-4" /> İlk 3&apos;ü karşılaştır
              </Link>
            )}
          </div>
        </section>
      )}

      {step > 0 && step < 4 && (
        <button type="button" onClick={() => setStep(step - 1)} className="mt-6 text-sm text-slate-400 hover:text-white">
          ← Geri
        </button>
      )}
    </div>
  );
}
