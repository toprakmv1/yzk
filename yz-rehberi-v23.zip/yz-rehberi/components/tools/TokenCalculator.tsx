"use client";

import { useMemo, useState } from "react";
import { NeonIcon } from "@/components/icons/NeonIcon";

/** Fiyatlar: data/models.json `apiFree` alanından (Ekim 2026). 1M token başına USD, giriş / çıkış. */
export const PRICE_PRESETS = [
  { id: "gpt6-luna", name: "GPT-6 Luna (OpenAI)", input: 0.1, output: 0.5 },
  { id: "deepseek", name: "DeepSeek V4.1 Flash", input: 0.3, output: 1.2 },
  { id: "muse-spark", name: "Meta Muse Spark", input: 1.25, output: 4.25 },
  { id: "glm", name: "GLM-5.3 (Z.ai)", input: 1.4, output: 4.4 },
  { id: "sonnet", name: "Claude Sonnet 5.5", input: 2, output: 10 },
  { id: "grok", name: "Grok 4.7 (xAI)", input: 2, output: 6 },
  { id: "kimi", name: "Kimi K3", input: 3, output: 15 },
  { id: "opus", name: "Claude Opus 5.5", input: 4, output: 20 },
] as const;

const TR_CHARS = /[çğıöşüÇĞİÖŞÜ]/g;

export function estimateTokens(text: string) {
  const chars = text.length;
  if (!chars) return { tokens: 0, low: 0, high: 0, words: 0, chars: 0, turkish: false };
  const words = (text.trim().match(/\S+/g) ?? []).length;
  const trRatio = (text.match(TR_CHARS)?.length ?? 0) / Math.max(1, chars);
  const turkish = trRatio > 0.01 || /\b(ve|bir|bu|için|ile|da|de)\b/i.test(text);
  // Türkçe gibi eklemeli dillerde karakter başına daha fazla token düşer
  const byChars = chars / (turkish ? 3.1 : 4.0);
  const byWords = words * (turkish ? 1.9 : 1.33);
  const tokens = Math.max(1, Math.round((byChars + byWords) / 2));
  return { tokens, low: Math.round(tokens * 0.8), high: Math.round(tokens * 1.25), words, chars, turkish };
}

const fmt = (n: number) => n.toLocaleString("tr-TR");
const usd = (n: number) => (n < 0.01 ? `$${n.toFixed(4)}` : n < 1 ? `$${n.toFixed(3)}` : `$${n.toLocaleString("en-US", { maximumFractionDigits: 2 })}`);

export function TokenCalculator() {
  const [text, setText] = useState(
    "Merhaba! Bu metin, yapay zekâ modellerinin token hesaplamasını göstermek için yazıldı. Kendi metninizi buraya yapıştırarak yaklaşık token sayısını ve API maliyetini görebilirsiniz.",
  );
  const [outTokens, setOutTokens] = useState(500);
  const [requests, setRequests] = useState(1000);
  const [custom, setCustom] = useState({ input: 1, output: 4 });
  const est = useMemo(() => estimateTokens(text), [text]);

  const rows = [...PRICE_PRESETS, { id: "custom", name: "Özel fiyat (kendi değerleriniz)", ...custom }].map((p) => {
    const per = (est.tokens * p.input + outTokens * p.output) / 1_000_000;
    return { ...p, per, month: per * requests };
  });

  return (
    <div className="space-y-6">
      <div className="glass rounded-2xl p-5">
        <label htmlFor="tk-text" className="text-sm font-semibold text-white">
          Metninizi yapıştırın (prompt / belge)
        </label>
        <textarea
          id="tk-text"
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, 200_000))}
          rows={7}
          className="mt-3 w-full resize-y rounded-xl border border-white/10 bg-black/30 p-4 font-mono text-sm leading-6 text-slate-200 outline-none focus:border-neon-turq"
        />
        <dl className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
          {[
            { l: "Tahmini token", v: fmt(est.tokens), c: "text-neon-turq" },
            { l: "Aralık", v: `${fmt(est.low)} – ${fmt(est.high)}`, c: "text-white" },
            { l: "Kelime", v: fmt(est.words), c: "text-white" },
            { l: "Karakter", v: fmt(est.chars), c: "text-white" },
          ].map((s) => (
            <div key={s.l} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <dt className="text-xs text-slate-500">{s.l}</dt>
              <dd className={`mt-1 font-display text-2xl font-bold ${s.c}`}>{s.v}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-3 text-xs text-slate-500">
          {est.turkish
            ? "Türkçe metin algılandı: Türkçe eklemeli bir dil olduğu için aynı içerik İngilizceye göre genellikle %30–60 daha fazla token tutar."
            : "Metin İngilizce/benzeri olarak değerlendirildi (≈ 4 karakter = 1 token)."}{" "}
          Kesin değer modelin tokenizer&apos;ına göre değişir.
        </p>
      </div>

      <div className="glass grid gap-5 rounded-2xl p-5 md:grid-cols-3">
        <label className="block text-sm">
          <span className="font-semibold text-white">Beklenen yanıt uzunluğu</span>
          <span className="mt-1 block text-xs text-slate-500">
            {fmt(outTokens)} çıkış token&apos;ı (~{fmt(Math.round(outTokens / 1.9))} Türkçe kelime)
          </span>
          <input
            type="range"
            min={50}
            max={8000}
            step={50}
            value={outTokens}
            onChange={(e) => setOutTokens(Number(e.target.value))}
            className="mt-3 w-full accent-[#00f5d4]"
          />
        </label>
        <label className="block text-sm">
          <span className="font-semibold text-white">Aylık istek sayısı</span>
          <input
            type="number"
            min={1}
            max={100000000}
            value={requests}
            onChange={(e) => setRequests(Math.max(1, Math.min(1e8, Number(e.target.value) || 1)))}
            className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-white outline-none focus:border-neon-turq"
          />
        </label>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <label>
            <span className="font-semibold text-white">Özel giriş $</span>
            <input
              type="number"
              step="0.01"
              min={0}
              value={custom.input}
              onChange={(e) => setCustom((c) => ({ ...c, input: Math.max(0, Number(e.target.value) || 0) }))}
              className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-white outline-none focus:border-neon-turq"
            />
          </label>
          <label>
            <span className="font-semibold text-white">Özel çıkış $</span>
            <input
              type="number"
              step="0.01"
              min={0}
              value={custom.output}
              onChange={(e) => setCustom((c) => ({ ...c, output: Math.max(0, Number(e.target.value) || 0) }))}
              className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-white outline-none focus:border-neon-turq"
            />
          </label>
          <span className="col-span-2 text-xs text-slate-500">1M token başına USD</span>
        </div>
      </div>

      <div className="glass overflow-x-auto rounded-2xl">
        <table className="w-full min-w-[560px] text-left text-sm">
          <caption className="sr-only">Modellere göre tahmini API maliyeti</caption>
          <thead>
            <tr className="border-b border-white/10 text-xs uppercase tracking-wider text-slate-500">
              <th className="p-3 pl-4">Model</th>
              <th className="p-3">Giriş / çıkış (1M)</th>
              <th className="p-3">İstek başına</th>
              <th className="p-3 pr-4">Aylık ({fmt(requests)} istek)</th>
            </tr>
          </thead>
          <tbody>
            {rows
              .slice()
              .sort((a, b) => a.per - b.per)
              .map((r, i) => (
                <tr key={r.id} className="border-b border-white/5 last:border-0">
                  <td className="p-3 pl-4 font-medium text-white">
                    {i === 0 && <NeonIcon name="star" className="mr-1.5 inline size-4 text-neon-green" />}
                    {r.name}
                  </td>
                  <td className="p-3 font-mono text-xs text-slate-400">
                    ${r.input} / ${r.output}
                  </td>
                  <td className="p-3 font-mono text-slate-200">{usd(r.per)}</td>
                  <td className="p-3 pr-4 font-mono text-neon-turq">{usd(r.month)}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs leading-5 text-slate-500">
        Fiyatlar Ekim 2026 itibarıyla sağlayıcıların yayımladığı liste fiyatlarıdır; önbellek indirimi, toplu işlem (batch) ve bölgesel farklar hesaba
        katılmamıştır. Sağlayıcılar fiyatları sık değiştirir — üretim bütçesi için resmi fiyat sayfasını kontrol edin.
      </p>
    </div>
  );
}
