"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeftRight, RotateCcw } from "lucide-react";
import { useMemo, useState } from "react";
import { cn } from "@/lib/cn";

const RATES = [1, 10, 20] as const;
type Mode = "haric" | "dahil";

const tl = new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY", minimumFractionDigits: 2 });

/** "1.234,56" veya "1234.56" girişlerini sayıya çevirir */
function parseTr(input: string): number {
  const clean = input.replace(/\s/g, "").replace(/₺/g, "");
  if (!clean) return 0;
  const normalized = clean.includes(",") ? clean.replace(/\./g, "").replace(",", ".") : clean;
  const n = Number(normalized);
  return Number.isFinite(n) && n >= 0 ? n : NaN;
}

/** Kuruş hassasiyetinde yuvarlama (kayan nokta hatalarını önler) */
const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export function KdvCalculator() {
  const [amount, setAmount] = useState("1.000");
  const [rate, setRate] = useState<number>(20);
  const [custom, setCustom] = useState("");
  const [mode, setMode] = useState<Mode>("haric");

  const effectiveRate = custom ? parseTr(custom) : rate;
  const value = parseTr(amount);
  const invalid = Number.isNaN(value) || Number.isNaN(effectiveRate) || effectiveRate > 100;

  const result = useMemo(() => {
    if (invalid) return null;
    const r = effectiveRate / 100;
    if (mode === "haric") {
      const kdv = round2(value * r);
      return { matrah: round2(value), kdv, toplam: round2(value + kdv) };
    }
    const matrah = round2(value / (1 + r));
    return { matrah, kdv: round2(value - matrah), toplam: round2(value) };
  }, [value, effectiveRate, mode, invalid]);

  return (
    <div className="glass relative overflow-hidden rounded-3xl p-6 md:p-8">
      <div aria-hidden className="absolute -right-24 -top-24 size-64 rounded-full bg-neon-blue/15 blur-3xl" />

      <div className="relative grid gap-8 lg:grid-cols-2">
        {/* ---------- GİRİŞ ---------- */}
        <form className="space-y-6" onSubmit={(e) => e.preventDefault()} aria-label="KDV hesaplama formu">
          <fieldset>
            <legend className="mb-2 text-sm font-medium text-slate-300">Hesaplama yönü</legend>
            <div className="grid grid-cols-2 gap-2 rounded-xl border border-white/10 bg-black/30 p-1">
              {(
                [
                  ["haric", "KDV Hariç → Dahil"],
                  ["dahil", "KDV Dahil → Hariç"],
                ] as const
              ).map(([m, label]) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMode(m)}
                  aria-pressed={mode === m}
                  className={cn(
                    "relative rounded-lg px-3 py-2.5 text-sm font-medium transition",
                    mode === m ? "text-black" : "text-slate-400 hover:text-white",
                  )}
                >
                  {mode === m && (
                    <motion.span
                      layoutId="kdv-mode"
                      className="absolute inset-0 rounded-lg bg-neon-blue shadow-glow-blue"
                      transition={{ type: "spring", stiffness: 400, damping: 32 }}
                    />
                  )}
                  <span className="relative">{label}</span>
                </button>
              ))}
            </div>
          </fieldset>

          <div>
            <label htmlFor="tutar" className="mb-2 block text-sm font-medium text-slate-300">
              {mode === "haric" ? "KDV hariç tutar (₺)" : "KDV dahil tutar (₺)"}
            </label>
            <input
              id="tutar"
              inputMode="decimal"
              autoComplete="off"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              aria-invalid={Number.isNaN(value)}
              className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3.5 font-mono text-2xl text-white outline-none transition focus:border-neon-blue focus:shadow-glow-blue"
              placeholder="0,00"
            />
          </div>

          <fieldset>
            <legend className="mb-2 text-sm font-medium text-slate-300">KDV oranı</legend>
            <div className="flex flex-wrap gap-2">
              {RATES.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => {
                    setRate(r);
                    setCustom("");
                  }}
                  aria-pressed={!custom && rate === r}
                  className={cn(
                    "rounded-xl border px-5 py-2.5 font-mono font-semibold transition",
                    !custom && rate === r
                      ? "border-neon-green bg-neon-green/15 text-neon-green shadow-glow-green"
                      : "border-white/10 bg-white/5 text-slate-300 hover:border-white/30",
                  )}
                >
                  %{r}
                </button>
              ))}
              <input
                aria-label="Özel KDV oranı"
                inputMode="decimal"
                value={custom}
                onChange={(e) => setCustom(e.target.value)}
                placeholder="Özel %"
                className="w-28 rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 font-mono text-white outline-none focus:border-neon-turq"
              />
            </div>
          </fieldset>

          <button
            type="button"
            onClick={() => {
              setAmount("");
              setCustom("");
              setRate(20);
            }}
            className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white"
          >
            <RotateCcw className="size-4" /> Sıfırla
          </button>
        </form>

        {/* ---------- SONUÇ ---------- */}
        <div aria-live="polite" className="rounded-2xl border border-white/10 bg-black/40 p-6">
          <p className="flex items-center gap-2 text-sm text-slate-400">
            <ArrowLeftRight className="size-4 text-neon-turq" /> Sonuç · %{invalid ? "—" : effectiveRate} KDV
          </p>
          <AnimatePresence mode="wait">
            {result ? (
              <motion.dl
                key={`${result.toplam}-${mode}`}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mt-5 space-y-4"
              >
                <Row label="KDV hariç tutar (matrah)" value={tl.format(result.matrah)} />
                <Row label="KDV tutarı" value={tl.format(result.kdv)} highlight="turq" />
                <div className="h-px bg-white/10" />
                <Row label="KDV dahil toplam" value={tl.format(result.toplam)} highlight="green" big />
              </motion.dl>
            ) : (
              <p className="mt-6 text-sm text-amber-300">Lütfen geçerli bir tutar ve 0–100 arası bir oran girin.</p>
            )}
          </AnimatePresence>
          <p className="mt-6 text-xs leading-5 text-slate-500">
            Formül: {mode === "haric" ? "Toplam = Tutar × (1 + oran/100)" : "Matrah = Tutar ÷ (1 + oran/100)"}. Sonuçlar kuruşa yuvarlanır; resmi işlemlerde
            mali müşavirinize danışın.
          </p>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, highlight, big }: { label: string; value: string; highlight?: "green" | "turq"; big?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="text-sm text-slate-400">{label}</dt>
      <dd
        className={cn(
          "font-mono font-semibold tabular-nums",
          big ? "text-3xl" : "text-lg",
          highlight === "green" && "text-neon-green text-glow-green",
          highlight === "turq" && "text-neon-turq",
          !highlight && "text-white",
        )}
      >
        {value}
      </dd>
    </div>
  );
}
