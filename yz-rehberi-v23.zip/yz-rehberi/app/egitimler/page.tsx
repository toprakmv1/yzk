import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { Monogram } from "@/components/models/ModelBits";
import { GeoSchema, itemListSchema } from "@/components/seo/GeoSchemaHelper";
import { GlassCard } from "@/components/ui/GlassCard";
import { PageHero } from "@/components/ui/Reveal";
import { TUTORIALS } from "@/lib/data";
import { GUIDES } from "@/lib/guides";
import { CATEGORY_BY_KEY, getModel } from "@/lib/models";
import { SITE } from "@/lib/site";
import { TUTORIAL_BODIES } from "@/lib/tutorials-content";

export const metadata: Metadata = pageMeta({
  title: "Yapay Zeka Nasıl Kullanılır? Adım Adım Rehberler (2026)",
  description:
    "ChatGPT, Gemini, Claude, Copilot, Perplexity, Midjourney, Veo, ElevenLabs, Suno ve Zapier için ekran ekran, animasyonlu Türkçe kullanım rehberleri ve temel eğitimler.",
  path: "/egitimler",
  keywords: ["yapay zeka nasıl kullanılır", "chatgpt nasıl kullanılır", "yapay zeka eğitimi"],
});

const LEVEL_ACCENT = { Başlangıç: "green", Orta: "blue", İleri: "turq" } as const;

export default function TutorialsPage() {
  const basics = TUTORIALS.filter((t) => TUTORIAL_BODIES[t.slug]);
  return (
    <>
      <GeoSchema
        data={itemListSchema("Yapay zekâ rehberleri", [
          ...GUIDES.map((g) => ({ name: g.title, path: `/egitimler/${g.slug}` })),
          ...basics.map((t) => ({ name: t.title, path: `/egitimler/${t.slug}` })),
        ])}
      />
      <PageHero
        eyebrow="Öğrenme merkezi"
        title={
          <>
            Adım adım <span className="text-neon-gradient">yapay zekâ</span> rehberleri
          </>
        }
        subtitle="En çok kullanılan 10 yapay zekâ aracı için kaydırdıkça canlanan, ekran ekran anlatım. Hiç kullanmamış biri için yazıldı."
      />
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <QuickAnswer question="Yapay zekâ kullanmayı nereden öğrenmeliyim?" updated={SITE.lastReviewed}>
          <p>
            Önce bir sohbet asistanıyla (ChatGPT, Gemini veya Claude) başlayın ve iyi prompt yazmanın temel kurallarını öğrenin. Ardından ihtiyacınıza göre
            görsel (Midjourney), video (Veo), ses (ElevenLabs), müzik (Suno) veya otomasyon (Zapier) rehberine geçin. Her rehber hesap açmaktan ilk sonucu
            almaya kadar tüm adımları gösterir.
          </p>
        </QuickAnswer>

        <h2 className="mb-6 mt-12 font-display text-3xl font-bold text-white">En çok kullanılan 10 yapay zekâ aracı</h2>
        <ol className="grid gap-5 md:grid-cols-2">
          {GUIDES.map((g, i) => {
            const m = getModel(g.toolSlug);
            return (
              <li key={g.slug}>
                <Link
                  href={`/egitimler/${g.slug}`}
                  className="group glass relative flex h-full gap-5 overflow-hidden rounded-2xl p-6 transition hover:-translate-y-1 hover:border-neon-blue/50 hover:shadow-glow-blue"
                >
                  <span className="absolute right-5 top-4 font-display text-5xl font-bold text-white/[0.04]">{String(i + 1).padStart(2, "0")}</span>
                  <Monogram slug={g.toolSlug} name={g.toolName} size="lg" />
                  <span className="min-w-0">
                    <span className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      {m && (
                        <span className="chip">
                          <NeonIcon name={m.primaryCategory} className="size-3.5 text-neon-blue" />
                          {CATEGORY_BY_KEY[m.primaryCategory].short}
                        </span>
                      )}
                      {g.steps.length} adım · {g.minutes} dk · {g.level}
                    </span>
                    <span className="mt-2 block font-display text-xl font-bold text-white group-hover:text-neon-blue">{g.title}</span>
                    <span className="mt-2 line-clamp-2 block text-sm leading-6 text-slate-400">{g.metaDescription}</span>
                    <span className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-neon-turq">
                      <NeonIcon name="play" className="size-4" /> Animasyonlu rehberi aç
                    </span>
                  </span>
                </Link>
              </li>
            );
          })}
        </ol>

        <AdUnit variant="inArticle" />

        <h2 className="mb-6 mt-6 font-display text-3xl font-bold text-white">Temel eğitimler</h2>
        <ol className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {basics.map((t, i) => (
            <li key={t.slug}>
              <Link href={`/egitimler/${t.slug}`} className="block h-full">
                <GlassCard accent={LEVEL_ACCENT[t.level]} delay={i * 0.05} className="h-full">
                  <div className="flex items-center justify-between text-xs">
                    <span className="rounded-md bg-white/5 px-2 py-0.5 text-slate-300">{t.level}</span>
                    <span className="text-slate-500">{t.minutes} dk okuma</span>
                  </div>
                  <h3 className="mt-4 font-display text-lg font-semibold text-white">{t.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-400">{t.summary}</p>
                </GlassCard>
              </Link>
            </li>
          ))}
        </ol>
        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
