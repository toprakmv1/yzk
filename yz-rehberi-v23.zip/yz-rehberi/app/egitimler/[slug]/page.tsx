import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AdUnit } from "@/components/ads/AdUnit";
import { AuthorBox, CitationList, QuickAnswer } from "@/components/geo/GeoBlocks";
import { ScrollyGuide } from "@/components/guides/ScrollyGuide";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { Breadcrumbs, ContentWithSidebar } from "@/components/layout/ContentWithSidebar";
import { Monogram, PowerBar, PricingBadge } from "@/components/models/ModelBits";
import { GeoSchema, articleSchema, breadcrumbSchema, faqSchema, howToSchema } from "@/components/seo/GeoSchemaHelper";
import { NeonPromptBox } from "@/components/ui/NeonPromptBox";
import { PageHero } from "@/components/ui/Reveal";
import { TUTORIALS } from "@/lib/data";
import { GUIDES, getGuide, type Guide } from "@/lib/guides";
import { getModel, hostOf, sourceTitle } from "@/lib/models";
import { SITE } from "@/lib/site";
import { TUTORIAL_BODIES } from "@/lib/tutorials-content";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return [...GUIDES.map((g) => ({ slug: g.slug })), ...TUTORIALS.map((t) => ({ slug: t.slug }))];
}
export const dynamicParams = false;

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const g = getGuide(slug);
  if (g) {
    return pageMeta({
      title: g.title,
      description: g.metaDescription,
      path: `/egitimler/${slug}`,
      type: "article",
      section: "Rehberler",
      keywords: [`${g.toolName} nasıl kullanılır`, `${g.toolName} kullanımı`, `${g.toolName} rehberi`],
    });
  }
  const t = TUTORIALS.find((x) => x.slug === slug);
  if (!t) return {};
  const hasBody = Boolean(TUTORIAL_BODIES[slug]);
  return pageMeta({ title: t.title, description: t.summary, path: `/egitimler/${slug}`, type: "article", section: "Eğitimler", noindex: !hasBody });
}

export default async function TutorialPage({ params }: Props) {
  const { slug } = await params;
  const g = getGuide(slug);
  if (g) return <GuideView g={g} />;

  const t = TUTORIALS.find((x) => x.slug === slug);
  if (!t) notFound();
  const content = TUTORIAL_BODIES[slug];
  const path = `/egitimler/${slug}`;

  return (
    <>
      {content && (
        <GeoSchema
          data={[
            articleSchema({ title: t.title, description: t.summary, path, datePublished: "2026-01-20", dateModified: SITE.lastReviewed, section: "Eğitimler" }),
            breadcrumbSchema([
              { name: "Ana Sayfa", path: "/" },
              { name: "Eğitimler", path: "/egitimler" },
              { name: t.title, path },
            ]),
          ]}
        />
      )}
      <PageHero eyebrow={`${t.level} · ${t.minutes} dk`} title={t.title} subtitle={t.summary} />
      <ContentWithSidebar>
        <Breadcrumbs
          items={[
            { name: "Ana Sayfa", path: "/" },
            { name: "Eğitimler", path: "/egitimler" },
            { name: t.title, path },
          ]}
        />
        {content ? (
          <>
            <QuickAnswer question={t.title} updated={SITE.lastReviewed}>
              <p>{content.quick}</p>
            </QuickAnswer>
            <div className="prose-neon mt-6">{content.body}</div>
            <AdUnit variant="inArticle" />
            <AuthorBox
              name={SITE.author.name}
              role="Yapay zekâ eğitmeni"
              reviewed={SITE.lastReviewed}
              bio="Eğitimler uygulamalı testler ve resmi dokümantasyon esas alınarak hazırlanır."
            />
          </>
        ) : (
          <div className="glass rounded-2xl p-8 text-center text-slate-400">Bu eğitim hazırlanıyor. İçerik eklenene kadar arama motorlarına kapalıdır.</div>
        )}
      </ContentWithSidebar>
    </>
  );
}

function GuideView({ g }: { g: Guide }) {
  const path = `/egitimler/${g.slug}`;
  const m = getModel(g.toolSlug);
  const others = GUIDES.filter((x) => x.slug !== g.slug);
  const crumbs = [
    { name: "Ana Sayfa", path: "/" },
    { name: "Eğitimler", path: "/egitimler" },
    { name: `${g.toolName} rehberi`, path },
  ];

  return (
    <>
      <GeoSchema
        data={[
          articleSchema({
            title: g.title,
            description: g.metaDescription,
            path,
            datePublished: "2026-09-15",
            dateModified: SITE.lastReviewed,
            section: "Kullanım Rehberleri",
            citations: g.sources,
            keywords: [`${g.toolName} nasıl kullanılır`, `${g.toolName} rehberi`, g.toolName],
          }),
          howToSchema(
            `${g.toolName} nasıl kullanılır?`,
            g.steps.map((s) => ({ name: s.title, text: s.body })),
            g.minutes,
          ),
          faqSchema(g.faq),
          breadcrumbSchema(crumbs),
        ]}
      />
      <PageHero
        eyebrow={`Animasyonlu rehber · ${g.steps.length} adım · ${g.minutes} dk · ${g.level}`}
        title={
          <>
            <span className="text-neon-gradient">{g.toolName}</span> nasıl kullanılır?
          </>
        }
        subtitle={g.metaDescription}
      />

      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <Breadcrumbs items={crumbs} />
        <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px]">
          <div>
            <QuickAnswer question={`${g.toolName} nasıl kullanılır? (Kısaca)`} updated={SITE.lastReviewed}>
              <p>{g.quick}</p>
            </QuickAnswer>
            <div className="prose-neon mt-4">
              {g.intro.map((p) => (
                <p key={p.slice(0, 40)}>{p}</p>
              ))}
            </div>
          </div>
          {m && (
            <aside className="glass h-fit rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <Monogram slug={m.slug} name={m.name} />
                <div>
                  <p className="font-display text-lg font-semibold text-white">{m.name}</p>
                  <p className="text-xs text-slate-500">{m.vendor}</p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                <PricingBadge pricing={m.pricing} />
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-300">
                <strong className="text-white">Ücretsiz:</strong> {m.freeQuota}
              </p>
              <PowerBar value={m.power} className="mt-3" />
              <Link href={`/ai-araclari/${m.slug}`} className="mt-4 inline-flex items-center gap-1.5 text-sm text-neon-turq hover:underline">
                Model kartı, kota ve alternatifler <NeonIcon name="arrow" className="size-4" />
              </Link>
            </aside>
          )}
        </div>

        <AdUnit variant="leaderboard" />

        <section aria-labelledby="adimlar" className="mt-4">
          <h2 id="adimlar" className="mb-6 font-display text-3xl font-bold text-white md:text-4xl">
            Adım adım {g.toolName} kullanımı
          </h2>
          <ScrollyGuide steps={g.steps} tool={g.toolName} />
        </section>

        <div className="mx-auto mt-16 max-w-4xl">
          <AdUnit variant="inArticle" />

          <section aria-labelledby="senaryolar" className="mt-10">
            <h2 id="senaryolar" className="font-display text-3xl font-bold text-white">
              Hemen deneyin: hazır kullanım senaryoları
            </h2>
            <div className="mt-6 grid gap-5 md:grid-cols-2">
              {g.useCases.map((u, i) => (
                <NeonPromptBox key={u.title} title={u.title} prompt={u.prompt} tool={g.toolName} accent={(["turq", "blue", "green"] as const)[i % 3]} />
              ))}
            </div>
          </section>

          <AdUnit variant="rectangle" className="mt-12" />

          <section aria-labelledby="hatalar" className="mt-14 rounded-2xl border border-neon-red/30 bg-neon-red/[0.05] p-6 md:p-8">
            <h2 id="hatalar" className="flex items-center gap-3 font-display text-2xl font-bold text-white">
              <NeonIcon name="warning" className="size-6 text-neon-red" /> Yeni başlayanların sık yaptığı hatalar
            </h2>
            <ul className="mt-5 space-y-3">
              {g.mistakes.map((x) => (
                <li key={x.slice(0, 40)} className="flex gap-3 leading-7 text-slate-300">
                  <NeonIcon name="x" className="mt-1.5 size-4 shrink-0 text-neon-red" />
                  {x}
                </li>
              ))}
            </ul>
          </section>

          <section aria-labelledby="ucret" className="mt-10">
            <h2 id="ucret" className="font-display text-2xl font-bold text-white">
              Ücretsiz mi, ücretli mi?
            </h2>
            <p className="mt-4 leading-8 text-slate-300">{g.freeVsPaid}</p>
          </section>

          <AdUnit variant="inArticle" />

          <section aria-labelledby="sss" className="mt-12">
            <h2 id="sss" className="font-display text-2xl font-bold text-white">
              Sık sorulan sorular
            </h2>
            <div className="mt-5 space-y-3">
              {g.faq.map((f) => (
                <details key={f.q} className="glass group rounded-2xl p-5 open:border-neon-turq/40">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-white">
                    {f.q}
                    <span className="text-neon-turq transition group-open:rotate-45">+</span>
                  </summary>
                  <p className="mt-3 leading-7 text-slate-400">{f.a}</p>
                </details>
              ))}
            </div>
          </section>

          <CitationList items={g.sources.map((u) => ({ title: sourceTitle(u), publisher: hostOf(u), url: u }))} />
          <AuthorBox
            name={SITE.author.name}
            role="Yapay zekâ eğitmeni"
            reviewed={SITE.lastReviewed}
            bio={`Bu rehber, ${g.toolName} için resmî yardım sayfaları ve uygulamalı denemeler esas alınarak hazırlandı. Arayüz güncellendikçe adımları yeniliyoruz.`}
          />

          <section aria-labelledby="diger" className="mt-14">
            <h2 id="diger" className="font-display text-2xl font-bold text-white">
              Diğer adım adım rehberler
            </h2>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {others.map((o) => (
                <li key={o.slug}>
                  <Link href={`/egitimler/${o.slug}`} className="group glass flex items-center gap-3 rounded-xl p-3 hover:border-neon-blue/40">
                    <Monogram slug={o.toolSlug} name={o.toolName} size="sm" />
                    <span className="min-w-0">
                      <span className="block truncate font-medium text-white group-hover:text-neon-blue">{o.toolName} nasıl kullanılır?</span>
                      <span className="text-xs text-slate-500">
                        {o.steps.length} adım · {o.minutes} dk
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
          <AdUnit variant="multiplex" className="mt-12" />
        </div>
      </div>
    </>
  );
}
