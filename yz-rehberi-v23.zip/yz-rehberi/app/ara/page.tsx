import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { Suspense } from "react";
import { SearchPageClient } from "@/components/search/SearchPageClient";
import { PageHero } from "@/components/ui/Reveal";

export const metadata: Metadata = pageMeta({
  title: "Sitede Ara — Yapay Zeka Modelleri, Rehberler ve Kavramlar",
  description: "150 yapay zeka modeli, adım adım kullanım rehberleri, prompt kütüphanesi ve yapay zeka sözlüğünde arama yapın.",
  path: "/ara",
  // Arama sonuç sayfaları dizine eklenmez (ince/yinelenen içerik koruması)
  noindex: true,
});

export default function SearchPage() {
  return (
    <>
      <PageHero
        eyebrow="Arama"
        title={
          <>
            Ne <span className="text-neon-gradient">arıyorsunuz?</span>
          </>
        }
        subtitle="Model adı, iş (ör. 'video oluşturma'), kavram (ör. 'token') veya rehber arayın."
      />
      <div className="mx-auto max-w-3xl px-4 md:px-6">
        <Suspense fallback={<div className="h-14 rounded-2xl bg-white/5" />}>
          <SearchPageClient />
        </Suspense>
      </div>
    </>
  );
}
