import type { Metadata } from "next";
import Link from "next/link";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { CinematicHero } from "@/components/hero/CinematicHero";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import { CategoryTabs, type TabPanel } from "@/components/models/CategoryTabs";
import { Monogram, NewBadge, PricingBadge, RankRow, SectionHeading } from "@/components/models/ModelBits";
import { GeoSchema, faqSchema, itemListSchema } from "@/components/seo/GeoSchemaHelper";
import { NeonPromptBox } from "@/components/ui/NeonPromptBox";
import { Reveal } from "@/components/ui/Reveal";
import { MEGA_PROMPTS } from "@/lib/data";
import { GUIDES } from "@/lib/guides";
import { CATEGORIES, CATEGORY_BY_KEY, formatMonth, freeModels, modelsInCategory, newestModels, stats, toLite, topModels, type CategoryKey } from "@/lib/models";
import { pageMeta } from "@/lib/seo";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: `Yapay Zeka Araçları 2026: Ücretsiz ve En İyiler | ${SITE.name}`,
  absoluteTitle: true,
  description: SITE.description,
  path: "/",
  keywords: [
    "yapay zeka",
    "yapay zeka araçları",
    "ücretsiz yapay zeka",
    "en iyi yapay zeka",
    "yapay zeka video oluşturma",
    "yapay zeka resim oluşturma",
    "yapay zeka nasıl kullanılır",
    "chatgpt alternatifi",
  ],
});

const FREE_TABS: CategoryKey[] = ["video", "gorsel", "ses", "muzik", "sohbet", "kod", "ajan", "sunum", "avatar", "3d", "arastirma", "acik-kaynak"];

function bestFree(key: CategoryKey, n = 3) {
  return freeModels(key)
    .slice(0, n)
    .map((m) => m.name)
    .join(", ");
}

export default function HomePage() {
  const s = stats();
  const top10 = topModels(10);
  const newest = newestModels(8);

  const freePanels: TabPanel[] = FREE_TABS.map((key) => {
    const c = CATEGORY_BY_KEY[key];
    const list = freeModels(key);
    return { key, slug: c.slug, label: c.short, accent: c.accent, total: list.length, models: list.slice(0, 6).map(toLite) };
  });

  const faq = [
    {
      q: "Ücretsiz kullanılabilen en iyi yapay zekâ hangisi?",
      a: `Genel sohbet ve yazı için ${bestFree("sohbet")} ücretsiz planla kullanılabilir. Görsel için ${bestFree("gorsel")}, video için ${bestFree("video")} öne çıkar. Ücretsiz planlarda günlük/aylık kullanım limitleri vardır; her modelin sayfasında güncel kotayı bulabilirsiniz.`,
    },
    {
      q: "Yapay zekâ ile ücretsiz video nasıl oluşturulur?",
      a: `${bestFree("video", 4)} gibi araçlar günlük ücretsiz kredi verir. Genellikle hesap açıp bir metin (prompt) veya görsel yükleyerek 5–10 saniyelik klipler üretebilirsiniz; ücretsiz çıktılar çoğunlukla filigranlı ve 720p'dir.`,
    },
    {
      q: "Şu an en güçlü yapay zekâ modeli hangisi?",
      a: `Editoryal değerlendirmemize göre genel sıralamada ilk sıralarda ${top10
        .slice(0, 4)
        .map((m) => m.name)
        .join(", ")} yer alıyor. Ancak "en güçlü" model işe göre değişir: kodlama, video ve ses için kategori sıralamalarına bakın.`,
    },
    {
      q: "Token nedir, ücretsiz planlar kaç token verir?",
      a: "Token, yapay zekânın metni işlediği küçük parçalardır; Türkçede bir kelime ortalama 1,5–3 token tutar. Sohbet uygulamalarının ücretsiz planları genellikle token yerine mesaj veya oturum limiti uygular; API'lerde ise ücret 1 milyon token başına hesaplanır. Token hesaplayıcımızla metninizi ölçebilirsiniz.",
    },
    {
      q: "Yapay zekâ araçlarını bilgisayarıma kurup internetsiz kullanabilir miyim?",
      a: `Evet. ${s.open} açık ağırlıklı model, Ollama veya LM Studio gibi ücretsiz programlarla kendi bilgisayarınızda çalıştırılabilir. Güçlü bir ekran kartı veya Apple Silicon Mac performansı ciddi şekilde artırır.`,
    },
  ];

  return (
    <>
      <GeoSchema
        data={[
          faqSchema(faq),
          itemListSchema(
            "En güçlü yapay zekâ modelleri",
            top10.map((m) => ({ name: m.name, path: `/ai-araclari/${m.slug}` })),
          ),
        ]}
      />

      <CinematicHero stats={s} categories={CATEGORIES.map((c) => ({ key: c.key, slug: c.slug, short: c.short, accent: c.accent }))} />

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        {/* ================= GEO: HIZLI CEVAP ================= */}
        <Reveal className="mx-auto mt-10 max-w-4xl">
          <QuickAnswer question="Hangi yapay zekâ modelleri ücretsiz kullanılabilir?" updated={SITE.lastReviewed}>
            <p>
              Veritabanımızdaki {s.total} aktif modelden <strong>{s.free} tanesi ücretsiz</strong> kullanılabiliyor (ücretsiz plan, günlük kredi veya açık
              kaynak). Sohbet için {bestFree("sohbet")}; görsel için {bestFree("gorsel")}; video için {bestFree("video")}; seslendirme için {bestFree("ses")} en
              güçlü ücretsiz seçenekler arasında.
            </p>
          </QuickAnswer>
        </Reveal>

        <AdUnit variant="leaderboard" className="mt-14" />

        {/* ================= ÜCRETSİZ MODELLER PANELİ ================= */}
        <section aria-labelledby="ucretsiz" className="py-14">
          <Reveal>
            <SectionHeading
              id="ucretsiz"
              eyebrow="Ücretsiz modeller paneli"
              accent="text-neon-green"
              title={
                <>
                  Para ödemeden kullanın: <span className="text-glow-green text-neon-green">ücretsiz</span> yapay zekâlar
                </>
              }
              href="/ucretsiz-yapay-zeka"
              linkLabel={`Tüm ücretsizler (${s.free})`}
            />
            <p className="mt-3 max-w-2xl text-slate-400">Bir kategori seçin; en güçlü ücretsiz modeller, günlük kota ve kredi bilgisiyle listelenir.</p>
          </Reveal>
          <div className="mt-8">
            <CategoryTabs panels={freePanels} moreLabel="Bu kategoride tümü" />
          </div>
        </section>

        {/* ================= EN GÜÇLÜLER + YENİLER ================= */}
        <section aria-label="Sıralamalar" className="grid gap-6 py-10 lg:grid-cols-[1.25fr_1fr]">
          <Reveal className="glass rounded-3xl p-5 md:p-7">
            <div className="flex items-center gap-3">
              <IconTile name="crown" accent="red" />
              <div>
                <p className="eyebrow text-neon-red">Top 10</p>
                <h2 className="font-display text-2xl font-bold text-white">En güçlü yapay zekâ modelleri</h2>
              </div>
            </div>
            <ol className="mt-5 space-y-0.5">
              {top10.map((m, i) => (
                <li key={m.slug}>
                  <RankRow m={toLite(m)} rank={i + 1} />
                </li>
              ))}
            </ol>
            <Link href="/en-guclu-yapay-zeka" className="mt-4 inline-flex items-center gap-1.5 px-3 text-sm font-medium text-neon-turq hover:underline">
              Kategoriye göre sıralamalar <NeonIcon name="arrow" className="size-4" />
            </Link>
          </Reveal>

          <Reveal delay={0.08} className="glass rounded-3xl p-5 md:p-7">
            <div className="flex items-center gap-3">
              <IconTile name="fire" accent="turq" />
              <div>
                <p className="eyebrow text-neon-turq">Yeni çıkanlar</p>
                <h2 className="font-display text-2xl font-bold text-white">Son eklenen modeller</h2>
              </div>
            </div>
            <ol className="relative mt-6 space-y-4 border-l border-white/10 pl-5">
              {newest.map((m) => (
                <li key={m.slug} className="relative">
                  <span aria-hidden className="absolute -left-[25px] top-2 size-2.5 rounded-full bg-neon-turq shadow-glow-turq" />
                  <Link href={`/ai-araclari/${m.slug}`} className="group flex items-center gap-3">
                    <Monogram slug={m.slug} name={m.name} size="sm" />
                    <span className="min-w-0">
                      <span className="flex items-center gap-2">
                        <span className="truncate font-semibold text-white group-hover:text-neon-turq">{m.name}</span>
                        <span className="text-xs text-slate-500">{formatMonth(m.released)}</span>
                      </span>
                      <span className="block truncate text-xs text-slate-400">{m.latestVersion}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ol>
            <Link href="/yeni-yapay-zeka-modelleri" className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-neon-turq hover:underline">
              Tüm yeni modeller <NeonIcon name="arrow" className="size-4" />
            </Link>
          </Reveal>
        </section>

        <AdUnit variant="rectangle" />

        {/* ================= KATEGORİ LİDERLERİ ================= */}
        <section aria-labelledby="kategoriler" className="py-14">
          <Reveal>
            <SectionHeading
              id="kategoriler"
              eyebrow="Ne yapmak istiyorsunuz?"
              title={
                <>
                  Kategorilere göre <span className="text-neon-gradient">en iyiler</span>
                </>
              }
              href="/ai-araclari"
              linkLabel="Tüm modeller"
            />
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {CATEGORIES.map((c, i) => {
              const list = modelsInCategory(c.key);
              return (
                <Reveal key={c.key} delay={(i % 3) * 0.06} className="glass flex flex-col rounded-2xl p-4">
                  <Link href={`/kategori/${c.slug}`} className="group flex items-center gap-3 px-1">
                    <IconTile name={c.key} accent={c.accent} />
                    <span className="min-w-0 flex-1">
                      <span className="block font-display text-lg font-semibold text-white group-hover:text-neon-turq">{c.label}</span>
                      <span className="block text-xs text-slate-500">
                        {list.length} model · {list.filter((m) => m.pricing !== "ucretli").length} ücretsiz erişim
                      </span>
                    </span>
                    <NeonIcon name="arrow" className="size-4 text-slate-500 transition group-hover:translate-x-1 group-hover:text-neon-turq" />
                  </Link>
                  <ol className="mt-3">
                    {list.slice(0, 3).map((m, r) => (
                      <li key={m.slug}>
                        <RankRow m={toLite(m)} rank={r + 1} compact />
                      </li>
                    ))}
                  </ol>
                </Reveal>
              );
            })}
          </div>
        </section>

        <AdUnit variant="inArticle" />

        {/* ================= ADIM ADIM REHBERLER ================= */}
        <section aria-labelledby="rehberler" className="py-14">
          <Reveal>
            <SectionHeading
              id="rehberler"
              eyebrow="Animasyonlu, adım adım"
              accent="text-neon-blue"
              title={
                <>
                  En çok kullanılan 10 yapay zekâ: <span className="text-neon-gradient">nasıl kullanılır?</span>
                </>
              }
              href="/egitimler"
              linkLabel="Tüm rehberler"
            />
            <p className="mt-3 max-w-2xl text-slate-400">Her adım, kaydırdıkça canlanan ekran animasyonlarıyla anlatılır. Hiç kullanmamış biri için yazıldı.</p>
          </Reveal>
          <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {GUIDES.map((g, i) => (
              <Reveal as="li" key={g.slug} delay={(i % 5) * 0.05}>
                <Link
                  href={`/egitimler/${g.slug}`}
                  className="group glass flex h-full flex-col rounded-2xl p-4 transition hover:-translate-y-1 hover:border-neon-blue/50"
                >
                  <div className="flex items-center justify-between">
                    <Monogram slug={g.toolSlug} name={g.toolName} size="sm" />
                    <span className="font-mono text-xs text-slate-500">{String(i + 1).padStart(2, "0")}</span>
                  </div>
                  <h3 className="mt-3 font-semibold leading-snug text-white group-hover:text-neon-blue">{g.toolName} nasıl kullanılır?</h3>
                  <p className="mt-1 text-xs text-slate-500">
                    {g.steps.length} adım · {g.minutes} dk · {g.level}
                  </p>
                  <span className="mt-auto inline-flex items-center gap-1 pt-3 text-xs font-medium text-neon-blue">
                    <NeonIcon name="play" className="size-3.5" /> Rehberi başlat
                  </span>
                </Link>
              </Reveal>
            ))}
          </ol>
        </section>

        {/* ================= ARAÇLAR ================= */}
        <section aria-label="Ücretsiz araçlar" className="grid gap-4 py-8 md:grid-cols-2 lg:grid-cols-4">
          {[
            {
              href: "/hangi-yapay-zeka",
              icon: "compass" as const,
              accent: "turq" as const,
              title: "Hangi yapay zekâ bana uygun?",
              text: "3 soruyu yanıtlayın, size özel öneri listesi alın.",
            },
            {
              href: "/karsilastir",
              icon: "compare" as const,
              accent: "blue" as const,
              title: "Modelleri karşılaştır",
              text: "Ücretsiz kota, fiyat, Türkçe desteği yan yana.",
            },
            {
              href: "/araclar/token-hesaplama",
              icon: "token" as const,
              accent: "green" as const,
              title: "Token & API maliyeti",
              text: "Metninizin kaç token tuttuğunu ve maliyetini görün.",
            },
            {
              href: "/sozluk",
              icon: "book" as const,
              accent: "red" as const,
              title: "Yapay zekâ sözlüğü",
              text: "LLM, RAG, MCP, token… sade Türkçe tanımlar.",
            },
          ].map((t, i) => (
            <Reveal key={t.href} delay={i * 0.06}>
              <Link
                href={t.href}
                className="group glass flex h-full items-start gap-4 rounded-2xl p-5 transition hover:-translate-y-1 hover:border-neon-turq/40"
              >
                <IconTile name={t.icon} accent={t.accent} />
                <span>
                  <span className="block font-semibold text-white group-hover:text-neon-turq">{t.title}</span>
                  <span className="mt-1 block text-sm leading-6 text-slate-400">{t.text}</span>
                </span>
              </Link>
            </Reveal>
          ))}
        </section>

        {/* ================= PROMPT VİTRİNİ ================= */}
        <section aria-labelledby="promptlar" className="py-14">
          <Reveal>
            <SectionHeading
              id="promptlar"
              eyebrow="Kopyala · Yapıştır · Üret"
              accent="text-neon-green"
              title="Öne çıkan mega promptlar"
              href="/mega-promptlar"
              linkLabel="Prompt kütüphanesi"
            />
          </Reveal>
          <div className="mt-8 grid gap-5 lg:grid-cols-3">
            {MEGA_PROMPTS.slice(0, 3).map((p, i) => (
              <NeonPromptBox key={p.id} {...p} accent={(["blue", "turq", "green"] as const)[i % 3]} delay={i * 0.08} />
            ))}
          </div>
        </section>

        <AdUnit variant="inArticle" />

        {/* ================= SON EKLENEN ÜCRETSİZLER (ızgara) ================= */}
        <section aria-labelledby="hizli-bakis" className="py-10">
          <Reveal>
            <h2 id="hizli-bakis" className="font-display text-2xl font-bold text-white">
              Hızlı bakış: yeni ve ücretsiz
            </h2>
          </Reveal>
          <ul className="mt-6 flex flex-wrap gap-2">
            {newest
              .concat(topModels(30).filter((m) => m.pricing !== "ucretli"))
              .filter((m, i, arr) => arr.findIndex((x) => x.slug === m.slug) === i)
              .slice(0, 24)
              .map((m) => (
                <li key={m.slug}>
                  <Link
                    href={`/ai-araclari/${m.slug}`}
                    className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-slate-200 transition hover:border-neon-turq/50 hover:text-white"
                  >
                    <NeonIcon name={m.primaryCategory} className="size-4 text-neon-turq" />
                    {m.name}
                    {m.isNew ? <NewBadge /> : <PricingBadge pricing={m.pricing} />}
                  </Link>
                </li>
              ))}
          </ul>
        </section>

        {/* ================= SSS (FAQPage şeması ile eşleşir) ================= */}
        <section aria-labelledby="sss" className="mx-auto max-w-3xl py-14">
          <h2 id="sss" className="text-center font-display text-3xl font-bold text-white">
            Sık sorulan sorular
          </h2>
          <div className="mt-8 space-y-3">
            {faq.map((f) => (
              <details key={f.q} className="glass group rounded-2xl p-5 open:border-neon-turq/40">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-white">
                  {f.q}
                  <span className="text-neon-turq transition group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 leading-7 text-slate-400">{f.a}</p>
              </details>
            ))}
          </div>
        </section>

        <AdUnit variant="multiplex" />
      </div>
    </>
  );
}
