import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { IconTile } from "@/components/icons/NeonIcon";
import { RankRow } from "@/components/models/ModelBits";
import { RankTable } from "@/components/models/RankTable";
import { GeoSchema, breadcrumbSchema, itemListSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { CATEGORIES, formatMonth, modelsInCategory, toLite, topModels } from "@/lib/models";
import { SITE } from "@/lib/site";

const MONTH = formatMonth(SITE.lastReviewed.slice(0, 7));

export const metadata: Metadata = pageMeta({
  title: `En İyi ve En Güçlü Yapay Zeka Modelleri (${MONTH})`,
  description:
    "Sohbet, kod, görsel, video, ses ve müzikte en güçlü yapay zeka modelleri sıralaması. Editoryal güç puanı, ücretsiz erişim ve Türkçe desteğiyle kategoriye göre top listeler.",
  path: "/en-guclu-yapay-zeka",
  keywords: ["en iyi yapay zeka", "en güçlü yapay zeka", "en iyi yapay zeka 2026"],
});

export default function StrongestPage() {
  const top = topModels(25);
  return (
    <>
      <GeoSchema
        data={[
          itemListSchema(
            "En güçlü yapay zekâ modelleri",
            top.map((m) => ({ name: m.name, path: `/ai-araclari/${m.slug}` })),
          ),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "En Güçlü Yapay Zekâ", path: "/en-guclu-yapay-zeka" },
          ]),
        ]}
      />
      <PageHero
        eyebrow={`${MONTH} sıralaması`}
        title={
          <>
            En <span className="text-glow-red text-neon-red">güçlü</span> yapay zekâ modelleri
          </>
        }
        subtitle="Genel top 25 ve her kategorinin liderleri. Güç puanı; kalite, yetenek seti, hız ve güncelliğe göre verilen editoryal bir değerlendirmedir."
      />
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <QuickAnswer question="Şu anda en güçlü yapay zekâ hangisi?" updated={SITE.lastReviewed}>
          <p>
            Genel sıralamada ilk beş:{" "}
            {top
              .slice(0, 5)
              .map((m, i) => `${i + 1}) ${m.name}`)
              .join(", ")}
            . Yine de &quot;en güçlü&quot; işe göre değişir — kodlama, video veya ses için aşağıdaki kategori liderlerine bakın.
          </p>
        </QuickAnswer>

        <AdUnit variant="leaderboard" />

        <h2 className="mb-5 font-display text-2xl font-bold text-white md:text-3xl">Genel Top 25</h2>
        <RankTable models={top} caption="En güçlü 25 yapay zekâ modeli" showCategory />

        <AdUnit variant="inArticle" />

        <h2 className="mb-6 mt-4 font-display text-2xl font-bold text-white md:text-3xl">Kategori liderleri</h2>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {CATEGORIES.map((c) => {
            const list = modelsInCategory(c.key).slice(0, 5);
            return (
              <section key={c.key} aria-labelledby={`lid-${c.key}`} className="glass rounded-2xl p-4">
                <Link href={`/kategori/${c.slug}`} className="group flex items-center gap-3 px-1">
                  <IconTile name={c.key} accent={c.accent} />
                  <h3 id={`lid-${c.key}`} className="font-display text-lg font-semibold text-white group-hover:text-neon-turq">
                    {c.label}
                  </h3>
                </Link>
                <ol className="mt-3">
                  {list.map((m, i) => (
                    <li key={m.slug}>
                      <RankRow m={toLite(m)} rank={i + 1} compact />
                    </li>
                  ))}
                </ol>
              </section>
            );
          })}
        </div>

        <section className="glass mt-12 rounded-2xl p-6 text-sm leading-7 text-slate-400">
          <h2 className="font-display text-lg font-semibold text-white">Puanlama yöntemi</h2>
          <p className="mt-2">
            Güç puanı (0–100), her modelin kendi kategorisindeki rakiplerine göre çıktı kalitesi, yetenek genişliği (ör. çok modluluk, ajan özellikleri), hız,
            bağlam/çözünürlük gibi teknik sınırlar ve güncelliği dikkate alınarak editörlerimiz tarafından verilir. Mümkün olduğunda bağımsız karşılaştırma
            tabloları (ör. LMArena, Artificial Analysis) ve resmi duyurular dikkate alınır; puanlar her veri güncellemesinde yeniden gözden geçirilir. Farklı
            kategorilerdeki puanlar birbirleriyle doğrudan karşılaştırılmamalıdır.
          </p>
        </section>
        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
