import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { Monogram, PricingBadge } from "@/components/models/ModelBits";
import { GeoSchema, breadcrumbSchema, itemListSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { CATEGORY_BY_KEY, MODELS, formatMonth, isActive } from "@/lib/models";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: `Yeni Çıkan Yapay Zeka Modelleri (${formatMonth(SITE.lastReviewed.slice(0, 7))}) — Güncel Liste`,
  description: "Son aylarda çıkan ve büyük güncelleme alan yapay zeka modelleri: sürümler, ücretsiz erişim ve neler değişti. Aylara göre zaman çizelgesi.",
  path: "/yeni-yapay-zeka-modelleri",
  keywords: ["yeni yapay zeka", "yeni çıkan yapay zeka", "yapay zeka haberleri"],
});

export default function NewModelsPage() {
  const recent = MODELS.filter((m) => isActive(m) && m.released >= "2026-04").sort((a, b) => b.released.localeCompare(a.released) || b.power - a.power);
  const groups = new Map<string, typeof recent>();
  for (const m of recent) groups.set(m.released, [...(groups.get(m.released) ?? []), m]);
  const months = Array.from(groups.keys());

  return (
    <>
      <GeoSchema
        data={[
          itemListSchema(
            "Yeni çıkan yapay zekâ modelleri",
            recent.slice(0, 40).map((m) => ({ name: m.name, path: `/ai-araclari/${m.slug}` })),
          ),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Yeni Yapay Zekâ Modelleri", path: "/yeni-yapay-zeka-modelleri" },
          ]),
        ]}
      />
      <PageHero
        eyebrow="Zaman çizelgesi"
        title={
          <>
            Yeni çıkan <span className="text-neon-gradient">yapay zekâ</span> modelleri
          </>
        }
        subtitle={`Son 6 ayda çıkan veya büyük sürüm güncellemesi alan ${recent.length} model, aylara göre.`}
      />
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <QuickAnswer question="En son hangi yapay zekâ modelleri çıktı?" updated={SITE.lastReviewed}>
          <p>
            {formatMonth(months[0] ?? "")} itibarıyla en yeni güncellemeler:{" "}
            {(groups.get(months[0]) ?? [])
              .slice(0, 6)
              .map((m) => `${m.name} (${m.latestVersion})`)
              .join(", ")}
            .
          </p>
        </QuickAnswer>
        <AdUnit variant="leaderboard" />

        <div className="relative mt-6 border-l border-white/10 pl-6 md:pl-10">
          {months.map((mo, gi) => (
            <section key={mo} aria-labelledby={`ay-${mo}`} className="relative pb-12">
              <span aria-hidden className="absolute -left-[31px] top-1.5 size-3 rounded-full bg-neon-red shadow-glow-red md:-left-[47px]" />
              <h2 id={`ay-${mo}`} className="font-display text-2xl font-bold text-white">
                {formatMonth(mo)} <span className="text-base font-normal text-slate-500">· {groups.get(mo)!.length} model</span>
              </h2>
              <ul className="mt-5 space-y-3">
                {groups.get(mo)!.map((m) => (
                  <li key={m.slug}>
                    <Link href={`/ai-araclari/${m.slug}`} className="group glass flex gap-4 rounded-2xl p-4 transition hover:border-neon-turq/40">
                      <Monogram slug={m.slug} name={m.name} />
                      <span className="min-w-0 flex-1">
                        <span className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-white group-hover:text-neon-turq">{m.name}</span>
                          <PricingBadge pricing={m.pricing} />
                          <span className="chip">
                            <NeonIcon name={m.primaryCategory} className="size-3.5 text-neon-blue" />
                            {CATEGORY_BY_KEY[m.primaryCategory].short}
                          </span>
                        </span>
                        <span className="mt-1 block text-sm text-neon-turq">{m.latestVersion}</span>
                        <span className="mt-1 line-clamp-2 block text-sm leading-6 text-slate-400">{m.description}</span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
              {gi % 2 === 0 && <AdUnit variant={gi % 4 === 0 ? "inArticle" : "rectangle"} />}
            </section>
          ))}
        </div>
        <AdUnit variant="multiplex" />
      </div>
    </>
  );
}
