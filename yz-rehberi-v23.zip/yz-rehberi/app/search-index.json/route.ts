import { buildSearchIndex } from "@/lib/search-index";

/** Derleme zamanında statik üretilir; arama penceresi ilk açılışta bu dosyayı yükler. */
export const dynamic = "force-static";

export function GET() {
  return new Response(JSON.stringify(buildSearchIndex()), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400",
      "X-Robots-Tag": "noindex",
    },
  });
}
