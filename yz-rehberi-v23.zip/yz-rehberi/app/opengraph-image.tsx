import { ImageResponse } from "next/og";
import { SITE } from "@/lib/site";

export const alt = `${SITE.name} — Ücretsiz ve En Güçlü Yapay Zekâ Modelleri`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Varsayılan sosyal paylaşım görseli (build'de otomatik üretilir) */
export default function OpengraphImage() {
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        padding: 80,
        background: "radial-gradient(circle at 75% 35%, #00473f 0%, #020a14 60%)",
        color: "white",
      }}
    >
      <div style={{ fontSize: 30, color: "#3dff8f", letterSpacing: 4 }}>EKİM 2026 · 140+ MODEL</div>
      <div style={{ fontSize: 84, fontWeight: 800, marginTop: 20, lineHeight: 1.05 }}>Hangi yapay zekâ ücretsiz, hangisi en güçlü?</div>
      <div style={{ fontSize: 32, color: "#5cd6ff", marginTop: 30 }}>Video · Görsel · Ses · Müzik · Kod · Adım adım rehberler</div>
      <div
        style={{ display: "flex", marginTop: 40, height: 8, width: 520, borderRadius: 8, background: "linear-gradient(90deg,#00f5d4,#5cd6ff,#3dff8f,#ff4566)" }}
      />
    </div>,
    size,
  );
}
