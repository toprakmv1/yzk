import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { AdUnit } from "@/components/ads/AdUnit";
import { PromptLibrary } from "@/components/content/PromptLibrary";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { GeoSchema, faqSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { ALL_PROMPTS } from "@/lib/prompts";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: `${ALL_PROMPTS.length}+ Hazır Yapay Zeka Promptu (Türkçe) — Kopyala, Kullan`,
  description:
    "ChatGPT, Claude, Gemini, Midjourney, Suno, Kling ve 150 yapay zeka için görsel, video, müzik, kod ve iş promptları. Kopyala-yapıştır hazır, Türkçe açıklamalı.",
  path: "/mega-promptlar",
  keywords: ["chatgpt promptları", "midjourney prompt", "yapay zeka prompt örnekleri", "türkçe prompt"],
});

const FAQ = [
  {
    q: "Mega prompt nedir?",
    a: "Mega prompt; rol, bağlam, adımlar, kurallar ve çıktı biçimini tek seferde tanımlayan, tekrar kullanılabilir uzun ve yapılandırılmış yapay zekâ talimatıdır.",
  },
  {
    q: "Köşeli parantezli alanlar ne anlama geliyor?",
    a: "[KANAL ADI] gibi köşeli parantez içindeki ifadeler, kopyaladıktan sonra kendi bilgilerinizle değiştirmeniz gereken yer tutuculardır.",
  },
];

export default function PromptsPage() {
  return (
    <>
      <GeoSchema data={faqSchema(FAQ)} />
      <PageHero
        eyebrow="Kopyala · Yapıştır · Üret"
        title={
          <>
            <span className="text-neon-gradient">Mega Prompt</span> Kütüphanesi
          </>
        }
        subtitle={`${ALL_PROMPTS.length} hazır prompt: görsel, video, müzik, kod, iş ve günlük kullanım. Tek tıkla kopyalayın.`}
      />
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <QuickAnswer question="İyi bir prompt nasıl yazılır?" updated={SITE.lastReviewed}>
          <p>
            İyi bir prompt altı parçadan oluşur: <strong>rol</strong> (sen bir … uzmanısın), <strong>bağlam</strong>, <strong>görev</strong>,{" "}
            <strong>kurallar/kısıtlar</strong>, <strong>çıktı biçimi</strong> ve mümkünse bir <strong>örnek</strong>. Aşağıdaki promptlarda köşeli parantezli
            alanları kendi bilgilerinizle doldurmanız yeterlidir.
          </p>
        </QuickAnswer>
        <AdUnit variant="leaderboard" />
        <PromptLibrary prompts={ALL_PROMPTS} />
      </div>
    </>
  );
}
