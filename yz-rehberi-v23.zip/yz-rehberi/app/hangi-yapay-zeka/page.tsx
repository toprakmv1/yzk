import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { GeoSchema, breadcrumbSchema, faqSchema, softwareAppSchema } from "@/components/seo/GeoSchemaHelper";
import { AiWizard } from "@/components/tools/AiWizard";
import { PageHero } from "@/components/ui/Reveal";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Hangi Yapay Zekayı Kullanmalıyım? 4 Soruluk Öneri Testi",
  description: "Amacınızı, bütçenizi ve dil tercihinizi seçin; 150 model arasından size en uygun ücretsiz veya ücretli yapay zeka araçlarını önerelim.",
  path: "/hangi-yapay-zeka",
});

const FAQ = [
  {
    q: "Yeni başlayanlar için en kolay yapay zekâ hangisi?",
    a: "Genel işler için ChatGPT, Gemini veya Claude gibi web ve mobil uygulaması olan sohbet asistanları en kolay başlangıçtır; kurulum gerektirmez ve Türkçeyi iyi anlar.",
  },
  {
    q: "Ücretsiz bir yapay zekâ işimi görür mü?",
    a: "Çoğu günlük iş için evet. Ücretsiz planlar mesaj, kredi veya çözünürlük sınırlarıyla gelir; yoğun ve ticari kullanımda ücretli plan gerekebilir.",
  },
  {
    q: "Verilerimin gizli kalmasını istiyorum, ne yapmalıyım?",
    a: "Açık kaynak modelleri Ollama veya LM Studio ile kendi bilgisayarınızda çalıştırın; böylece verileriniz cihazınızdan çıkmaz. Bulut araçlarında ise ayarlardan model eğitimine veri paylaşımını kapatın.",
  },
];

export default function WizardPage() {
  return (
    <>
      <GeoSchema
        data={[
          softwareAppSchema({
            name: "Hangi Yapay Zekâ? Öneri Sihirbazı",
            description: "Kullanıcının amacına, bütçesine ve diline göre yapay zekâ aracı öneren ücretsiz araç",
            path: "/hangi-yapay-zeka",
            category: "UtilitiesApplication",
          }),
          faqSchema(FAQ),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Hangi Yapay Zekâ?", path: "/hangi-yapay-zeka" },
          ]),
        ]}
      />
      <PageHero
        eyebrow="Öneri sihirbazı"
        title={
          <>
            Hangi yapay zekâ <span className="text-neon-gradient">size uygun?</span>
          </>
        }
        subtitle="4 kısa soruyu yanıtlayın; 140+ model arasından ihtiyacınıza en uygun 5 aracı sıralayalım."
      />
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <AiWizard />
        <AdUnit variant="inArticle" className="mt-12" />
        <QuickAnswer question="Hangi yapay zekâyı kullanmalıyım?" updated={SITE.lastReviewed}>
          <p>
            Önce ne yapmak istediğinizi belirleyin: metin için sohbet asistanı, görsel için metinden-görsel modeli, video için video modeli. Sonra bütçenize
            (ücretsiz/ücretli/açık kaynak) ve Türkçe ihtiyacınıza göre daraltın. Sihirbaz bu üç kriteri editoryal güç puanıyla birleştirerek sıralar.
          </p>
        </QuickAnswer>
        <section className="mx-auto mt-12 max-w-3xl space-y-3">
          {FAQ.map((f) => (
            <details key={f.q} className="glass group rounded-2xl p-5 open:border-neon-turq/40">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-white">
                {f.q}
                <span className="text-neon-turq transition group-open:rotate-45">+</span>
              </summary>
              <p className="mt-3 leading-7 text-slate-400">{f.a}</p>
            </details>
          ))}
        </section>
        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
