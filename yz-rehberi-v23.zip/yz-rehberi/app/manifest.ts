import type { MetadataRoute } from "next";
import { SITE } from "@/lib/site";

/** Web uygulama bildirimi (PWA) — mobilde "Ana ekrana ekle" ve marka rengi */
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: `${SITE.name} — Yapay Zeka Araçları ve Rehberleri`,
    short_name: SITE.name,
    description: SITE.description,
    start_url: "/",
    display: "standalone",
    background_color: "#020a14",
    theme_color: "#020a14",
    lang: "tr-TR",
    dir: "ltr",
    categories: ["education", "productivity", "utilities"],
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icon-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
