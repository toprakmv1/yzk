import { ImageResponse } from "next/og";
import { CATEGORY_BY_KEY, MODELS, PRICING_LABEL, getModel } from "@/lib/models";

export const alt = "Yapay zekâ modeli inceleme kartı";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export function generateStaticParams() {
  return MODELS.map((m) => ({ slug: m.slug }));
}

/** Her model için otomatik sosyal paylaşım görseli (sosyal medyada tıklanma oranını artırır) */
export default async function ModelOgImage({ params }: { params: { slug: string } | Promise<{ slug: string }> }) {
  // Next 15: düz nesne, Next 16+: Promise — ikisini de destekle
  const { slug } = await Promise.resolve(params);
  const m = getModel(slug);
  const name = m?.name ?? "Yapay Zekâ Modeli";
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: 72,
        background: "radial-gradient(circle at 80% 20%, #003d36 0%, #020a14 60%)",
        color: "white",
      }}
    >
      <div style={{ display: "flex", fontSize: 28, color: "#00f5d4", letterSpacing: 3 }}>
        YZ REHBERİ · {m ? CATEGORY_BY_KEY[m.primaryCategory].label.toUpperCase() : ""}
      </div>
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ fontSize: 96, fontWeight: 800, lineHeight: 1 }}>{name}</div>
        <div style={{ fontSize: 36, color: "#cfe9ff", marginTop: 24, maxWidth: 1000 }}>{m?.tagline ?? ""}</div>
      </div>
      <div style={{ display: "flex", gap: 24, fontSize: 30 }}>
        <div style={{ display: "flex", padding: "10px 22px", borderRadius: 14, border: "2px solid #3dff8f", color: "#3dff8f" }}>
          {m ? PRICING_LABEL[m.pricing] : ""}
        </div>
        <div style={{ display: "flex", padding: "10px 22px", borderRadius: 14, border: "2px solid #5cd6ff", color: "#5cd6ff" }}>Güç {m?.power ?? ""}/100</div>
        <div style={{ display: "flex", padding: "10px 22px", borderRadius: 14, border: "2px solid #ff4566", color: "#ff4566" }}>Nasıl kullanılır?</div>
      </div>
    </div>,
    size,
  );
}
