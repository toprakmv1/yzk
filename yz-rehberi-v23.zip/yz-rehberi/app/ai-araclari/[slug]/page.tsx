import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AdUnit } from "@/components/ads/AdUnit";
import { AuthorBox, CitationList, QuickAnswer } from "@/components/geo/GeoBlocks";
import { IconTile, NeonIcon, type IconName } from "@/components/icons/NeonIcon";
import { Breadcrumbs, ContentWithSidebar } from "@/components/layout/ContentWithSidebar";
import { ClosedBadge, ModelCard, Monogram, NewBadge, PowerBar, PricingBadge } from "@/components/models/ModelBits";
import { GeoSchema, articleSchema, breadcrumbSchema, faqSchema, howToSchema, productReviewSchema } from "@/components/seo/GeoSchemaHelper";
import { NeonPromptBox } from "@/components/ui/NeonPromptBox";
import { pairsFor } from "@/lib/compare-pairs";
import { guideForTool } from "@/lib/guides";
import {
  CATEGORY_BY_KEY,
  MODELS,
  PRICING_LABEL,
  alternativesFor,
  formatMonth,
  getModel,
  hostOf,
  rankInCategory,
  sourceTitle,
  toLite,
  type Model,
} from "@/lib/models";
import { SITE } from "@/lib/site";
import { cn } from "@/lib/cn";

type Props = { params: Promise<{ slug: string }> };

/** pSEO: tüm model sayfaları derleme zamanında statik üretilir (SSG) */
export function generateStaticParams() {
  return MODELS.map((m) => ({ slug: m.slug }));
}
export const dynamicParams = false;

const TURKISH_TEXT: Record<string, string> = {
  iyi: "Evet. Türkçe istemleri iyi anlar ve akıcı Türkçe çıktı üretir.",
  orta: "Kısmen. Türkçe istemleri anlar ancak çıktı kalitesi İngilizceye göre daha düşük olabilir; önemli işlerde İngilizce prompt denemek faydalı olur.",
  zayıf: "Sınırlı. Türkçe desteği zayıf veya resmi olarak belirtilmemiş; en iyi sonuç için İngilizce prompt kullanın.",
};

function freeAnswer(m: Model) {
  if (m.status === "kapandi") return `${m.name} artık hizmet vermiyor. ${m.freeTier}`;
  switch (m.pricing) {
    case "ucretsiz":
      return `Evet, ${m.name} tamamen ücretsizdir. ${m.freeTier}`;
    case "acik-kaynak":
      return `Evet, ${m.name} açık kaynaktır; kendi donanımınızda ücretsiz çalıştırabilirsiniz. ${m.freeTier}`;
    case "freemium":
      return `Evet, ${m.name} için ücretsiz bir plan var. ${m.freeTier}${m.paidFrom ? ` Ücretli planlar ${m.paidFrom} seviyesinden başlıyor.` : ""}`;
    default:
      return `Hayır, ${m.name} ücretli bir araçtır. ${m.freeTier}${m.paidFrom ? ` Fiyatlar ${m.paidFrom} seviyesinden başlıyor.` : ""}`;
  }
}

function buildFaq(m: Model, alts: Model[]) {
  const faq = [
    { q: `${m.name} ücretsiz mi?`, a: freeAnswer(m) },
    {
      q: `${m.name} ücretsiz planda ne kadar kullanılabilir? Kaç token veya kredi veriyor?`,
      a: `Ücretsiz kullanım: ${m.freeQuota}.${m.apiFree ? ` API tarafında: ${m.apiFree}` : ""} Limitler yoğunluğa ve bölgeye göre değişebileceği için güncel değeri ${hostOf(m.url)} üzerinden doğrulayın.`,
    },
    { q: `${m.name} Türkçe destekliyor mu?`, a: TURKISH_TEXT[m.turkish] ?? `Türkçe desteği: ${m.turkish}.` },
    { q: `${m.name} nasıl kullanılır?`, a: m.howTo.slice(0, 3).join(" ") },
  ];
  if (m.platforms?.length) faq.push({ q: `${m.name} hangi cihazlarda çalışır?`, a: `${m.name} şu platformlarda kullanılabilir: ${m.platforms.join(", ")}.` });
  if (alts.length)
    faq.push({
      q: `${m.name} alternatifleri nelerdir?`,
      a: `Benzer işler için ${alts
        .slice(0, 4)
        .map((a) => `${a.name} (${PRICING_LABEL[a.pricing].toLowerCase()})`)
        .join(", ")} değerlendirilebilir.`,
    });
  return faq;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const m = getModel(slug);
  if (!m) return {};
  // Kısa, tıklanabilir başlık (Google ≈60 karakter gösterir): marka adı + en çok aranan soru kalıpları
  const short = m.name.replace(/\s*\(.*?\)\s*/g, " ").trim();
  const variants =
    m.status === "kapandi"
      ? [`${short} Kapandı mı? Yerine Kullanılabilecek Alternatifler`, `${short} Kapandı mı? Alternatifler`]
      : m.pricing === "ucretli"
        ? [`${short} Nedir, Fiyatı Ne Kadar? Nasıl Kullanılır (2026)`, `${short} Fiyatı ve Kullanımı (2026)`, `${short} Fiyatı ve Kullanımı`]
        : [`${short} Ücretsiz mi? Nasıl Kullanılır, Kota ve Alternatifler`, `${short} Ücretsiz mi? Nasıl Kullanılır (2026)`, `${short} Ücretsiz mi? Nasıl Kullanılır`];
  // Site adı ekiyle birlikte ≈65 karakteri aşmayan en zengin varyantı seç
  const title = variants.find((t) => t.length + SITE.name.length + 3 <= 66) ?? variants[variants.length - 1];
  const description = `${m.name}: ${m.tagline.replace(/\.$/, "")}. ${
    m.freeQuota ? `Ücretsiz kullanım: ${m.freeQuota}. ` : ""
  }Adım adım kullanım, ipuçları, Türkçe desteği ve alternatifler.`;
  return pageMeta({
    title,
    description,
    path: `/ai-araclari/${m.slug}`,
    type: "article",
    publishedTime: "2026-01-10",
    section: CATEGORY_BY_KEY[m.primaryCategory]?.label,
    keywords: [m.name, `${m.name} ücretsiz mi`, `${m.name} nasıl kullanılır`, `${m.name} alternatifleri`, m.vendor],
  });
}

export default async function ModelPage({ params }: Props) {
  const { slug } = await params;
  const m = getModel(slug);
  if (!m) notFound();
  const path = `/ai-araclari/${m.slug}`;
  const cat = CATEGORY_BY_KEY[m.primaryCategory];
  const rank = rankInCategory(m);
  const alts = alternativesFor(m, 6);
  const guide = guideForTool(m.slug);
  const faq = buildFaq(m, alts);
  const closed = m.status === "kapandi";
  // İç linkleme: bu modelin yer aldığı statik "A vs B" sayfaları (dizine eklenebilir)
  const pairLinks = pairsFor(m.slug, 6)
    .map((p) => {
      const other = getModel(p.a === m.slug ? p.b : p.a);
      return other ? { href: `/karsilastir/${p.slug}`, other: other.slug, label: `${getModel(p.a)?.name} vs ${getModel(p.b)?.name}` } : null;
    })
    .filter((x): x is { href: string; other: string; label: string } => x !== null);

  const facts: { icon: IconName; label: string; value: string; accent?: string }[] = [
    { icon: "gift", label: "Fiyat modeli", value: closed ? "Hizmet dışı" : PRICING_LABEL[m.pricing], accent: "text-neon-green" },
    { icon: "bolt", label: "Ücretsiz kota", value: m.freeQuota || "—" },
    { icon: "star", label: "Ücretli plan", value: m.paidFrom ?? (m.pricing === "acik-kaynak" ? "Gerekmez (kendi donanımınız)" : "Resmi sitede belirtilmiyor") },
    { icon: "token", label: "API / token", value: m.apiFree ?? "Herkese açık API yok" },
    { icon: "cpu", label: "Son sürüm", value: m.latestVersion },
    { icon: "clock", label: "Son güncelleme", value: formatMonth(m.released) },
    { icon: "globe", label: "Türkçe desteği", value: m.turkish === "iyi" ? "İyi" : m.turkish === "orta" ? "Orta" : "Zayıf" },
    { icon: "layers", label: "Platformlar", value: m.platforms?.join(", ") || "Web" },
    { icon: "acik-kaynak", label: "Açık ağırlık", value: m.openWeights ? "Evet (indirilebilir)" : "Hayır" },
  ];

  return (
    <>
      <GeoSchema
        data={[
          articleSchema({
            title: `${m.name} nedir, nasıl kullanılır?`,
            description: m.description,
            path,
            datePublished: "2026-01-10",
            dateModified: SITE.lastReviewed,
            section: cat?.label ?? "YZ Araçları",
            citations: m.sources,
            keywords: [m.name, m.vendor, `${m.name} ücretsiz mi`, `${m.name} nasıl kullanılır`, ...(cat?.keywords ?? [])],
          }),
          productReviewSchema({
            name: m.name,
            vendor: m.vendor,
            description: m.tagline,
            path,
            free: m.pricing !== "ucretli" && !closed,
            os: m.platforms?.join(", "),
            version: m.latestVersion,
            sameAs: m.url,
            paidFrom: closed ? null : m.paidFrom,
            category:
              m.primaryCategory === "kod"
                ? "DeveloperApplication"
                : m.primaryCategory === "gorsel" || m.primaryCategory === "video"
                  ? "MultimediaApplication"
                  : "BusinessApplication",
          }),
          howToSchema(`${m.name} nasıl kullanılır?`, m.howTo),
          faqSchema(faq),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "YZ Araçları", path: "/ai-araclari" },
            ...(cat ? [{ name: cat.label, path: `/kategori/${cat.slug}` }] : []),
            { name: m.name, path },
          ]),
        ]}
      />

      {/* ---------- Başlık ---------- */}
      <section className="relative overflow-hidden pb-8 pt-28 md:pt-36">
        <div aria-hidden className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div aria-hidden className="absolute left-1/3 top-10 h-64 w-[36rem] max-w-full rounded-full bg-neon-turq/12 blur-[120px]" />
        <div className="relative mx-auto max-w-7xl px-4 md:px-6">
          <Breadcrumbs
            items={[
              { name: "Ana Sayfa", path: "/" },
              { name: "YZ Araçları", path: "/ai-araclari" },
              ...(cat ? [{ name: cat.label, path: `/kategori/${cat.slug}` }] : []),
              { name: m.name, path },
            ]}
          />
          <div className="flex flex-col gap-6 md:flex-row md:items-center">
            <Monogram slug={m.slug} name={m.name} size="xl" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                {closed ? <ClosedBadge /> : <PricingBadge pricing={m.pricing} />}
                {m.isNew && <NewBadge />}
                {m.categories.map((k) => (
                  <Link key={k} href={`/kategori/${CATEGORY_BY_KEY[k].slug}`} className="chip hover:border-neon-turq/50 hover:text-white">
                    <NeonIcon name={k} className="size-3.5 text-neon-blue" />
                    {CATEGORY_BY_KEY[k].short}
                  </Link>
                ))}
              </div>
              <h1 className="mt-3 font-display text-4xl font-bold leading-tight text-white md:text-5xl">
                <span className="text-neon-gradient">{m.name}</span> nedir, nasıl kullanılır?
              </h1>
              <p className="mt-3 max-w-3xl text-lg leading-8 text-slate-300">{m.tagline}</p>
              <p className="mt-1 text-sm text-slate-500">
                Geliştirici: {m.vendor} · Son sürüm: {m.latestVersion}
              </p>
            </div>
            <div className="glass w-full shrink-0 rounded-2xl p-5 md:w-72">
              <p className="text-xs uppercase tracking-widest text-slate-500">Editoryal güç puanı</p>
              <p className="mt-1 font-display text-4xl font-bold text-white">
                {m.power}
                <span className="text-lg text-slate-500">/100</span>
              </p>
              <PowerBar value={m.power} label={false} className="mt-2" />
              {rank && cat && (
                <p className="mt-3 text-sm text-slate-400">
                  {cat.label} kategorisinde <strong className="text-neon-turq">#{rank.rank}</strong> / {rank.of}
                </p>
              )}
              {!closed && (
                <a href={m.url} target="_blank" rel="noopener noreferrer nofollow" className="btn-neon mt-4 w-full py-3 text-sm">
                  {hostOf(m.url)} adresine git <NeonIcon name="external" className="size-4" />
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      <ContentWithSidebar>
        {closed && (
          <p role="alert" className="mb-8 flex gap-3 rounded-2xl border border-neon-red/40 bg-neon-red/10 p-5 text-slate-200">
            <NeonIcon name="warning" className="mt-0.5 size-5 shrink-0 text-neon-red" />
            <span>
              <strong className="text-white">{m.name} artık kullanılamıyor.</strong> {m.freeTier} Aşağıdaki alternatiflere göz atabilirsiniz.
            </span>
          </p>
        )}

        <QuickAnswer question={`${m.name} nedir?`} updated={SITE.lastReviewed}>
          <p>{m.description}</p>
        </QuickAnswer>

        {/* ---------- Hızlı bilgiler ---------- */}
        <section aria-labelledby="bilgiler" className="mt-10">
          <h2 id="bilgiler" className="font-display text-2xl font-bold text-white">
            Bir bakışta {m.name}: ücretsiz kota, fiyat ve token
          </h2>
          <dl className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {facts.map((f) => (
              <div key={f.label} className="glass rounded-2xl p-4">
                <dt className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-slate-500">
                  <NeonIcon name={f.icon} className="size-4 text-neon-turq" />
                  {f.label}
                </dt>
                <dd className={cn("mt-1.5 text-sm leading-6 text-slate-200", f.accent)}>{f.value}</dd>
              </div>
            ))}
          </dl>
          <div className="glass mt-3 rounded-2xl p-5">
            <h3 className="flex items-center gap-2 font-semibold text-white">
              <NeonIcon name="gift" className="size-5 text-neon-green" /> Ücretsiz planda neler var?
            </h3>
            <p className="mt-2 leading-7 text-slate-300">{m.freeTier}</p>
            <p className="mt-2 text-sm text-slate-500">Teknik özellik: {m.spec}</p>
          </div>
        </section>

        <AdUnit variant="rectangle" />

        {/* ---------- Animasyonlu rehber CTA ---------- */}
        {guide && (
          <Link
            href={`/egitimler/${guide.slug}`}
            className="group relative mt-10 flex items-center gap-5 overflow-hidden rounded-2xl border border-neon-blue/40 bg-gradient-to-r from-neon-blue/15 via-neon-turq/10 to-transparent p-6 transition hover:shadow-glow-blue"
          >
            <span className="grid size-14 shrink-0 place-items-center rounded-full bg-neon-blue/20 text-neon-blue ring-1 ring-neon-blue/50">
              <NeonIcon name="play" className="size-6" />
            </span>
            <span>
              <span className="eyebrow text-neon-blue">Animasyonlu rehber · {guide.steps.length} adım</span>
              <span className="mt-1 block font-display text-xl font-bold text-white">{guide.title}</span>
              <span className="mt-1 block text-sm text-slate-400">Ekran ekran, kaydırdıkça canlanan anlatım — {guide.minutes} dakika</span>
            </span>
          </Link>
        )}

        {/* ---------- Nasıl kullanılır ---------- */}
        <section aria-labelledby="nasil" className="mt-12">
          <h2 id="nasil" className="font-display text-3xl font-bold text-white">
            {m.name} nasıl kullanılır? (Adım adım)
          </h2>
          <ol className="relative mt-6 space-y-4 before:absolute before:bottom-4 before:left-5 before:top-4 before:w-px before:bg-gradient-to-b before:from-neon-turq before:via-neon-blue before:to-transparent">
            {m.howTo.map((step, i) => (
              <li key={step} className="relative flex gap-4">
                <span className="relative z-10 grid size-10 shrink-0 place-items-center rounded-full border border-neon-turq/50 bg-space-900 font-display font-bold text-neon-turq shadow-glow-turq">
                  {i + 1}
                </span>
                <p className="glass flex-1 rounded-2xl px-4 py-3 leading-7 text-slate-200">{step}</p>
              </li>
            ))}
          </ol>
        </section>

        <AdUnit variant="inArticle" />

        {/* ---------- En iyi olduğu işler + ipuçları ---------- */}
        <section className="grid gap-5 md:grid-cols-2">
          <div className="glass rounded-2xl p-6">
            <h2 className="flex items-center gap-2 font-display text-xl font-bold text-white">
              <IconTile name="star" accent="turq" size="sm" /> Ne için en iyi?
            </h2>
            <ul className="mt-4 space-y-2.5">
              {m.bestFor.map((b) => (
                <li key={b} className="flex gap-2.5 text-slate-300">
                  <NeonIcon name="check" className="mt-1 size-4 shrink-0 text-neon-turq" />
                  {b}
                </li>
              ))}
            </ul>
          </div>
          <div className="glass rounded-2xl p-6">
            <h2 className="flex items-center gap-2 font-display text-xl font-bold text-white">
              <IconTile name="lightbulb" accent="green" size="sm" /> Pro ipuçları
            </h2>
            <ul className="mt-4 space-y-3">
              {m.proTips.map((t) => (
                <li key={t} className="flex gap-2.5 text-sm leading-6 text-slate-300">
                  <NeonIcon name="spark" className="mt-0.5 size-4 shrink-0 text-neon-green" />
                  {t}
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* ---------- Skill / entegrasyon ---------- */}
        <section aria-labelledby="skiller" className="mt-10">
          <h2 id="skiller" className="font-display text-2xl font-bold text-white">
            {m.name} için skill, eklenti ve entegrasyonlar
          </h2>
          <p className="mt-2 text-slate-400">Bu özellikleri ekleyerek veya bağlayarak aracı kendi iş akışınıza göre genişletebilirsiniz.</p>
          <ul className="mt-5 flex flex-wrap gap-2.5">
            {m.skills.map((s) => (
              <li key={s} className="flex items-center gap-2 rounded-xl border border-neon-blue/30 bg-neon-blue/[0.07] px-3.5 py-2 text-sm text-slate-100">
                <NeonIcon name="plug" className="size-4 text-neon-blue" />
                {s}
              </li>
            ))}
          </ul>
        </section>

        {/* ---------- Örnek prompt ---------- */}
        {m.promptExample && (
          <section aria-labelledby="ornek-prompt" className="mt-12">
            <h2 id="ornek-prompt" className="mb-5 font-display text-2xl font-bold text-white">
              {m.name} için örnek prompt
            </h2>
            <NeonPromptBox title={`${m.name} — hazır prompt`} prompt={m.promptExample} tool={m.name} category={cat?.short} accent="turq" collapsible={false} />
          </section>
        )}

        {/* ---------- Artılar / eksiler ---------- */}
        <section className="mt-12 grid gap-5 md:grid-cols-2">
          <div className="rounded-2xl border border-neon-green/30 bg-neon-green/[0.05] p-6">
            <h2 className="font-display text-xl font-semibold text-white">Artıları</h2>
            <ul className="mt-4 space-y-3">
              {m.pros.map((p) => (
                <li key={p} className="flex gap-3 text-slate-300">
                  <NeonIcon name="check" className="mt-1 size-4 shrink-0 text-neon-green" />
                  {p}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-neon-red/30 bg-neon-red/[0.05] p-6">
            <h2 className="font-display text-xl font-semibold text-white">Eksileri</h2>
            <ul className="mt-4 space-y-3">
              {m.cons.map((p) => (
                <li key={p} className="flex gap-3 text-slate-300">
                  <NeonIcon name="x" className="mt-1 size-4 shrink-0 text-neon-red" />
                  {p}
                </li>
              ))}
            </ul>
          </div>
        </section>

        <AdUnit variant="inArticle" className="mt-12" />

        {/* ---------- Alternatifler ---------- */}
        {alts.length > 0 && (
          <section aria-labelledby="alternatifler" className="mt-14">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <h2 id="alternatifler" className="font-display text-2xl font-bold text-white">
                {m.name} alternatifleri
              </h2>
              {cat && (
                <Link href={`/kategori/${cat.slug}`} className="text-sm text-neon-turq hover:underline">
                  {cat.label} sıralaması →
                </Link>
              )}
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {alts.map((a) => (
                <ModelCard key={a.slug} m={toLite(a)} />
              ))}
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              {pairLinks.map((p) => (
                <Link key={p.href} href={p.href} className="chip px-3 py-1.5 text-sm hover:border-neon-turq/50 hover:text-white">
                  <NeonIcon name="compare" className="size-4 text-neon-turq" /> {p.label}
                </Link>
              ))}
              {alts
                .filter((a) => !pairLinks.some((p) => p.other === a.slug))
                .slice(0, Math.max(0, 3 - pairLinks.length))
                .map((a) => (
                  <Link
                    key={a.slug}
                    href={`/karsilastir?m=${m.slug},${a.slug}`}
                    rel="nofollow"
                    className="chip px-3 py-1.5 text-sm hover:border-neon-turq/50 hover:text-white"
                  >
                    <NeonIcon name="compare" className="size-4 text-neon-turq" /> {m.name} vs {a.name}
                  </Link>
                ))}
            </div>
          </section>
        )}

        {/* ---------- SSS ---------- */}
        <section aria-labelledby="sss" className="mt-14">
          <h2 id="sss" className="font-display text-2xl font-bold text-white">
            {m.name} hakkında sık sorulan sorular
          </h2>
          <div className="mt-5 space-y-3">
            {faq.map((f) => (
              <details key={f.q} className="glass group rounded-2xl p-5 open:border-neon-turq/40">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-white">
                  <h3 className="text-base">{f.q}</h3>
                  <span className="text-neon-turq transition group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 leading-7 text-slate-400">{f.a}</p>
              </details>
            ))}
          </div>
        </section>

        <CitationList items={m.sources.map((u) => ({ title: sourceTitle(u), publisher: hostOf(u), url: u }))} />

        <AuthorBox
          name={SITE.author.name}
          role="Yapay zekâ editörü"
          reviewed={SITE.lastReviewed}
          bio={`Bu sayfa ${m.name} için resmi dokümantasyon, fiyat sayfaları ve güvenilir kaynaklar (yukarıda listelendi) temel alınarak hazırlandı. Güç puanı, kategori içi karşılaştırmalı editoryal bir değerlendirmedir.`}
        />
        <AdUnit variant="multiplex" className="mt-12" />
      </ContentWithSidebar>
    </>
  );
}
