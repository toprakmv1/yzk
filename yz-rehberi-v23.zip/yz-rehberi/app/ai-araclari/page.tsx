import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { ModelExplorer } from "@/components/models/ModelExplorer";
import { GeoSchema, breadcrumbSchema, itemListSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { CATEGORIES, MODELS, isActive, stats, toLite } from "@/lib/models";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Yapay Zeka Araçları Listesi 2026: 150 Model Karşılaştırması",
  description:
    "Video, görsel, ses, müzik, kod ve sohbet için 150 yapay zeka aracı: ücretsiz kotalar, fiyatlar, Türkçe desteği ve güç puanı. Filtreleyin, karşılaştırın, adım adım kullanın.",
  path: "/ai-araclari",
  keywords: ["yapay zeka araçları", "ai araçları", "yapay zeka siteleri", "yapay zeka uygulamaları"],
});

export default function AiToolsPage() {
  const s = stats();
  const active = MODELS.filter(isActive);
  return (
    <>
      <GeoSchema
        data={[
          itemListSchema(
            "Yapay zekâ araçları ve modelleri",
            active.map((m) => ({ name: m.name, path: `/ai-araclari/${m.slug}` })),
          ),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "YZ Araçları", path: "/ai-araclari" },
          ]),
        ]}
      />
      <PageHero
        eyebrow="Model dizini"
        title={
          <>
            {s.total} yapay zekâ <span className="text-neon-gradient">modeli</span>
          </>
        }
        subtitle={`${s.categories} kategori · ${s.free} ücretsiz erişim · ${s.open} açık kaynak. Kategori, fiyat ve Türkçe desteğine göre filtreleyin.`}
      />
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <QuickAnswer question="Hangi yapay zekâ aracını kullanmalıyım?" updated={SITE.lastReviewed}>
          <p>
            İşinize göre seçin: genel sohbet ve yazı için bir sohbet asistanı (ChatGPT, Claude, Gemini), görsel için bir metinden-görsele modeli, video için
            Kling, Veo veya Seedance gibi bir video modeli. Bütçeniz yoksa &quot;Ücretsiz erişim&quot; filtresini kullanın; gizlilik önemliyse açık kaynak
            modelleri kendi bilgisayarınızda çalıştırın.
          </p>
        </QuickAnswer>
        <AdUnit variant="leaderboard" />
        <ModelExplorer models={MODELS.map(toLite)} categories={CATEGORIES.map((c) => ({ key: c.key, short: c.short, accent: c.accent }))} />
        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
