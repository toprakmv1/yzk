import type { MetadataRoute } from "next";
import { TUTORIALS } from "@/lib/data";
import { PAIRS } from "@/lib/compare-pairs";
import { GUIDES } from "@/lib/guides";
import { LEGAL_PAGES } from "@/lib/legal";
import { CATEGORIES, MODELS } from "@/lib/models";
import { SITE, absoluteUrl } from "@/lib/site";
import { TUTORIAL_BODIES } from "@/lib/tutorials-content";

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date(SITE.lastReviewed);
  const entry = (path: string, priority: number, changeFrequency: "daily" | "weekly" | "monthly" = "weekly", lm: Date = lastModified) => ({
    url: absoluteUrl(path),
    lastModified: lm,
    changeFrequency,
    priority,
  });
  const monthDate = (ym: string) => {
    const d = new Date(`${ym}-01T00:00:00Z`);
    return Number.isNaN(d.getTime()) || d > lastModified ? lastModified : d;
  };

  return [
    entry("/", 1, "daily"),
    entry("/ai-araclari", 0.95, "daily"),
    entry("/ucretsiz-yapay-zeka", 0.95, "daily"),
    entry("/en-guclu-yapay-zeka", 0.9, "weekly"),
    entry("/yeni-yapay-zeka-modelleri", 0.9, "daily"),
    entry("/egitimler", 0.9),
    entry("/karsilastir", 0.8),
    entry("/hangi-yapay-zeka", 0.8, "monthly"),
    entry("/mega-promptlar", 0.8),
    entry("/sozluk", 0.8, "monthly"),
    entry("/trendler", 0.6),
    entry("/araclar/token-hesaplama", 0.8, "monthly"),
    entry("/araclar/kdv-hesaplama", 0.7, "monthly"),
    entry("/araclar/istifa-dilekcesi-olusturucu", 0.6, "monthly"),
    ...CATEGORIES.map((c) => entry(`/kategori/${c.slug}`, 0.9)),
    ...MODELS.map((m) => entry(`/ai-araclari/${m.slug}`, m.status === "kapandi" ? 0.3 : 0.8, "weekly", monthDate(m.released))),
    ...GUIDES.map((g) => entry(`/egitimler/${g.slug}`, 0.85)),
    // Yalnızca içeriği yazılmış (index'lenebilir) eğitimler
    ...TUTORIALS.filter((t) => TUTORIAL_BODIES[t.slug]).map((t) => entry(`/egitimler/${t.slug}`, 0.7)),
    ...PAIRS.map((p) => entry(`/karsilastir/${p.slug}`, 0.6)),
    ...Object.keys(LEGAL_PAGES).map((s) => entry(`/${s}`, 0.3, "monthly")),
  ];
}
