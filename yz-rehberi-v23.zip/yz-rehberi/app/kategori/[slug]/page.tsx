import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import { Breadcrumbs } from "@/components/layout/ContentWithSidebar";
import { ModelCard } from "@/components/models/ModelBits";
import { RankTable } from "@/components/models/RankTable";
import { GeoSchema, breadcrumbSchema, faqSchema, itemListSchema } from "@/components/seo/GeoSchemaHelper";
import { CATEGORIES, CATEGORY_BY_SLUG, formatMonth, hasFreeAccess, modelsInCategory, toLite } from "@/lib/models";
import { SITE } from "@/lib/site";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return CATEGORIES.map((c) => ({ slug: c.slug }));
}
export const dynamicParams = false;

const MONTH = formatMonth(SITE.lastReviewed.slice(0, 7));

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const c = CATEGORY_BY_SLUG[slug];
  if (!c) return {};
  const list = modelsInCategory(c.key);
  const title = `${c.label}: En İyi ${list.length} Yapay Zeka Aracı (${MONTH})`;
  return pageMeta({
    title,
    description: `${c.intro} ${list.filter(hasFreeAccess).length} ücretsiz seçenek, kota, fiyat ve Türkçe desteğiyle sıralandı: ${list
      .slice(0, 3)
      .map((m) => m.name)
      .join(", ")}.`,
    path: `/kategori/${c.slug}`,
    keywords: c.keywords,
  });
}

export default async function CategoryPage({ params }: Props) {
  const { slug } = await params;
  const c = CATEGORY_BY_SLUG[slug];
  if (!c) notFound();
  const list = modelsInCategory(c.key);
  const free = list.filter(hasFreeAccess);
  const fullyFree = list.filter((m) => m.pricing === "ucretsiz" || m.pricing === "acik-kaynak");
  const open = list.filter((m) => m.openWeights);
  const trGood = list.filter((m) => m.turkish === "iyi");
  const newest = list
    .filter((m) => m.isNew)
    .sort((a, b) => b.released.localeCompare(a.released))
    .slice(0, 6);
  const path = `/kategori/${c.slug}`;
  const job = c.job.toLocaleLowerCase("tr-TR");

  const faq = [
    {
      q: `En iyi ${job} yapay zekâsı hangisi?`,
      a: `Editoryal sıralamamızda ilk üç: ${list
        .slice(0, 3)
        .map((m) => `${m.name} (${m.vendor})`)
        .join(", ")}. Seçim yaparken ücretsiz kota, Türkçe desteği ve çıktı kalitesini birlikte değerlendirin.`,
    },
    {
      q: `Ücretsiz ${job} yapay zekâsı var mı?`,
      a: free.length
        ? `Evet, ${free.length} seçenek ücretsiz kullanılabiliyor. En güçlüleri: ${free
            .slice(0, 4)
            .map((m) => `${m.name} (${m.freeQuota})`)
            .join("; ")}.`
        : "Bu kategorideki araçların çoğu ücretli; açık kaynak alternatiflere göz atın.",
    },
    ...(trGood.length
      ? [
          {
            q: `Türkçeyi en iyi destekleyen ${job} aracı hangisi?`,
            a: `Türkçe desteği iyi olan seçenekler: ${trGood
              .slice(0, 5)
              .map((m) => m.name)
              .join(", ")}.`,
          },
        ]
      : []),
    ...(open.length
      ? [
          {
            q: `Bilgisayarıma kurabileceğim açık kaynak ${job} modeli var mı?`,
            a: `Evet: ${open
              .slice(0, 5)
              .map((m) => m.name)
              .join(", ")}. Bu modeller genellikle güçlü bir ekran kartı gerektirir; ComfyUI, Ollama veya LM Studio ile çalıştırılabilir.`,
          },
        ]
      : []),
  ];

  return (
    <>
      <GeoSchema
        data={[
          itemListSchema(
            `En iyi ${job} yapay zekâ araçları`,
            list.map((m) => ({ name: m.name, path: `/ai-araclari/${m.slug}` })),
          ),
          faqSchema(faq),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "YZ Araçları", path: "/ai-araclari" },
            { name: c.label, path },
          ]),
        ]}
      />
      <section className="relative overflow-hidden pb-8 pt-28 md:pt-36">
        <div aria-hidden className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div aria-hidden className="absolute left-1/2 top-10 h-72 w-[42rem] max-w-full -translate-x-1/2 rounded-full bg-neon-turq/15 blur-[120px]" />
        <div className="relative mx-auto max-w-7xl px-4 md:px-6">
          <Breadcrumbs
            items={[
              { name: "Ana Sayfa", path: "/" },
              { name: "YZ Araçları", path: "/ai-araclari" },
              { name: c.label, path },
            ]}
          />
          <div className="flex items-start gap-5">
            <IconTile name={c.key} accent={c.accent} size="lg" className="hidden sm:grid" />
            <div>
              <p className="eyebrow text-neon-turq">
                {c.label} · {MONTH} sıralaması
              </p>
              <h1 className="mt-3 font-display text-4xl font-bold leading-tight text-white md:text-5xl">
                En iyi <span className="text-neon-gradient">{job}</span> yapay zekâları
              </h1>
              <p className="mt-4 max-w-3xl text-lg leading-8 text-slate-300">{c.intro}</p>
              <ul className="mt-5 flex flex-wrap gap-2 text-sm">
                <li className="chip px-3 py-1 text-sm">{list.length} model</li>
                <li className="chip border-neon-green/40 px-3 py-1 text-sm text-neon-green">{free.length} ücretsiz erişim</li>
                {open.length > 0 && <li className="chip px-3 py-1 text-sm">{open.length} açık ağırlık</li>}
                {trGood.length > 0 && <li className="chip px-3 py-1 text-sm">{trGood.length} iyi Türkçe</li>}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <QuickAnswer question={`En iyi ${job} yapay zekâsı hangisi?`} updated={SITE.lastReviewed}>
          <p>
            Genel kalitede <strong>{list[0]?.name}</strong> öne çıkıyor; onu {list[1]?.name} ve {list[2]?.name} izliyor.
            {free[0] && (
              <>
                {" "}
                Ücretsiz kullanmak istiyorsanız en güçlü seçenek <strong>{free[0].name}</strong> ({free[0].freeQuota}).
              </>
            )}
            {fullyFree[0] && fullyFree[0].slug !== free[0]?.slug && (
              <> Tamamen ücretsiz/açık kaynak tercih edenler için {fullyFree[0].name} iyi bir başlangıç.</>
            )}
          </p>
        </QuickAnswer>

        <AdUnit variant="leaderboard" />

        <section aria-labelledby="siralama">
          <h2 id="siralama" className="mb-5 font-display text-2xl font-bold text-white md:text-3xl">
            {c.label}: tam sıralama
          </h2>
          <RankTable models={list.slice(0, 10)} caption={`${c.label} sıralaması`} />
          {list.length > 10 && (
            <>
              <AdUnit variant="inArticle" />
              <RankTable models={list.slice(10)} caption={`${c.label} sıralaması (devam)`} startRank={11} />
            </>
          )}
          <p className="mt-3 text-xs text-slate-500">
            Güç puanı; çıktı kalitesi, özellik seti, hız ve güncellik gözetilerek verilen kategori içi editoryal bir değerlendirmedir. Kotalar sağlayıcılar
            tarafından sık değiştirilir.
          </p>
        </section>

        {free.length > 0 && (
          <section aria-labelledby="ucretsizler" className="mt-14">
            <h2 id="ucretsizler" className="font-display text-2xl font-bold text-white md:text-3xl">
              Ücretsiz {job} yapay zekâları
            </h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {free.slice(0, 9).map((m) => (
                <ModelCard key={m.slug} m={toLite(m)} />
              ))}
            </div>
          </section>
        )}

        <AdUnit variant="rectangle" className="mt-12" />

        {newest.length > 0 && (
          <section aria-labelledby="yeniler" className="mt-14">
            <h2 id="yeniler" className="font-display text-2xl font-bold text-white">
              {c.label} kategorisinde yeni çıkanlar
            </h2>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {newest.map((m) => (
                <li key={m.slug}>
                  <Link href={`/ai-araclari/${m.slug}`} className="glass flex items-center justify-between gap-3 rounded-xl p-4 hover:border-neon-red/40">
                    <span className="min-w-0">
                      <span className="block truncate font-semibold text-white">{m.name}</span>
                      <span className="block truncate text-xs text-slate-500">{m.latestVersion}</span>
                    </span>
                    <span className="shrink-0 text-xs text-neon-red">{formatMonth(m.released)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section aria-labelledby="sss" className="mx-auto mt-14 max-w-3xl">
          <h2 id="sss" className="font-display text-2xl font-bold text-white">
            Sık sorulan sorular
          </h2>
          <div className="mt-5 space-y-3">
            {faq.map((f) => (
              <details key={f.q} className="glass group rounded-2xl p-5 open:border-neon-turq/40">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-white">
                  {f.q}
                  <span className="text-neon-turq transition group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 leading-7 text-slate-400">{f.a}</p>
              </details>
            ))}
          </div>
        </section>

        <nav aria-label="Diğer kategoriler" className="mt-14">
          <h2 className="font-display text-xl font-bold text-white">Diğer kategoriler</h2>
          <ul className="mt-4 flex flex-wrap gap-2">
            {CATEGORIES.filter((x) => x.key !== c.key).map((x) => (
              <li key={x.key}>
                <Link
                  href={`/kategori/${x.slug}`}
                  className="group flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] py-1.5 pl-1.5 pr-3 text-sm text-slate-200 hover:border-neon-turq/50"
                >
                  <IconTile name={x.key} accent={x.accent} size="sm" /> {x.label}
                  <NeonIcon name="arrow" className="size-3.5 text-slate-500" />
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
