import { TUTORIALS } from "@/lib/data";
import { GLOSSARY } from "@/lib/glossary";
import { GUIDES } from "@/lib/guides";
import { CATEGORIES, MODELS, PRICING_LABEL, isActive, modelsInCategory } from "@/lib/models";
import { SITE, absoluteUrl } from "@/lib/site";
import { TUTORIAL_BODIES } from "@/lib/tutorials-content";

/**
 * /llms.txt — LLM'ler için site özeti (llmstxt.org önerisi).
 * Build sırasında statik üretilir; içerik değiştikçe otomatik güncellenir.
 */
export const dynamic = "force-static";

export function GET() {
  const lines = [
    `# ${SITE.name}`,
    "",
    `> ${SITE.description}`,
    "",
    `Türkçe yapay zekâ rehberi ve model veritabanı (${MODELS.filter(isActive).length} aktif model). Her model sayfasında ücretsiz kota, fiyat, API/token bilgisi, adım adım kullanım, skill/entegrasyonlar ve kaynak bağlantıları bulunur.`,
    `Son veri güncellemesi: ${SITE.lastReviewed}`,
    "",
    "## Ana listeler",
    `- [Ücretsiz yapay zekâ modelleri](${absoluteUrl("/ucretsiz-yapay-zeka")}): kategoriye göre ücretsiz araçlar ve kotaları`,
    `- [En güçlü yapay zekâ modelleri](${absoluteUrl("/en-guclu-yapay-zeka")}): genel ve kategori bazlı sıralama`,
    `- [Yeni çıkan yapay zekâ modelleri](${absoluteUrl("/yeni-yapay-zeka-modelleri")}): aylara göre zaman çizelgesi`,
    `- [Tüm modeller](${absoluteUrl("/ai-araclari")})`,
    "",
    "## Kategoriler",
    ...CATEGORIES.map(
      (c) =>
        `- [${c.label}](${absoluteUrl(`/kategori/${c.slug}`)}): ${modelsInCategory(c.key).length} model. İlk üç: ${modelsInCategory(c.key)
          .slice(0, 3)
          .map((m) => m.name)
          .join(", ")}`,
    ),
    "",
    "## Adım adım kullanım rehberleri",
    ...GUIDES.map((g) => `- [${g.title}](${absoluteUrl(`/egitimler/${g.slug}`)}): ${g.metaDescription}`),
    ...TUTORIALS.filter((t) => TUTORIAL_BODIES[t.slug]).map((t) => `- [${t.title}](${absoluteUrl(`/egitimler/${t.slug}`)}): ${t.summary}`),
    "",
    "## Model sayfaları",
    ...MODELS.filter(isActive).map(
      (m) => `- [${m.name}](${absoluteUrl(`/ai-araclari/${m.slug}`)}): ${m.tagline} (${PRICING_LABEL[m.pricing]}; ücretsiz: ${m.freeQuota})`,
    ),
    "",
    "## Araçlar",
    `- [Hangi yapay zekâ bana uygun?](${absoluteUrl("/hangi-yapay-zeka")})`,
    `- [Model karşılaştırma](${absoluteUrl("/karsilastir")})`,
    `- [Token ve API maliyet hesaplayıcı](${absoluteUrl("/araclar/token-hesaplama")})`,
    `- [KDV Hesaplama](${absoluteUrl("/araclar/kdv-hesaplama")})`,
    "",
    "## Optional",
    `- [Yapay zekâ sözlüğü](${absoluteUrl("/sozluk")}): ${GLOSSARY.length} kavram`,
    `- [Mega prompt kütüphanesi](${absoluteUrl("/mega-promptlar")})`,
    `- [Ekosistem istatistikleri](${absoluteUrl("/trendler")})`,
    `- [Editoryal ilkeler](${absoluteUrl("/editoryal-ilkeler")})`,
  ];

  return new Response(lines.join("\n"), {
    headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "public, max-age=3600" },
  });
}
