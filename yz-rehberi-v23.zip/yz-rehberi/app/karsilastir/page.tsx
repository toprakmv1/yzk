import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { Suspense } from "react";
import { AdUnit } from "@/components/ads/AdUnit";
import { CompareTool } from "@/components/compare/CompareTool";
import { GeoSchema, breadcrumbSchema, softwareAppSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { PAIRS } from "@/lib/compare-pairs";
import { getModel } from "@/lib/models";

export const metadata: Metadata = pageMeta({
  title: "Yapay Zeka Karşılaştırma: ChatGPT vs Gemini vs Claude ve Fazlası",
  description: "150 yapay zeka modelini yan yana karşılaştırın: ücretsiz kota, fiyat, API/token, Türkçe desteği, artılar ve eksiler. Popüler A vs B karşılaştırmaları.",
  path: "/karsilastir",
  keywords: ["chatgpt vs gemini", "chatgpt vs claude", "yapay zeka karşılaştırma"],
});

export default function ComparePage() {
  return (
    <>
      <GeoSchema
        data={[
          softwareAppSchema({
            name: "Yapay Zekâ Karşılaştırma Aracı",
            description: "Yapay zekâ modellerini yan yana karşılaştırma aracı",
            path: "/karsilastir",
            category: "UtilitiesApplication",
          }),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Karşılaştır", path: "/karsilastir" },
          ]),
        ]}
      />
      <PageHero
        eyebrow="Karşılaştırma aracı"
        title={
          <>
            Yapay zekâları <span className="text-neon-gradient">yan yana</span> koyun
          </>
        }
        subtitle="Ücretsiz kota, fiyat, token, Türkçe desteği ve artılar/eksiler — tek tabloda."
      />
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <Suspense fallback={<div className="h-40 rounded-2xl bg-white/[0.03]" />}>
          <CompareTool defaults={["chatgpt", "claude", "gemini"]} />
        </Suspense>

        <AdUnit variant="inArticle" />

        <section aria-labelledby="populer" className="mt-6">
          <h2 id="populer" className="font-display text-2xl font-bold text-white">
            Popüler karşılaştırmalar
          </h2>
          <ul className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {PAIRS.map((p) => (
              <li key={p.slug}>
                <Link
                  href={`/karsilastir/${p.slug}`}
                  className="glass block rounded-xl px-4 py-3 text-sm text-slate-200 hover:border-neon-turq/50 hover:text-white"
                >
                  {getModel(p.a)?.name} <span className="text-neon-red">vs</span> {getModel(p.b)?.name}
                </Link>
              </li>
            ))}
          </ul>
        </section>
        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
