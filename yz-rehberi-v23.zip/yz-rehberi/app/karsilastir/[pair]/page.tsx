import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AdUnit } from "@/components/ads/AdUnit";
import { CompareTable, verdict } from "@/components/compare/CompareTable";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { NeonIcon } from "@/components/icons/NeonIcon";
import { Breadcrumbs } from "@/components/layout/ContentWithSidebar";
import { GeoSchema, articleSchema, breadcrumbSchema, faqSchema } from "@/components/seo/GeoSchemaHelper";
import { toCompare } from "@/lib/compare";
import { PAIRS, getPair } from "@/lib/compare-pairs";
import { CATEGORY_BY_KEY, PRICING_LABEL, getModel } from "@/lib/models";
import { SITE } from "@/lib/site";

type Props = { params: Promise<{ pair: string }> };

export function generateStaticParams() {
  return PAIRS.map((p) => ({ pair: p.slug }));
}
export const dynamicParams = false;

function load(slug: string) {
  const p = getPair(slug);
  if (!p) return null;
  const a = getModel(p.a);
  const b = getModel(p.b);
  return a && b ? { p, a, b } : null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { pair } = await params;
  const d = load(pair);
  if (!d) return {};
  const title = `${d.a.name} vs ${d.b.name}: Hangisi Daha İyi? (2026 Karşılaştırma)`;
  return pageMeta({
    title,
    description: `${d.a.name} mi ${d.b.name} mi? Ücretsiz kullanım, ücretli planlar, API/token fiyatı, Türkçe desteği, artılar ve eksilerle tarafsız karşılaştırma.`,
    path: `/karsilastir/${pair}`,
    type: "article",
    publishedTime: "2026-10-01",
    section: "Karşılaştırmalar",
    keywords: [`${d.a.name} vs ${d.b.name}`, `${d.a.name} mi ${d.b.name} mi`, `${d.b.name} vs ${d.a.name}`],
  });
}

export default async function PairPage({ params }: Props) {
  const { pair } = await params;
  const d = load(pair);
  if (!d) notFound();
  const { a, b } = d;
  const ca = toCompare(a);
  const cb = toCompare(b);
  const path = `/karsilastir/${pair}`;
  const v = verdict(ca, cb);
  const faq = [
    { q: `${a.name} mi ${b.name} mi daha iyi?`, a: v },
    {
      q: `${a.name} ve ${b.name} ücretsiz mi?`,
      a: `${a.name}: ${PRICING_LABEL[a.pricing]} — ${a.freeQuota}. ${b.name}: ${PRICING_LABEL[b.pricing]} — ${b.freeQuota}.`,
    },
    {
      q: `${a.name} ile ${b.name} arasındaki temel fark nedir?`,
      a: `${a.name} (${a.vendor}) ${a.tagline.toLocaleLowerCase("tr-TR")}; ${b.name} (${b.vendor}) ise ${b.tagline.toLocaleLowerCase("tr-TR")}.`,
    },
  ];
  const related = PAIRS.filter((x) => x.slug !== pair && (x.a === a.slug || x.b === a.slug || x.a === b.slug || x.b === b.slug)).slice(0, 8);

  return (
    <>
      <GeoSchema
        data={[
          articleSchema({
            title: `${a.name} vs ${b.name}`,
            description: v,
            path,
            datePublished: "2026-10-01",
            dateModified: SITE.lastReviewed,
            section: "Karşılaştırmalar",
            citations: [...a.sources, ...b.sources].slice(0, 6),
          }),
          faqSchema(faq),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Karşılaştır", path: "/karsilastir" },
            { name: `${a.name} vs ${b.name}`, path },
          ]),
        ]}
      />
      <section className="relative overflow-hidden pb-8 pt-28 md:pt-36">
        <div aria-hidden className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="relative mx-auto max-w-6xl px-4 md:px-6">
          <Breadcrumbs
            items={[
              { name: "Ana Sayfa", path: "/" },
              { name: "Karşılaştır", path: "/karsilastir" },
              { name: `${a.name} vs ${b.name}`, path },
            ]}
          />
          <p className="eyebrow text-neon-turq">{CATEGORY_BY_KEY[a.primaryCategory]?.label} karşılaştırması</p>
          <h1 className="mt-3 font-display text-4xl font-bold leading-tight text-white md:text-6xl">
            <span className="text-neon-gradient">{a.name}</span> <span className="text-neon-red">vs</span> <span className="text-neon-gradient">{b.name}</span>
          </h1>
          <p className="mt-4 max-w-3xl text-lg text-slate-300">
            Hangisini kullanmalısınız? Ücretsiz kota, fiyat, Türkçe desteği ve güçlü yönleriyle tarafsız karşılaştırma.
          </p>
        </div>
      </section>
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <QuickAnswer question={`${a.name} mi ${b.name} mi?`} updated={SITE.lastReviewed}>
          <p>{v}</p>
        </QuickAnswer>
        <AdUnit variant="leaderboard" />
        <CompareTable models={[ca, cb]} />
        <p className="mt-4 text-sm text-slate-400">
          Üçüncü bir model eklemek ister misiniz?{" "}
          <Link href={`/karsilastir?m=${a.slug},${b.slug}`} className="text-neon-turq underline">
            Etkileşimli karşılaştırma aracında açın
          </Link>
          .
        </p>
        <AdUnit variant="inArticle" />
        <section aria-labelledby="sss" className="mx-auto max-w-3xl">
          <h2 id="sss" className="font-display text-2xl font-bold text-white">
            Sık sorulan sorular
          </h2>
          <div className="mt-5 space-y-3">
            {faq.map((f) => (
              <details key={f.q} className="glass group rounded-2xl p-5 open:border-neon-turq/40">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-white">
                  {f.q}
                  <span className="text-neon-turq transition group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 leading-7 text-slate-400">{f.a}</p>
              </details>
            ))}
          </div>
        </section>
        {related.length > 0 && (
          <nav aria-label="İlgili karşılaştırmalar" className="mt-12">
            <h2 className="font-display text-xl font-bold text-white">İlgili karşılaştırmalar</h2>
            <ul className="mt-4 flex flex-wrap gap-2">
              {related.map((r) => (
                <li key={r.slug}>
                  <Link href={`/karsilastir/${r.slug}`} className="chip px-3 py-1.5 text-sm hover:border-neon-turq/50 hover:text-white">
                    <NeonIcon name="compare" className="size-4 text-neon-turq" />
                    {getModel(r.a)?.name} vs {getModel(r.b)?.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        )}
        <AdUnit variant="multiplex" className="mt-12" />
      </div>
    </>
  );
}
