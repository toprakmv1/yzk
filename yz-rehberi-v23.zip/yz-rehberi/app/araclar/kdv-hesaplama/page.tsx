import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { SeoGuide } from "@/components/content/SeoGuide";
import { AuthorBox, CitationList, QuickAnswer, StatisticBox } from "@/components/geo/GeoBlocks";
import { Breadcrumbs, ContentWithSidebar } from "@/components/layout/ContentWithSidebar";
import { GeoSchema, articleSchema, breadcrumbSchema, faqSchema, howToSchema, softwareAppSchema } from "@/components/seo/GeoSchemaHelper";
import { KdvCalculator } from "@/components/tools/KdvCalculator";
import { PageHero } from "@/components/ui/Reveal";
import { SITE } from "@/lib/site";

const PATH = "/araclar/kdv-hesaplama";
const TITLE = "KDV Hesaplama 2026 — KDV Dahil ve Hariç Hesaplama Aracı";
const DESC =
  "Güncel %1, %10 ve %20 oranlarıyla KDV dahil ve KDV hariç tutarı saniyeler içinde hesaplayın. Formüller, örnekler ve sık yapılan hatalarla detaylı rehber.";

export const metadata: Metadata = pageMeta({ title: TITLE, description: DESC, path: PATH, keywords: ["kdv hesaplama", "kdv dahil hesaplama", "kdv hariç hesaplama", "kdv oranları 2026"] });

const FAQ = [
  {
    q: "KDV dahil fiyattan KDV nasıl hesaplanır?",
    a: "KDV dahil tutarı (1 + KDV oranı) değerine bölerek matrahı bulun, ardından KDV dahil tutardan matrahı çıkarın. Örneğin %20 KDV dahil 1.200 TL için: 1.200 ÷ 1,20 = 1.000 TL matrah, 200 TL KDV.",
  },
  {
    q: "2026'da Türkiye'de KDV oranları nedir?",
    a: "Genel KDV oranı %20'dir. Temel gıda ürünlerinin bir kısmı gibi bazı mal ve hizmetlerde %1, bazı gıda, tekstil ve hizmetlerde %10 indirimli oran uygulanır. Hangi ürüne hangi oranın uygulandığını güncel mevzuattan kontrol edin.",
  },
  {
    q: "KDV hariç fiyata KDV nasıl eklenir?",
    a: "KDV hariç tutarı (1 + KDV oranı) ile çarpın. Örneğin 1.000 TL'ye %20 KDV eklemek için 1.000 × 1,20 = 1.200 TL.",
  },
  {
    q: "KDV'yi yüzde olarak çıkarmak neden yanlış sonuç verir?",
    a: "KDV dahil fiyattan doğrudan %20 düşmek, KDV'yi toplam tutar üzerinden hesaplar; oysa KDV matrah üzerinden alınır. 1.200 TL'den %20 düşmek 960 TL verir, doğru matrah ise 1.000 TL'dir.",
  },
];

const STEPS = [
  "Hesaplama yönünü seçin: KDV hariç tutardan dahile mi, dahil tutardan hariçe mi?",
  "Tutarı Türk lirası olarak girin (1.250,50 veya 1250.50 biçimleri kabul edilir).",
  "Ürün veya hizmetinize uygun KDV oranını (%1, %10, %20) seçin ya da özel oran yazın.",
  "Matrah, KDV tutarı ve toplam tutar anında hesaplanır.",
];

export default function KdvPage() {
  return (
    <>
      <GeoSchema
        data={[
          softwareAppSchema({
            name: "KDV Hesaplama Aracı",
            description: DESC,
            path: PATH,
            category: "FinanceApplication",
            featureList: ["KDV dahil hesaplama", "KDV hariç hesaplama", "%1 %10 %20 oranları", "Özel oran desteği"],
          }),
          articleSchema({
            title: TITLE,
            description: DESC,
            path: PATH,
            datePublished: "2026-01-15",
            dateModified: SITE.lastReviewed,
            section: "Finans Araçları",
            citations: ["https://www.gib.gov.tr", "https://www.mevzuat.gov.tr"],
          }),
          faqSchema(FAQ),
          howToSchema("KDV nasıl hesaplanır?", STEPS),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Araçlar", path: "/araclar/kdv-hesaplama" },
            { name: "KDV Hesaplama", path: PATH },
          ]),
        ]}
      />

      <PageHero
        eyebrow="Ücretsiz Finans Aracı"
        title={
          <>
            <span className="text-neon-gradient">KDV Hesaplama</span> 2026
          </>
        }
        subtitle="KDV dahil ve hariç tutarları güncel oranlarla anında hesaplayın."
      />

      <ContentWithSidebar>
        <Breadcrumbs
          items={[
            { name: "Ana Sayfa", path: "/" },
            { name: "Araçlar", path: "/araclar/kdv-hesaplama" },
            { name: "KDV Hesaplama", path: PATH },
          ]}
        />

        <QuickAnswer question="KDV nasıl hesaplanır?" updated={SITE.lastReviewed}>
          <p>
            KDV hariç tutara KDV eklemek için tutarı <strong>(1 + oran)</strong> ile çarpın: %20 KDV için 1.000 × 1,20 = 1.200 TL. KDV dahil tutardan
            KDV&apos;yi ayırmak için tutarı <strong>(1 + oran)</strong> değerine bölün: 1.200 ÷ 1,20 = 1.000 TL matrah, fark olan 200 TL KDV&apos;dir.
          </p>
        </QuickAnswer>

        <div className="mt-10">
          <KdvCalculator />
        </div>

        {/* ============ 750+ KELİMELİK DETAYLI REHBER ============ */}
        <div className="mt-20">
          <SeoGuide
            title="KDV Hesaplama Rehberi: Formüller, Oranlar ve Örnekler"
            intro={
              <p>
                Katma Değer Vergisi (KDV), bir mal veya hizmetin üretimden tüketiciye kadar her aşamada eklenen değer üzerinden alınan dolaylı bir vergidir. Bu
                rehberde KDV&apos;nin nasıl hesaplandığını, hangi oranların uygulandığını ve en sık yapılan hataları örneklerle açıklıyoruz.
              </p>
            }
            sections={[
              {
                id: "kdv-nedir",
                title: "KDV nedir ve kim öder?",
                content: (
                  <>
                    <p>
                      KDV, Türkiye&apos;de <strong>3065 sayılı Katma Değer Vergisi Kanunu</strong> ile düzenlenen bir tüketim vergisidir. Vergiyi satıcı tahsil
                      edip devlete öder, ancak vergi yükünü nihai tüketici taşır. Bu nedenle KDV&apos;ye &quot;dolaylı vergi&quot; denir.
                    </p>
                    <p>
                      İşletmeler, satışlarında tahsil ettikleri KDV&apos;den (hesaplanan KDV), alışlarında ödedikleri KDV&apos;yi (indirilecek KDV) düşer ve
                      farkı beyan ederek öder. Bu mekanizma sayesinde vergi yalnızca her aşamada eklenen değer üzerinden alınmış olur.
                    </p>
                    <h3>Matrah kavramı</h3>
                    <p>
                      Matrah, verginin hesaplandığı tutardır; yani ürünün veya hizmetin KDV hariç bedelidir. KDV her zaman matrah üzerinden hesaplanır, toplam
                      tutar üzerinden değil. Hesaplama hatalarının büyük bölümü bu ayrımın gözden kaçmasından kaynaklanır.
                    </p>
                  </>
                ),
              },
              {
                id: "kdv-oranlari",
                title: "Güncel KDV oranları",
                content: (
                  <>
                    <p>
                      Türkiye&apos;de üç temel KDV oranı uygulanır. Genel oran, 10 Temmuz 2023&apos;ten itibaren %18&apos;den %20&apos;ye yükseltilmiştir.
                      İndirimli oranlar ise belirli temel ihtiyaç ürünlerine uygulanır.
                    </p>
                    <table>
                      <thead>
                        <tr>
                          <th>Oran</th>
                          <th>Kapsam (özet)</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>%1</td>
                          <td>Bazı temel gıda ürünleri ve kanunda sayılan belirli teslimler</td>
                        </tr>
                        <tr>
                          <td>%10</td>
                          <td>Bazı gıda ürünleri, belirli hizmetler ve listelerde yer alan diğer teslimler</td>
                        </tr>
                        <tr>
                          <td>%20</td>
                          <td>Genel oran — listelerde yer almayan tüm mal ve hizmetler</td>
                        </tr>
                      </tbody>
                    </table>
                    <StatisticBox
                      value="%20"
                      label="Türkiye'de genel KDV oranı"
                      context="Cumhurbaşkanı Kararı ile 10 Temmuz 2023 tarihinden itibaren %18'den %20'ye yükseltildi."
                      sourceName="Resmî Gazete / Gelir İdaresi Başkanlığı"
                      sourceUrl="https://www.gib.gov.tr"
                      year={2023}
                      accent="green"
                    />
                    <p>
                      Oranlar Cumhurbaşkanı kararıyla değiştirilebildiği için, özellikle fatura keserken ürününüze uygulanan oranı Gelir İdaresi
                      Başkanlığı&apos;nın güncel listelerinden kontrol etmeniz önerilir.
                    </p>
                  </>
                ),
              },
              {
                id: "kdv-haric-dahil",
                title: "KDV hariç tutardan KDV dahil tutara",
                content: (
                  <>
                    <p>
                      Elinizde KDV hariç bir fiyat varsa, KDV dahil fiyatı bulmak için tutarı (1 + oran) ile çarpmanız yeterlidir. Oran ondalık olarak yazılır:
                      %20 için 0,20, %10 için 0,10.
                    </p>
                    <h3>Formül</h3>
                    <p>
                      <strong>KDV tutarı = Matrah × Oran</strong>
                      <br />
                      <strong>KDV dahil tutar = Matrah × (1 + Oran)</strong>
                    </p>
                    <h3>Örnek</h3>
                    <p>
                      Bir yazılım hizmeti için 2.500 TL + KDV teklif verdiniz. %20 oranla KDV tutarı 2.500 × 0,20 = 500 TL, müşterinin ödeyeceği toplam 2.500 ×
                      1,20 = 3.000 TL olur.
                    </p>
                  </>
                ),
              },
              {
                id: "kdv-dahil-haric",
                title: "KDV dahil tutardan KDV'yi ayırma (iç yüzde)",
                content: (
                  <>
                    <p>
                      Market fişi veya perakende fiyat gibi KDV dahil bir tutardan matrahı bulmak için &quot;iç yüzde&quot; yöntemi kullanılır. Burada çarpma
                      değil, bölme yapılır.
                    </p>
                    <h3>Formül</h3>
                    <p>
                      <strong>Matrah = KDV dahil tutar ÷ (1 + Oran)</strong>
                      <br />
                      <strong>KDV tutarı = KDV dahil tutar − Matrah</strong>
                    </p>
                    <h3>Örnek</h3>
                    <p>
                      %10 KDV dahil 550 TL&apos;lik bir restoran hesabında matrah 550 ÷ 1,10 = 500 TL, KDV ise 50 TL&apos;dir. Pratik bir kısayol olarak %20 KDV
                      dahil tutarı 6&apos;ya bölerek KDV&apos;yi bulabilirsiniz (1.200 ÷ 6 = 200), çünkü 0,20 ÷ 1,20 = 1/6&apos;dır.
                    </p>
                  </>
                ),
              },
              {
                id: "sik-hatalar",
                title: "En sık yapılan 4 KDV hesaplama hatası",
                content: (
                  <>
                    <ol>
                      <li>
                        <strong>Toplamdan doğrudan yüzde düşmek:</strong> 1.200 TL&apos;den %20 düşmek 960 TL verir; doğru matrah 1.000 TL&apos;dir.
                      </li>
                      <li>
                        <strong>Yanlış oran seçmek:</strong> Aynı sektörde bile ürünler farklı oranlara tabi olabilir.
                      </li>
                      <li>
                        <strong>Satır bazında yuvarlama farkları:</strong> Çok kalemli faturalarda her satırı ayrı yuvarlamak toplamda kuruş farkları
                        yaratabilir.
                      </li>
                      <li>
                        <strong>Tevkifatı unutmak:</strong> Bazı hizmetlerde KDV&apos;nin bir kısmını alıcı beyan eder (KDV tevkifatı); bu durumda faturadaki
                        tahsil edilecek tutar değişir.
                      </li>
                    </ol>
                  </>
                ),
              },
              {
                id: "nasil-kullanilir",
                title: "Bu KDV hesaplama aracı nasıl kullanılır?",
                content: (
                  <>
                    <ol>
                      {STEPS.map((s) => (
                        <li key={s}>{s}</li>
                      ))}
                    </ol>
                    <p>
                      Araç tamamen tarayıcınızda çalışır; girdiğiniz tutarlar herhangi bir sunucuya gönderilmez veya kaydedilmez. Sonuçlar kuruş hassasiyetinde
                      yuvarlanır.
                    </p>
                  </>
                ),
              },
              {
                id: "sss",
                title: "Sık sorulan sorular",
                content: (
                  <>
                    {FAQ.map((f) => (
                      <div key={f.q}>
                        <h3>{f.q}</h3>
                        <p>{f.a}</p>
                      </div>
                    ))}
                  </>
                ),
              },
            ]}
          />

          <CitationList
            items={[
              {
                title: "3065 sayılı Katma Değer Vergisi Kanunu",
                publisher: "Mevzuat Bilgi Sistemi",
                url: "https://www.mevzuat.gov.tr",
                note: "Kanun metninin güncel hali",
              },
              {
                title: "KDV oranları ve uygulama rehberleri",
                publisher: "T.C. Hazine ve Maliye Bakanlığı Gelir İdaresi Başkanlığı",
                url: "https://www.gib.gov.tr",
              },
              { title: "Resmî Gazete arşivi", publisher: "T.C. Cumhurbaşkanlığı İdari İşler Başkanlığı", url: "https://www.resmigazete.gov.tr" },
            ]}
          />

          <AuthorBox
            name={SITE.author.name}
            role="Finans ve vergi içerikleri"
            reviewed={SITE.lastReviewed}
            bio="Bu içerik birincil kaynaklardan (kanun metni ve Gelir İdaresi yayınları) derlenmiştir. Bilgilendirme amaçlıdır; vergi danışmanlığı yerine geçmez."
          />
        </div>
      </ContentWithSidebar>
    </>
  );
}
