import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { SeoGuide } from "@/components/content/SeoGuide";
import { AuthorBox, CitationList, QuickAnswer } from "@/components/geo/GeoBlocks";
import { Breadcrumbs, ContentWithSidebar } from "@/components/layout/ContentWithSidebar";
import { GeoSchema, articleSchema, faqSchema, softwareAppSchema } from "@/components/seo/GeoSchemaHelper";
import { ResignationBuilder } from "@/components/tools/ResignationBuilder";
import { PageHero } from "@/components/ui/Reveal";
import { SITE } from "@/lib/site";

const PATH = "/araclar/istifa-dilekcesi-olusturucu";
const TITLE = "İstifa Dilekçesi Oluşturucu — Hazır Örnek ve İhbar Süresi Hesabı";
const DESC =
  "Birkaç bilgiyle yasal ihbar sürenizi hesaplayan, yazdırılabilir istifa dilekçesi oluşturun. Standart istifa, haklı nedenle fesih ve emeklilik şablonları.";

export const metadata: Metadata = pageMeta({ title: TITLE, description: DESC, path: PATH, keywords: ["istifa dilekçesi", "istifa dilekçesi örneği", "ihbar süresi hesaplama"] });

const FAQ = [
  {
    q: "İstifa eden kıdem tazminatı alabilir mi?",
    a: "Kural olarak kendi isteğiyle istifa eden işçi kıdem tazminatı alamaz. Ancak İş Kanunu md. 24'teki haklı nedenlerle fesih, emeklilik, askerlik ve kadın işçinin evlilikten itibaren bir yıl içinde ayrılması gibi durumlarda kıdem tazminatı hakkı doğar.",
  },
  {
    q: "İhbar süresi ne kadar?",
    a: "İş Kanunu md. 17'ye göre: 6 aydan az çalışmada 2 hafta, 6 ay–1,5 yıl arası 4 hafta, 1,5–3 yıl arası 6 hafta, 3 yıldan fazla çalışmada 8 haftadır.",
  },
  {
    q: "İstifa dilekçesi nasıl teslim edilmeli?",
    a: "İki nüsha hazırlayıp birini işverene teslim edin, diğerine teslim alındığına dair tarih ve imza alın. Alınmıyorsa noter veya KEP ile göndermek ispat açısından güvenlidir.",
  },
];

export default function IstifaPage() {
  return (
    <>
      <GeoSchema
        data={[
          softwareAppSchema({ name: "İstifa Dilekçesi Oluşturucu", description: DESC, path: PATH, category: "BusinessApplication" }),
          articleSchema({ title: TITLE, description: DESC, path: PATH, datePublished: "2026-02-01", dateModified: SITE.lastReviewed, section: "İş Araçları" }),
          faqSchema(FAQ),
        ]}
      />
      <PageHero
        eyebrow="Ücretsiz İş Aracı"
        title={<span className="text-neon-gradient">İstifa Dilekçesi Oluşturucu</span>}
        subtitle="Bilgilerinizi girin, dilekçeniz anında hazır olsun. Veriler tarayıcınızdan çıkmaz."
      />
      <ContentWithSidebar>
        <Breadcrumbs
          items={[
            { name: "Ana Sayfa", path: "/" },
            { name: "Araçlar", path: "/araclar/kdv-hesaplama" },
            { name: "İstifa Dilekçesi", path: PATH },
          ]}
        />
        <QuickAnswer question="İstifa dilekçesi nasıl yazılır?" updated={SITE.lastReviewed}>
          <p>
            İstifa dilekçesi işverene hitapla başlar; pozisyonunuzu, ayrılma nedeninizi, yasal ihbar sürenizi ve son çalışma gününüzü içerir. Tarih ve ıslak
            imza eklenir, iki nüsha hazırlanıp birine teslim alındı imzası alınır. İhbar süresi kıdeme göre 2 ile 8 hafta arasındadır.
          </p>
        </QuickAnswer>
        <div className="mt-10">
          <ResignationBuilder />
        </div>
        <div className="mt-20">
          <SeoGuide
            title="İstifa Süreci Rehberi"
            sections={[
              {
                id: "ihbar",
                title: "İhbar süreleri (İş Kanunu md. 17)",
                content: (
                  <table>
                    <thead>
                      <tr>
                        <th>Kıdem</th>
                        <th>İhbar süresi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>6 aydan az</td>
                        <td>2 hafta</td>
                      </tr>
                      <tr>
                        <td>6 ay – 1,5 yıl</td>
                        <td>4 hafta</td>
                      </tr>
                      <tr>
                        <td>1,5 – 3 yıl</td>
                        <td>6 hafta</td>
                      </tr>
                      <tr>
                        <td>3 yıldan fazla</td>
                        <td>8 hafta</td>
                      </tr>
                    </tbody>
                  </table>
                ),
              },
              {
                id: "hakli-neden",
                title: "Haklı nedenle fesih ne zaman mümkün?",
                content: (
                  <p>
                    İş Kanunu&apos;nun 24. maddesi; ücretin ödenmemesi, çalışma koşullarının uygulanmaması, sağlık sebepleri, ahlak ve iyi niyet kurallarına
                    aykırı davranışlar gibi durumlarda işçiye sözleşmeyi ihbar süresi beklemeden feshetme hakkı tanır. Bu durumda kıdem tazminatı hakkı korunur.
                    Gerekçenin somut ve ispatlanabilir olması önemlidir.
                  </p>
                ),
              },
              {
                id: "sss",
                title: "Sık sorulan sorular",
                content: (
                  <>
                    {FAQ.map((f) => (
                      <div key={f.q}>
                        <h3>{f.q}</h3>
                        <p>{f.a}</p>
                      </div>
                    ))}
                  </>
                ),
              },
            ]}
          />
          <CitationList
            items={[
              { title: "4857 sayılı İş Kanunu", publisher: "Mevzuat Bilgi Sistemi", url: "https://www.mevzuat.gov.tr" },
              { title: "Çalışma hayatı rehberleri", publisher: "T.C. Çalışma ve Sosyal Güvenlik Bakanlığı", url: "https://www.csgb.gov.tr" },
            ]}
          />
          <AuthorBox
            name={SITE.author.name}
            role="İş hukuku içerikleri"
            reviewed={SITE.lastReviewed}
            bio="Bilgilendirme amaçlıdır; hukuki danışmanlık yerine geçmez. Uyuşmazlık durumunda bir avukata danışın."
          />
        </div>
      </ContentWithSidebar>
    </>
  );
}
