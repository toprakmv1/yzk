import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { AdUnit } from "@/components/ads/AdUnit";
import { AuthorBox, QuickAnswer } from "@/components/geo/GeoBlocks";
import { Breadcrumbs, ContentWithSidebar } from "@/components/layout/ContentWithSidebar";
import { GeoSchema, breadcrumbSchema, faqSchema, softwareAppSchema } from "@/components/seo/GeoSchemaHelper";
import { TokenCalculator } from "@/components/tools/TokenCalculator";
import { PageHero } from "@/components/ui/Reveal";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Token Hesaplama: Metin Kaç Token? API Maliyet Hesaplayıcı",
  description:
    "Metninizin yaklaşık token sayısını (Türkçe uyumlu) hesaplayın ve ChatGPT, Claude, Grok, DeepSeek gibi modellerin API maliyetini karşılaştırın. Ücretsiz.",
  path: "/araclar/token-hesaplama",
  keywords: ["token hesaplama", "chatgpt token hesaplama", "api maliyeti", "token nedir"],
});

const FAQ = [
  {
    q: "Token nedir?",
    a: "Token, yapay zekâ modellerinin metni işlerken kullandığı küçük parçalardır. İngilizcede 1 token ortalama 4 karakter (yaklaşık 0,75 kelime) tutar; Türkçede bir kelime genellikle 1,5–3 token arasındadır.",
  },
  {
    q: "Türkçe metinler neden daha fazla token tutar?",
    a: "Tokenizer'lar çoğunlukla İngilizce ağırlıklı verilerle eğitilir. Türkçe eklemeli bir dil olduğundan ('kitaplarımızdan' gibi) uzun kelimeler birden fazla parçaya bölünür; bu da aynı içeriğin daha fazla token tutmasına ve API maliyetinin artmasına yol açar.",
  },
  {
    q: "API maliyeti nasıl hesaplanır?",
    a: "Maliyet = (giriş token'ı × giriş fiyatı + çıkış token'ı × çıkış fiyatı) / 1.000.000. Çıkış (yanıt) token'ları genellikle giriş token'larından 3–5 kat pahalıdır.",
  },
  {
    q: "ChatGPT veya Claude'un ücretsiz sürümü token sınırı koyar mı?",
    a: "Sohbet uygulamaları token yerine genellikle mesaj veya oturum limiti uygular; arka planda ise bağlam penceresi (tek seferde işlenebilen token miktarı) sınırı vardır. Detaylar için model sayfalarındaki 'Ücretsiz kota' bilgisine bakın.",
  },
];

export default function TokenPage() {
  const path = "/araclar/token-hesaplama";
  return (
    <>
      <GeoSchema
        data={[
          softwareAppSchema({
            name: "Token ve API Maliyet Hesaplayıcı",
            description: "Metnin yaklaşık token sayısını ve yapay zekâ API maliyetini hesaplayan ücretsiz araç",
            path,
            category: "UtilitiesApplication",
            featureList: ["Türkçe token tahmini", "Model bazlı maliyet karşılaştırması", "Aylık bütçe hesabı"],
          }),
          faqSchema(FAQ),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Araçlar", path: "/hangi-yapay-zeka" },
            { name: "Token Hesaplama", path },
          ]),
        ]}
      />
      <PageHero
        eyebrow="Ücretsiz araç"
        title={
          <>
            Token <span className="text-neon-gradient">hesaplayıcı</span>
          </>
        }
        subtitle="Metniniz kaç token? Hangi model ne kadar tutar? Türkçeye özel tahminle anında görün."
      />
      <ContentWithSidebar>
        <Breadcrumbs
          items={[
            { name: "Ana Sayfa", path: "/" },
            { name: "Token Hesaplama", path },
          ]}
        />
        <TokenCalculator />
        <AdUnit variant="inArticle" />
        <QuickAnswer question="Bir metin kaç token tutar?" updated={SITE.lastReviewed}>
          <p>
            Kabaca İngilizcede 4 karakter ≈ 1 token, Türkçede ise 3 karakter ≈ 1 token kabul edilebilir. 1.000 kelimelik Türkçe bir metin yaklaşık 1.600–2.200
            token tutar. Kesin sayı modelin tokenizer&apos;ına göre değişir.
          </p>
        </QuickAnswer>
        <div className="prose-neon mt-6">
          <h2>Token maliyetini düşürmenin 5 yolu</h2>
          <ol>
            <li>Gereksiz bağlamı kısaltın; uzun belgeleri parçalara bölüp yalnızca ilgili bölümü gönderin.</li>
            <li>Basit işler için küçük/hızlı modelleri (Flash, Haiku, Luna gibi) kullanın.</li>
            <li>Sabit sistem talimatları için sağlayıcının önbellek (prompt caching) özelliğini açın.</li>
            <li>Acil olmayan toplu işleri batch API ile gönderin; genellikle önemli indirim sağlar.</li>
            <li>Yanıt uzunluğunu sınırlayın (ör. &quot;en fazla 150 kelime&quot;) — çıkış token&apos;ları daha pahalıdır.</li>
          </ol>
          <h2>Sık sorulan sorular</h2>
          {FAQ.map((f) => (
            <div key={f.q}>
              <h3>{f.q}</h3>
              <p>{f.a}</p>
            </div>
          ))}
          <p>
            Kavramların ayrıntısı için <Link href="/sozluk#token">yapay zekâ sözlüğündeki token</Link> ve{" "}
            <Link href="/sozluk#baglam-penceresi">bağlam penceresi</Link> maddelerine bakın.
          </p>
        </div>
        <AuthorBox
          name={SITE.author.name}
          role="Yapay zekâ editörü"
          reviewed={SITE.lastReviewed}
          bio="Fiyatlar model sayfalarımızdaki kaynaklı verilerden alınır ve her veri güncellemesinde yenilenir."
        />
      </ContentWithSidebar>
    </>
  );
}
