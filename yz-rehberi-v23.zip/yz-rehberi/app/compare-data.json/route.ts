import { toCompare } from "@/lib/compare";
import { MODELS } from "@/lib/models";

/** Karşılaştırma aracının ihtiyaç duyduğu veri — statik JSON, yalnızca araç açıldığında yüklenir */
export const dynamic = "force-static";

export function GET() {
  return new Response(JSON.stringify(MODELS.map(toCompare)), {
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "public, max-age=3600", "X-Robots-Tag": "noindex" },
  });
}
