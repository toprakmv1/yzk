import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { IconTile, NeonIcon } from "@/components/icons/NeonIcon";
import { Monogram, PricingBadge } from "@/components/models/ModelBits";
import { GeoSchema, breadcrumbSchema, faqSchema, itemListSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { CATEGORIES, freeModels, stats } from "@/lib/models";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Ücretsiz Yapay Zeka Araçları 2026: Video, Görsel, Ses, Kod",
  description:
    "Para ödemeden kullanabileceğiniz yapay zeka araçları: ücretsiz video oluşturma, resim oluşturma, seslendirme, müzik, kod ve sohbet. Günlük kredi ve kota bilgileriyle.",
  path: "/ucretsiz-yapay-zeka",
  keywords: ["ücretsiz yapay zeka", "bedava yapay zeka", "ücretsiz yapay zeka video", "ücretsiz yapay zeka resim"],
});

export default function FreePage() {
  const s = stats();
  const all = freeModels();
  const fully = all.filter((m) => m.pricing === "ucretsiz" || m.pricing === "acik-kaynak");
  const faq = [
    {
      q: "Tamamen ücretsiz yapay zekâ var mı?",
      a: `Evet. ${fully.length} araç tamamen ücretsiz veya açık kaynak; örneğin ${fully
        .slice(0, 5)
        .map((m) => m.name)
        .join(", ")}. Diğerleri ücretsiz planla sınırlı kullanım sunar.`,
    },
    {
      q: "Ücretsiz yapay zekâ planlarının sınırı ne?",
      a: "Sohbet asistanlarında genellikle saatlik/günlük mesaj limiti, görsel ve video araçlarında günlük yenilenen krediler vardır. Ücretsiz video çıktıları çoğunlukla filigranlı ve düşük çözünürlüklüdür; ticari kullanım hakkı plan koşullarına bağlıdır.",
    },
    {
      q: "Ücretsiz yapay zekâ güvenli mi?",
      a: "Ücretsiz planlarda verileriniz model eğitiminde kullanılabilir. Ayarlardan veri paylaşımını kapatın, kişisel ve gizli bilgileri yazmayın. Gizlilik kritikse açık kaynak modelleri kendi bilgisayarınızda çalıştırın.",
    },
  ];
  return (
    <>
      <GeoSchema
        data={[
          itemListSchema(
            "Ücretsiz yapay zekâ modelleri",
            all.map((m) => ({ name: m.name, path: `/ai-araclari/${m.slug}` })),
          ),
          faqSchema(faq),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Ücretsiz Yapay Zekâ", path: "/ucretsiz-yapay-zeka" },
          ]),
        ]}
      />
      <PageHero
        eyebrow="Ücretsiz modeller paneli"
        title={
          <>
            <span className="text-glow-green text-neon-green">Ücretsiz</span> yapay zekâ modelleri
          </>
        }
        subtitle={`${s.free} model ücretsiz kullanılabiliyor. Her kategoride günlük kota, kredi ve sınırlarıyla en güçlüleri.`}
      >
        <nav aria-label="Kategoriye atla" className="mt-8 flex flex-wrap justify-center gap-2">
          {CATEGORIES.map((c) => (
            <a
              key={c.key}
              href={`#${c.slug}`}
              className="group flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] py-1.5 pl-1.5 pr-3 text-sm text-slate-200 hover:border-neon-green/50"
            >
              <IconTile name={c.key} accent={c.accent} size="sm" />
              {c.short}
            </a>
          ))}
        </nav>
      </PageHero>

      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <QuickAnswer question="En iyi ücretsiz yapay zekâ hangisi?" updated={SITE.lastReviewed}>
          <p>
            İhtiyaca göre değişir: sohbet ve yazı için{" "}
            {freeModels("sohbet")
              .slice(0, 3)
              .map((m) => m.name)
              .join(", ")}
            ; görsel için{" "}
            {freeModels("gorsel")
              .slice(0, 3)
              .map((m) => m.name)
              .join(", ")}
            ; video için{" "}
            {freeModels("video")
              .slice(0, 3)
              .map((m) => m.name)
              .join(", ")}
            ; kod için{" "}
            {freeModels("kod")
              .slice(0, 3)
              .map((m) => m.name)
              .join(", ")}{" "}
            ücretsiz planlarıyla en güçlü seçenekler.
          </p>
        </QuickAnswer>
        <AdUnit variant="leaderboard" />

        {CATEGORIES.map((c, ci) => {
          const list = freeModels(c.key);
          if (!list.length) return null;
          return (
            <section key={c.key} id={c.slug} aria-labelledby={`h-${c.slug}`} className="scroll-mt-28 py-8">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 id={`h-${c.slug}`} className="flex items-center gap-3 font-display text-2xl font-bold text-white md:text-3xl">
                  <IconTile name={c.key} accent={c.accent} />
                  Ücretsiz {c.job.toLocaleLowerCase("tr-TR")} yapay zekâları
                  <span className="font-mono text-sm text-slate-500">({list.length})</span>
                </h2>
                <Link href={`/kategori/${c.slug}`} className="text-sm text-neon-turq hover:underline">
                  {list.length > 10 ? `Tümünü gör (${list.length})` : "Ücretli dahil sıralama"} →
                </Link>
              </div>
              <ul className="mt-5 grid gap-3 md:grid-cols-2">
                {list.slice(0, 10).map((m, i) => (
                  <li key={m.slug}>
                    <Link href={`/ai-araclari/${m.slug}`} className="group glass flex h-full gap-4 rounded-2xl p-4 transition hover:border-neon-green/40">
                      <span className="w-6 shrink-0 pt-2 text-center font-display font-bold text-slate-500">{i + 1}</span>
                      <Monogram slug={m.slug} name={m.name} size="sm" />
                      <span className="min-w-0 flex-1">
                        <span className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-white group-hover:text-neon-green">{m.name}</span>
                          <PricingBadge pricing={m.pricing} />
                        </span>
                        <span className="mt-1 flex items-start gap-1.5 text-sm leading-6 text-slate-300">
                          <NeonIcon name="gift" className="mt-1 size-3.5 shrink-0 text-neon-green" />
                          {m.freeQuota}
                        </span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
              {ci % 2 === 1 && <AdUnit variant={ci % 4 === 1 ? "inArticle" : "rectangle"} />}
            </section>
          );
        })}

        <section aria-labelledby="sss" className="mx-auto mt-10 max-w-3xl">
          <h2 id="sss" className="font-display text-2xl font-bold text-white">
            Sık sorulan sorular
          </h2>
          <div className="mt-5 space-y-3">
            {faq.map((f) => (
              <details key={f.q} className="glass group rounded-2xl p-5 open:border-neon-green/40">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium text-white">
                  {f.q}
                  <span className="text-neon-green transition group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 leading-7 text-slate-400">{f.a}</p>
              </details>
            ))}
          </div>
        </section>
        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
