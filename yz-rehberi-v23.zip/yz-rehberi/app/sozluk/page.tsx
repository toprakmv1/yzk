import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { Fragment } from "react";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { GeoSchema, breadcrumbSchema, definedTermSetSchema, faqSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { GLOSSARY } from "@/lib/glossary";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Yapay Zeka Sözlüğü: LLM, Token, Prompt, RAG, MCP Nedir?",
  description: `Yapay zeka terimlerinin sade Türkçe açıklamaları: ${GLOSSARY.slice(0, 8)
    .map((t) => t.term.split(" (")[0])
    .join(", ")} ve ${GLOSSARY.length - 8} terim daha.`,
  path: "/sozluk",
});

const LETTERS = (() => {
  const set = new Set(GLOSSARY.map((t) => t.term[0].toLocaleUpperCase("tr-TR")));
  return Array.from(set).sort((a, b) => a.localeCompare(b, "tr"));
})();

export default function GlossaryPage() {
  const sorted = GLOSSARY.slice().sort((a, b) => a.term.localeCompare(b.term, "tr"));
  const byId = Object.fromEntries(GLOSSARY.map((t) => [t.id, t]));
  return (
    <>
      <GeoSchema
        data={[
          definedTermSetSchema("Yapay Zekâ Sözlüğü", "/sozluk", GLOSSARY),
          faqSchema(GLOSSARY.slice(0, 12).map((t) => ({ q: `${t.term.split(" (")[0]} nedir?`, a: t.long }))),
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: "Yapay Zekâ Sözlüğü", path: "/sozluk" },
          ]),
        ]}
      />
      <PageHero
        eyebrow={`${GLOSSARY.length} kavram`}
        title={
          <>
            Yapay zekâ <span className="text-neon-gradient">sözlüğü</span>
          </>
        }
        subtitle="Jargonsuz, örnekli tanımlar. Bir terime doğrudan bağlantı vermek için başlığının yanındaki # işaretini kullanın."
      >
        <nav aria-label="Harf dizini" className="mt-8 flex flex-wrap justify-center gap-1.5">
          {LETTERS.map((l) => (
            <a
              key={l}
              href={`#harf-${l}`}
              className="grid size-9 place-items-center rounded-lg border border-white/10 bg-white/5 font-mono text-sm text-slate-300 hover:border-neon-turq/50 hover:text-neon-turq"
            >
              {l}
            </a>
          ))}
        </nav>
      </PageHero>

      <div className="mx-auto max-w-4xl px-4 md:px-6">
        <QuickAnswer question="Yapay zekâ ile ilgili en önemli 3 kavram nedir?" updated={SITE.lastReviewed}>
          <p>
            <strong>Büyük dil modeli (LLM)</strong> metni anlayıp üreten modeldir; <strong>prompt</strong> ona verdiğiniz talimattır; <strong>token</strong> ise
            modelin metni işlediği küçük parçalardır ve limitler ile API ücretleri token üzerinden hesaplanır.
          </p>
        </QuickAnswer>
        <AdUnit variant="leaderboard" />

        <div className="space-y-4">
          {sorted.map((t, i) => {
            const letter = t.term[0].toLocaleUpperCase("tr-TR");
            const firstOfLetter = i === 0 || sorted[i - 1].term[0].toLocaleUpperCase("tr-TR") !== letter;
            return (
              <Fragment key={t.id}>
                <article id={t.id} className="glass scroll-mt-28 rounded-2xl p-6 target:border-neon-turq/60 target:shadow-glow-turq">
                  {firstOfLetter && <span id={`harf-${letter}`} className="block scroll-mt-28" />}
                  <div>
                    <h2 className="flex flex-wrap items-baseline gap-x-3 font-display text-xl font-bold text-white">
                      {t.term}
                      {t.en && <span className="text-sm font-normal text-slate-500">{t.en}</span>}
                      <a href={`#${t.id}`} aria-label={`${t.term} bağlantısı`} className="text-sm text-slate-600 hover:text-neon-turq">
                        #
                      </a>
                    </h2>
                    <p className="mt-1 text-neon-turq">{t.short}</p>
                  </div>
                  <div className="mt-3 leading-7 text-slate-300">
                    {t.long}
                    {t.example && (
                      <span className="mt-3 block rounded-xl border border-white/10 bg-black/20 p-3 text-sm text-slate-400">
                        <strong className="text-slate-200">Örnek:</strong> {t.example}
                      </span>
                    )}
                    {t.related && t.related.length > 0 && (
                      <span className="mt-3 flex flex-wrap gap-1.5 text-sm">
                        <span className="text-slate-500">İlgili:</span>
                        {t.related
                          .filter((r) => byId[r])
                          .map((r) => (
                            <a key={r} href={`#${r}`} className="chip hover:border-neon-turq/50 hover:text-white">
                              {byId[r].term.split(" (")[0]}
                            </a>
                          ))}
                      </span>
                    )}
                  </div>
                </article>
                {i > 0 && (i + 1) % 12 === 0 && <AdUnit variant={(i + 1) % 24 === 0 ? "rectangle" : "inArticle"} />}
              </Fragment>
            );
          })}
        </div>
        <AdUnit variant="multiplex" className="mt-14" />
      </div>
    </>
  );
}
