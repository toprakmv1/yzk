import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import Link from "next/link";
import { AdUnit } from "@/components/ads/AdUnit";
import { QuickAnswer } from "@/components/geo/GeoBlocks";
import { IconTile } from "@/components/icons/NeonIcon";
import { GeoSchema, breadcrumbSchema } from "@/components/seo/GeoSchemaHelper";
import { PageHero } from "@/components/ui/Reveal";
import { CATEGORIES, MODELS, PRICING_LABEL, formatMonth, isActive, type Pricing } from "@/lib/models";
import { SITE } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Yapay Zeka İstatistikleri 2026: Kategori, Fiyat ve Açık Kaynak",
  description:
    "150 yapay zeka modelinden oluşan veritabanımıza göre: hangi kategoride kaç model var, kaçı ücretsiz, kaçı açık kaynak, Türkçeyi kaçı iyi destekliyor ve aylara göre çıkışlar.",
  path: "/trendler",
});

function Bar({
  label,
  value,
  max,
  color = "from-neon-turq to-neon-blue",
  suffix = "",
  href,
}: {
  label: string;
  value: number;
  max: number;
  color?: string;
  suffix?: string;
  href?: string;
}) {
  const inner = (
    <>
      <span className="w-36 shrink-0 truncate text-sm text-slate-300 md:w-44">{label}</span>
      <span className="relative h-7 flex-1 overflow-hidden rounded-lg bg-white/[0.05]">
        <span
          className={`absolute inset-y-0 left-0 rounded-lg bg-gradient-to-r ${color} opacity-80`}
          style={{ width: `${Math.max(2, (value / max) * 100)}%` }}
        />
        <span className="relative flex h-full items-center px-2.5 font-mono text-xs font-semibold text-white">
          {value}
          {suffix}
        </span>
      </span>
    </>
  );
  return href ? (
    <Link href={href} className="flex items-center gap-3 rounded-lg hover:bg-white/[0.03]">
      {inner}
    </Link>
  ) : (
    <div className="flex items-center gap-3">{inner}</div>
  );
}

export default function TrendsPage() {
  const active = MODELS.filter(isActive);
  const total = active.length;
  const byCat = CATEGORIES.map((c) => ({
    c,
    n: active.filter((m) => m.categories.includes(c.key)).length,
    free: active.filter((m) => m.categories.includes(c.key) && m.pricing !== "ucretli").length,
  })).sort((a, b) => b.n - a.n);
  const pricing = (Object.keys(PRICING_LABEL) as Pricing[]).map((p) => ({ p, n: active.filter((m) => m.pricing === p).length }));
  const tr = ["iyi", "orta", "zayıf"].map((t) => ({ t, n: active.filter((m) => m.turkish === t).length }));
  const months = Array.from(new Set(active.map((m) => m.released)))
    .filter((x) => x >= "2025-11")
    .sort();
  const byMonth = months.map((mo) => ({ mo, n: active.filter((m) => m.released === mo).length }));
  const vendors = Object.entries(
    active.reduce<Record<string, number>>((acc, m) => ((acc[m.vendor.split(/[ (/]/)[0]] = (acc[m.vendor.split(/[ (/]/)[0]] ?? 0) + 1), acc), {}),
  )
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);
  const freeCount = active.filter((m) => m.pricing !== "ucretli").length;
  const openCount = active.filter((m) => m.openWeights).length;
  const openShare = Math.round((active.filter((m) => m.openWeights).length / total) * 100);
  const freeShare = Math.round((active.filter((m) => m.pricing !== "ucretli").length / total) * 100);
  const maxCat = Math.max(...byCat.map((x) => x.n));
  const maxMonth = Math.max(...byMonth.map((x) => x.n));

  return (
    <>
      <GeoSchema
        data={breadcrumbSchema([
          { name: "Ana Sayfa", path: "/" },
          { name: "Ekosistem İstatistikleri", path: "/trendler" },
        ])}
      />
      <PageHero
        eyebrow="Veri paneli"
        title={
          <>
            Yapay zekâ <span className="text-neon-gradient">ekosistemi</span> rakamlarla
          </>
        }
        subtitle={`Veritabanımızdaki ${total} aktif yapay zekâ modelinden hesaplanan güncel dağılımlar. Son güncelleme: ${formatMonth(SITE.lastReviewed.slice(0, 7))}.`}
      />
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <QuickAnswer question="Yapay zekâ araçlarının ne kadarı ücretsiz?" updated={SITE.lastReviewed}>
          <p>
            İncelediğimiz {total} aktif modelden <strong>{freeCount} tanesi (%{freeShare})</strong> ücretsiz plan, günlük kredi veya açık kaynak lisansla para
            ödemeden kullanılabiliyor. <strong>{openCount} model (%{openShare})</strong> açık ağırlıklı, yani kendi bilgisayarınızda çalıştırılabiliyor. En kalabalık
            kategori: {byCat[0].c.label} ({byCat[0].n} model).
          </p>
        </QuickAnswer>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { v: total, l: "aktif model", c: "text-neon-turq" },
            { v: `%${freeShare}`, l: "ücretsiz erişim", c: "text-neon-green" },
            { v: `%${openShare}`, l: "açık ağırlık", c: "text-neon-blue" },
            { v: active.filter((m) => m.isNew).length, l: "yeni çıkan / güncellenen", c: "text-neon-red" },
          ].map((s) => (
            <div key={s.l} className="glass rounded-2xl p-5">
              <p className={`font-display text-4xl font-bold ${s.c}`}>{s.v}</p>
              <p className="mt-1 text-sm text-slate-400">{s.l}</p>
            </div>
          ))}
        </div>

        <section className="glass mt-8 rounded-2xl p-6" aria-labelledby="kat">
          <h2 id="kat" className="font-display text-2xl font-bold text-white">
            Kategorilere göre model sayısı
          </h2>
          <p className="mt-1 text-sm text-slate-400">Bir model birden fazla kategoride yer alabilir. Çubuğa tıklayarak kategori sıralamasını açın.</p>
          <div className="mt-6 space-y-2">
            {byCat.map(({ c, n, free }) => (
              <div key={c.key} className="flex items-center gap-3">
                <IconTile name={c.key} accent={c.accent} size="sm" />
                <div className="flex-1">
                  <Bar label={c.label} value={n} max={maxCat} href={`/kategori/${c.slug}`} suffix={` model · ${free} ücretsiz`} />
                </div>
              </div>
            ))}
          </div>
        </section>

        <AdUnit variant="inArticle" />

        <div className="grid gap-6 md:grid-cols-2">
          <section className="glass rounded-2xl p-6" aria-labelledby="fiyat">
            <h2 id="fiyat" className="font-display text-xl font-bold text-white">
              Fiyat modeline göre dağılım
            </h2>
            <div className="mt-5 space-y-2">
              {pricing.map(({ p, n }) => (
                <Bar
                  key={p}
                  label={PRICING_LABEL[p]}
                  value={n}
                  max={total}
                  color={p === "ucretli" ? "from-neon-red to-neon-red/60" : "from-neon-green to-neon-turq"}
                />
              ))}
            </div>
          </section>
          <section className="glass rounded-2xl p-6" aria-labelledby="turkce">
            <h2 id="turkce" className="font-display text-xl font-bold text-white">
              Türkçe desteği
            </h2>
            <div className="mt-5 space-y-2">
              {tr.map(({ t, n }) => (
                <Bar
                  key={t}
                  label={t === "iyi" ? "İyi" : t === "orta" ? "Orta" : "Zayıf"}
                  value={n}
                  max={total}
                  color={t === "iyi" ? "from-neon-green to-neon-turq" : t === "orta" ? "from-neon-blue to-neon-turq" : "from-slate-500 to-slate-600"}
                />
              ))}
            </div>
          </section>
        </div>

        <section className="glass mt-6 rounded-2xl p-6" aria-labelledby="ay">
          <h2 id="ay" className="font-display text-xl font-bold text-white">
            Aylara göre çıkan / güncellenen modeller
          </h2>
          <div className="mt-6 flex h-56 items-end gap-2">
            {byMonth.map(({ mo, n }) => (
              <div key={mo} className="flex flex-1 flex-col items-center justify-end gap-2">
                <span className="font-mono text-xs text-slate-300">{n}</span>
                <span
                  className="w-full rounded-t-lg bg-gradient-to-t from-neon-turq/40 to-neon-turq shadow-glow-turq"
                  style={{ height: `${(n / maxMonth) * 100}%` }}
                />
                <span className="text-[10px] text-slate-500">{formatMonth(mo).slice(0, 3)}</span>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs text-slate-500">Her model, veritabanımızdaki son büyük sürümünün ayına göre sayılır.</p>
        </section>

        <section className="glass mt-6 rounded-2xl p-6" aria-labelledby="sirket">
          <h2 id="sirket" className="font-display text-xl font-bold text-white">
            En çok modeli listelenen şirketler
          </h2>
          <div className="mt-5 space-y-2">
            {vendors.map(([v, n]) => (
              <Bar key={v} label={v} value={n} max={vendors[0][1]} color="from-neon-blue to-neon-turq" />
            ))}
          </div>
        </section>

        <p className="mt-6 text-sm text-slate-500">
          Metodoloji: Tüm rakamlar, sitemizdeki model veritabanından (her kayıtta kaynak bağlantılarıyla) otomatik hesaplanır. Veritabanı her ürünü değil,
          Türkiye&apos;deki kullanıcılar için en önemli ve erişilebilir araçları kapsar.
        </p>
        <AdUnit variant="multiplex" className="mt-12" />
      </div>
    </>
  );
}
