import type { Metadata, Viewport } from "next";
import { Inter, JetBrains_Mono, Space_Grotesk } from "next/font/google";
import Script from "next/script";
import type { ReactNode } from "react";
import { MobileAnchorAd } from "@/components/ads/AdUnit";
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { SearchDialog } from "@/components/search/SearchDialog";
import { GeoSchema, organizationSchema, websiteSchema } from "@/components/seo/GeoSchemaHelper";
import { ADSENSE, SITE, VERIFY } from "@/lib/site";
import "./globals.css";

const display = Space_Grotesk({ subsets: ["latin", "latin-ext"], variable: "--nf-display", display: "swap" });
const sans = Inter({ subsets: ["latin", "latin-ext"], variable: "--nf-sans", display: "swap" });
const mono = JetBrains_Mono({ subsets: ["latin", "latin-ext"], variable: "--nf-mono", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: {
    default: `${SITE.name} — Ücretsiz ve En İyi Yapay Zeka Araçları (2026)`,
    template: `%s | ${SITE.name}`,
  },
  description: SITE.description,
  applicationName: SITE.name,
  keywords: [
    "yapay zeka",
    "ücretsiz yapay zeka",
    "en iyi yapay zeka",
    "yapay zeka video oluşturma",
    "yapay zeka resim oluşturma",
    "yapay zeka nasıl kullanılır",
    "ChatGPT",
    "Gemini",
    "Claude",
    "Midjourney",
    "prompt",
  ],
  authors: [{ name: SITE.author.name, url: SITE.author.url }],
  creator: SITE.name,
  publisher: SITE.name,
  category: "technology",
  formatDetection: { telephone: false, email: false, address: false },
  // NOT: canonical burada TANIMLANMAZ — aksi halde kendi canonical'ı olmayan her sayfa ana sayfayı işaret eder.
  // Her sayfa canonical/OG/Twitter etiketlerini lib/seo.ts → pageMeta() ile kendisi üretir.
  openGraph: {
    type: "website",
    locale: SITE.locale,
    siteName: SITE.name,
  },
  twitter: { card: "summary_large_image", site: SITE.twitter },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1, "max-video-preview": -1 },
  },
  // Google Search Console / AdSense site doğrulaması
  // Search Console, Bing Webmaster Tools ve Yandex Webmaster (Türkiye'de Yandex trafiği önemlidir)
  verification: {
    google: VERIFY.google,
    yandex: VERIFY.yandex,
    other: VERIFY.bing ? { "msvalidate.01": VERIFY.bing } : undefined,
  },
  other: ADSENSE.client ? { "google-adsense-account": ADSENSE.client } : {},
};

export const viewport: Viewport = {
  themeColor: "#020a14",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr" className={`dark ${display.variable} ${sans.variable} ${mono.variable}`}>
      <body className="min-h-dvh bg-space-950 text-slate-200 antialiased">
        <GeoSchema id="site-schema" data={[organizationSchema(), websiteSchema()]} />
        <Header />
        <main id="icerik">{children}</main>
        <Footer />
        <MobileAnchorAd />
        <SearchDialog />

        {/* Google Analytics 4 — yalnızca NEXT_PUBLIC_GA_ID tanımlıysa (trafik ölçümü olmadan SEO iyileştirmesi yapılamaz) */}
        {VERIFY.ga4 && (
          <>
            <Script id="ga4-src" strategy="afterInteractive" src={`https://www.googletagmanager.com/gtag/js?id=${VERIFY.ga4}`} />
            <Script id="ga4-init" strategy="afterInteractive">
              {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${VERIFY.ga4}');`}
            </Script>
          </>
        )}

        {/* AdSense: yalnızca client ID tanımlıysa ve etkileşimden sonra yüklenir (LCP'yi etkilemez) */}
        {ADSENSE.client && (
          <Script
            id="adsense"
            async
            strategy="lazyOnload"
            crossOrigin="anonymous"
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE.client}`}
          />
        )}
      </body>
    </html>
  );
}
