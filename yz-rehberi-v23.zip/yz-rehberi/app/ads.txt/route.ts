import { ADSENSE } from "@/lib/site";

/**
 * /ads.txt — AdSense yetkili satıcı beyanı.
 * NEXT_PUBLIC_ADSENSE_CLIENT (ca-pub-XXXX) tanımlıysa otomatik üretilir.
 * Eksik ads.txt, AdSense panelinde "Gelir kaybı riski" uyarısına yol açar.
 */
export const dynamic = "force-static";

export function GET() {
  const pub = ADSENSE.client.replace(/^ca-/, "");
  const body = pub ? `google.com, ${pub}, DIRECT, f08c47fec0942fa0\n` : "# AdSense yayıncı kimliği henüz tanımlanmadı (NEXT_PUBLIC_ADSENSE_CLIENT)\n";
  return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "public, max-age=86400" } });
}
