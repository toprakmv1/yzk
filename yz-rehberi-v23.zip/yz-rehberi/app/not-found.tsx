import Link from "next/link";

export default function NotFound() {
  return (
    <section className="grid min-h-[80svh] place-items-center px-4 text-center">
      <div>
        <p className="font-display text-8xl font-bold text-neon-gradient">404</p>
        <h1 className="mt-4 font-display text-2xl font-semibold text-white">Bu sayfa uzay boşluğunda kayboldu</h1>
        <p className="mt-2 text-slate-400">Aradığınız sayfa taşınmış veya hiç var olmamış olabilir.</p>
        <Link href="/" className="btn-neon mt-8">
          Ana sayfaya dön
        </Link>
      </div>
    </section>
  );
}
