import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/ui/Reveal";
import { LEGAL_PAGES } from "@/lib/legal";
import { GeoSchema, breadcrumbSchema } from "@/components/seo/GeoSchemaHelper";
import { SITE, absoluteUrl } from "@/lib/site";

type Props = { params: Promise<{ sayfa: string }> };

export function generateStaticParams() {
  return Object.keys(LEGAL_PAGES).map((sayfa) => ({ sayfa }));
}
export const dynamicParams = false;

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { sayfa } = await params;
  const p = LEGAL_PAGES[sayfa];
  return p ? pageMeta({ title: p.title, description: p.description, path: `/${sayfa}` }) : {};
}

export default async function LegalPage({ params }: Props) {
  const { sayfa } = await params;
  const p = LEGAL_PAGES[sayfa];
  if (!p) notFound();
  return (
    <>
      <GeoSchema
        data={[
          breadcrumbSchema([
            { name: "Ana Sayfa", path: "/" },
            { name: p.title, path: `/${sayfa}` },
          ]),
          ...(sayfa === "iletisim"
            ? [{ "@type": "ContactPage", name: p.title, url: absoluteUrl("/iletisim"), about: { "@id": absoluteUrl("/#organization") } }]
            : sayfa === "hakkimizda"
              ? [{ "@type": "AboutPage", name: p.title, url: absoluteUrl("/hakkimizda"), about: { "@id": absoluteUrl("/#organization") } }]
              : []),
        ]}
      />
      <PageHero eyebrow={SITE.name} title={p.title} />
      <div className="prose-neon mx-auto max-w-3xl px-4 md:px-6">
        {p.body.map((b) => {
          // E-posta adresini tıklanabilir mailto bağlantısına çevir
          const parts = b.split(SITE.contactEmail);
          return (
            <p key={b}>
              {parts.map((part, i) => (
                <span key={i}>
                  {part}
                  {i < parts.length - 1 && <a href={`mailto:${SITE.contactEmail}`}>{SITE.contactEmail}</a>}
                </span>
              ))}
            </p>
          );
        })}
        <p className="text-sm text-slate-500">Son güncelleme: {new Date(SITE.lastReviewed).toLocaleDateString("tr-TR", { dateStyle: "long" })}</p>
      </div>
    </>
  );
}
