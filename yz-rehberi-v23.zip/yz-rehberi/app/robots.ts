import type { MetadataRoute } from "next";
import { SITE } from "@/lib/site";

/**
 * robots.txt
 *
 * ÖNEMLİ: "/_next/" klasörü ENGELLENMEMELİDİR. Google sayfayı işlerken (render) CSS ve JavaScript dosyalarını
 * buradan indirir; engellenirse sayfalar "mobil uyumlu değil / içerik eksik" olarak değerlendirilir.
 *
 * Yapay zekâ yanıt motorlarında (ChatGPT arama, Perplexity, Google AI Overviews, Claude) görünür olmak GEO'nun
 * hedefi olduğu için LLM tarayıcılarına izin verilir. Eğitim amaçlı taramayı engellemek isterseniz ilgili botu
 * `disallow: "/"` yapın.
 */
export default function robots(): MetadataRoute.Robots {
  const aiBots = [
    "GPTBot",
    "OAI-SearchBot",
    "ChatGPT-User",
    "ClaudeBot",
    "Claude-User",
    "Claude-SearchBot",
    "PerplexityBot",
    "Perplexity-User",
    "Google-Extended",
    "Applebot-Extended",
    "CCBot",
  ];
  return {
    rules: [
      // Site içi arama sonuçları taranmaz (tarama bütçesi korunur). JSON uç noktaları X-Robots-Tag ile noindex.
      { userAgent: "*", allow: "/", disallow: ["/api/", "/ara?"] },
      { userAgent: "Mediapartners-Google", allow: "/" }, // AdSense tarayıcısı — asla engellemeyin
      { userAgent: "AdsBot-Google", allow: "/" },
      ...aiBots.map((userAgent) => ({ userAgent, allow: "/" })),
    ],
    sitemap: `${SITE.url}/sitemap.xml`,
    host: SITE.url,
  };
}
