/**
 * Model meta verileri (tipler, kategoriler, etiketler, biçimlendiriciler).
 * VERİ İÇERMEZ — istemci bileşenleri yalnızca bu dosyadan içe aktarmalı ki
 * models.json tarayıcı paketine girmesin.
 *
 * Yapay zekâ model/araç veritabanı katmanı.
 * Kaynak: data/models.json (her kaydın `sources` alanında birincil kaynak bağlantıları vardır).
 * Bu dosya yalnızca saf fonksiyonlar içerir; hem sunucu hem istemci tarafında kullanılabilir.
 */

export type CategoryKey = "sohbet" | "kod" | "gorsel" | "video" | "ses" | "muzik" | "3d" | "sunum" | "avatar" | "arastirma" | "ajan" | "acik-kaynak";

export type Pricing = "ucretsiz" | "freemium" | "acik-kaynak" | "ucretli";

export type Model = {
  slug: string;
  name: string;
  vendor: string;
  categories: CategoryKey[];
  primaryCategory: CategoryKey;
  pricing: Pricing;
  freeTier: string;
  freeQuota: string;
  paidFrom: string | null;
  spec: string;
  apiFree: string | null;
  /** Editoryal güç puanı (0–100) — kategori içi göreli değerlendirme */
  power: number;
  latestVersion: string;
  /** YYYY-MM */
  released: string;
  isNew: boolean;
  openWeights: boolean;
  url: string;
  tagline: string;
  description: string;
  bestFor: string[];
  howTo: string[];
  proTips: string[];
  skills: string[];
  promptExample: string;
  pros: string[];
  cons: string[];
  turkish: "iyi" | "orta" | "zayıf" | string;
  platforms: string[] | null;
  sources: string[];
  status: "aktif" | "kapandi" | string;
};


export type Accent = "turq" | "blue" | "green" | "red";

export type CategoryMeta = {
  key: CategoryKey;
  /** URL parçası: /kategori/{slug} */
  slug: string;
  label: string;
  short: string;
  /** "Video oluşturma" gibi işlev adı — başlıklarda kullanılır */
  job: string;
  accent: Accent;
  intro: string;
  keywords: string[];
};

export const CATEGORIES: CategoryMeta[] = [
  {
    key: "sohbet",
    slug: "sohbet-asistanlari",
    label: "Sohbet Asistanları",
    short: "Sohbet",
    job: "Sohbet ve yazı",
    accent: "turq",
    intro: "Soru sormak, metin yazmak, özetlemek, çeviri ve günlük işler için genel amaçlı yapay zekâ asistanları.",
    keywords: ["chatgpt alternatifi", "ücretsiz yapay zeka sohbet", "türkçe yapay zeka"],
  },
  {
    key: "gorsel",
    slug: "gorsel-olusturma",
    label: "Görsel Oluşturma",
    short: "Görsel",
    job: "Görsel oluşturma",
    accent: "blue",
    intro: "Yazıdan resim üreten, fotoğraf düzenleyen, logo ve afiş tasarlayan yapay zekâ modelleri.",
    keywords: ["yapay zeka resim oluşturma", "ücretsiz görsel oluşturma", "text to image"],
  },
  {
    key: "video",
    slug: "video-olusturma",
    label: "Video Oluşturma",
    short: "Video",
    job: "Video oluşturma",
    accent: "red",
    intro: "Yazıdan veya fotoğraftan video üreten, sahneleri canlandıran ve kısa film oluşturan yapay zekâ araçları.",
    keywords: ["yapay zeka video oluşturma", "ücretsiz video yapay zeka", "text to video"],
  },
  {
    key: "ses",
    slug: "ses-seslendirme",
    label: "Ses ve Seslendirme",
    short: "Ses",
    job: "Seslendirme ve ses",
    accent: "green",
    intro: "Metni doğal sese çeviren (TTS), ses klonlayan, konuşmayı yazıya döken yapay zekâ modelleri.",
    keywords: ["yapay zeka seslendirme", "metni sese çevirme", "türkçe tts"],
  },
  {
    key: "muzik",
    slug: "muzik-olusturma",
    label: "Müzik Oluşturma",
    short: "Müzik",
    job: "Müzik ve şarkı üretimi",
    accent: "turq",
    intro: "Sözlü şarkı, enstrümantal müzik ve jingle üreten yapay zekâ araçları.",
    keywords: ["yapay zeka şarkı yapma", "yapay zeka müzik oluşturma", "suno alternatifi"],
  },
  {
    key: "kod",
    slug: "kodlama",
    label: "Kodlama ve Geliştirme",
    short: "Kod",
    job: "Kod yazma",
    accent: "blue",
    intro: "Kod yazan, hata ayıklayan, uygulama ve web sitesi geliştiren yapay zekâ asistanları ve ajanlar.",
    keywords: ["yapay zeka kod yazma", "ücretsiz kodlama asistanı", "vibe coding"],
  },
  {
    key: "ajan",
    slug: "ajanlar-otomasyon",
    label: "Ajanlar ve Otomasyon",
    short: "Ajan",
    job: "Otomasyon ve ajan",
    accent: "green",
    intro: "Görevleri sizin yerinize adım adım yürüten yapay zekâ ajanları ve iş akışı otomasyon araçları.",
    keywords: ["yapay zeka ajan", "otomasyon araçları", "ai agent"],
  },
  {
    key: "arastirma",
    slug: "arastirma",
    label: "Araştırma ve Arama",
    short: "Araştırma",
    job: "Araştırma",
    accent: "turq",
    intro: "Kaynak göstererek araştıran, belgeleri analiz eden ve not çıkaran yapay zekâ araçları.",
    keywords: ["yapay zeka araştırma", "kaynaklı yapay zeka", "perplexity alternatifi"],
  },
  {
    key: "sunum",
    slug: "sunum-hazirlama",
    label: "Sunum ve Belge",
    short: "Sunum",
    job: "Sunum hazırlama",
    accent: "red",
    intro: "Slayt, sunum, doküman ve infografik hazırlayan yapay zekâ araçları.",
    keywords: ["yapay zeka sunum hazırlama", "ücretsiz sunum yapay zeka", "slayt oluşturma"],
  },
  {
    key: "avatar",
    slug: "avatar-dijital-insan",
    label: "Avatar ve Dijital İnsan",
    short: "Avatar",
    job: "Konuşan avatar",
    accent: "blue",
    intro: "Konuşan avatar, dudak senkronu ve dijital sunucu videoları üreten yapay zekâ araçları.",
    keywords: ["konuşan avatar", "yapay zeka avatar video", "dijital insan"],
  },
  {
    key: "3d",
    slug: "3d-model-olusturma",
    label: "3D Model Oluşturma",
    short: "3D",
    job: "3D model üretimi",
    accent: "green",
    intro: "Yazıdan veya görselden 3D model, sahne ve oyun varlığı üreten yapay zekâ araçları.",
    keywords: ["yapay zeka 3d model", "text to 3d", "görselden 3d model"],
  },
  {
    key: "acik-kaynak",
    slug: "acik-kaynak-modeller",
    label: "Açık Kaynak Modeller",
    short: "Açık kaynak",
    job: "Yerelde çalıştırma",
    accent: "turq",
    intro: "Ağırlıkları indirilebilen, kendi bilgisayarınızda veya sunucunuzda ücretsiz çalıştırabileceğiniz modeller.",
    keywords: ["açık kaynak yapay zeka", "yerel llm", "ollama modelleri"],
  },
];

export const CATEGORY_BY_KEY = Object.fromEntries(CATEGORIES.map((c) => [c.key, c])) as Record<CategoryKey, CategoryMeta>;
export const CATEGORY_BY_SLUG = Object.fromEntries(CATEGORIES.map((c) => [c.slug, c])) as Record<string, CategoryMeta>;

export const PRICING_LABEL: Record<Pricing, string> = {
  ucretsiz: "Tamamen ücretsiz",
  freemium: "Ücretsiz plan var",
  "acik-kaynak": "Açık kaynak",
  ucretli: "Ücretli",
};

export const TURKISH_LABEL: Record<string, string> = { iyi: "Türkçe: iyi", orta: "Türkçe: orta", zayıf: "Türkçe: zayıf" };

export const ACCENT_RGB: Record<Accent, string> = {
  turq: "0 245 212",
  blue: "92 214 255",
  green: "61 255 143",
  red: "255 69 102",
};

const MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
export function formatMonth(ym: string) {
  const [y, mo] = ym.split("-").map(Number);
  if (!y || !mo) return ym;
  return `${MONTHS[mo - 1]} ${y}`;
}

export function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

/** Arama / kart gibi istemci bileşenleri için hafif özet (yük boyutunu küçültür) */
export type ModelLite = Pick<
  Model,
  | "slug"
  | "name"
  | "vendor"
  | "categories"
  | "primaryCategory"
  | "pricing"
  | "freeQuota"
  | "power"
  | "released"
  | "isNew"
  | "openWeights"
  | "tagline"
  | "turkish"
  | "status"
  | "latestVersion"
>;

export function toLite(m: Model): ModelLite {
  const { slug, name, vendor, categories, primaryCategory, pricing, freeQuota, power, released, isNew, openWeights, tagline, turkish, status, latestVersion } =
    m;
  return { slug, name, vendor, categories, primaryCategory, pricing, freeQuota, power, released, isNew, openWeights, tagline, turkish, status, latestVersion };
}

/** Basit, deterministik monogram rengi */
export function accentFor(slug: string): Accent {
  const list: Accent[] = ["turq", "blue", "green", "red"];
  let h = 0;
  for (const ch of slug) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return list[h % list.length];
}

export function initials(name: string) {
  const clean = name.replace(/\(.*?\)/g, "").trim();
  const parts = clean.split(/[\s\-.]+/).filter(Boolean);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

/** Kaynak bağlantısı için okunabilir başlık: "openai.com/pricing" */
export function sourceTitle(url: string) {
  try {
    const u = new URL(url);
    const path = decodeURIComponent(u.pathname).replace(/\/$/, "");
    return u.hostname.replace(/^www\./, "") + (path.length > 60 ? path.slice(0, 57) + "…" : path) || url;
  } catch {
    return url;
  }
}
