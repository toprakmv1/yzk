/**
 * Birleşik prompt kütüphanesi:
 *  1) Editör seçkisi mega promptlar (lib/data.ts)
 *  2) Adım adım rehberlerdeki gerçek kullanım senaryoları (data/guides.json)
 *  3) Her modelin sayfasındaki örnek prompt (data/models.json)
 */
import { MEGA_PROMPTS, type MegaPrompt, type PromptCategory } from "@/lib/data";
import { GUIDES } from "@/lib/guides";
import { MODELS, getModel, isActive, type CategoryKey } from "@/lib/models";

const CAT_MAP: Partial<Record<CategoryKey, PromptCategory>> = {
  sohbet: "Günlük",
  kod: "Kod",
  gorsel: "Görsel",
  video: "Video",
  ses: "Ses",
  muzik: "Müzik",
  "3d": "3D",
  sunum: "İş",
  avatar: "Video",
  arastirma: "Araştırma",
  ajan: "İş",
};

function categoryOf(cats: CategoryKey[]): PromptCategory {
  for (const c of cats) if (CAT_MAP[c]) return CAT_MAP[c]!;
  return "Günlük";
}

const fromGuides: MegaPrompt[] = GUIDES.flatMap((g) => {
  const m = getModel(g.toolSlug);
  return g.useCases.map((u, i) => ({
    id: `${g.toolSlug}-kullanim-${i + 1}`,
    title: u.title,
    category: categoryOf(m?.categories ?? ["sohbet"]),
    tool: g.toolName,
    description: `${g.toolName} rehberimizden test edilmiş kullanım senaryosu.`,
    prompt: u.prompt,
  }));
});

const fromModels: MegaPrompt[] = MODELS.filter((m) => isActive(m) && m.promptExample && m.promptExample.length > 30).map((m) => ({
  id: `${m.slug}-ornek`,
  title: `${m.name} için örnek prompt`,
  category: categoryOf(m.categories),
  tool: m.name,
  description: m.tagline,
  prompt: m.promptExample,
}));

export const ALL_PROMPTS: MegaPrompt[] = [...MEGA_PROMPTS, ...fromGuides, ...fromModels];
