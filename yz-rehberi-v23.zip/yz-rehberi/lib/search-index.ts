/**
 * Site içi arama dizini — derleme zamanında /search-index.json olarak üretilir.
 */
import { TUTORIALS } from "@/lib/data";
import type { SearchDoc } from "@/lib/fuzzy";
import { GLOSSARY } from "@/lib/glossary";
import { GUIDES } from "@/lib/guides";
import { CATEGORIES, CATEGORY_BY_KEY, MODELS, PRICING_LABEL } from "@/lib/models";
import { ALL_PROMPTS } from "@/lib/prompts";
import { TUTORIAL_BODIES } from "@/lib/tutorials-content";

export const STATIC_PAGES: SearchDoc[] = [
  {
    t: "Ücretsiz yapay zekâ modelleri",
    u: "/ucretsiz-yapay-zeka",
    k: "Liste",
    d: "Tamamen ücretsiz veya ücretsiz planı olan tüm yapay zekâ araçları, kotalarıyla.",
    x: "bedava free ücretsiz ai",
    w: 1,
  },
  {
    t: "En güçlü yapay zekâ modelleri",
    u: "/en-guclu-yapay-zeka",
    k: "Liste",
    d: "Kategorilere göre en güçlü yapay zekâ modelleri sıralaması.",
    x: "en iyi top 10 sıralama leaderboard",
    w: 1,
  },
  {
    t: "Yeni çıkan yapay zekâ modelleri",
    u: "/yeni-yapay-zeka-modelleri",
    k: "Liste",
    d: "Son aylarda çıkan ve güncellenen yapay zekâ modelleri.",
    x: "yeni güncel son çıkan",
    w: 1,
  },
  { t: "Tüm yapay zekâ araçları", u: "/ai-araclari", k: "Liste", d: "Filtrelenebilir yapay zekâ modeli dizini.", x: "dizin katalog liste", w: 0.9 },
  {
    t: "Hangi yapay zekâyı kullanmalıyım?",
    u: "/hangi-yapay-zeka",
    k: "Araç",
    d: "3 soruda size en uygun yapay zekâ aracını bulun.",
    x: "öneri sihirbaz test seçim",
    w: 0.9,
  },
  { t: "Yapay zekâ karşılaştırma", u: "/karsilastir", k: "Araç", d: "Modelleri yan yana karşılaştırın.", x: "vs karşılaştır fark hangisi", w: 0.9 },
  {
    t: "Token hesaplayıcı",
    u: "/araclar/token-hesaplama",
    k: "Araç",
    d: "Metninizin yaklaşık token sayısını ve API maliyetini hesaplayın.",
    x: "token sayacı maliyet api fiyat",
    w: 0.9,
  },
  {
    t: "Yapay zekâ sözlüğü",
    u: "/sozluk",
    k: "Sözlük",
    d: "LLM, token, prompt, RAG gibi kavramların sade Türkçe açıklamaları.",
    x: "terimler kavramlar nedir",
    w: 0.8,
  },
  { t: "Mega prompt kütüphanesi", u: "/mega-promptlar", k: "Prompt", d: "Kopyala-yapıştır hazır promptlar.", x: "prompt örnekleri hazır komut", w: 0.8 },
  {
    t: "Yapay zekâ ekosistemi istatistikleri",
    u: "/trendler",
    k: "Veri",
    d: "Kategori, fiyat ve Türkçe desteğe göre yapay zekâ dağılımı.",
    x: "trend istatistik grafik",
    w: 0.6,
  },
  { t: "KDV hesaplama", u: "/araclar/kdv-hesaplama", k: "Araç", d: "KDV dahil/hariç hesaplama aracı.", x: "kdv vergi", w: 0.5 },
  { t: "İstifa dilekçesi oluşturucu", u: "/araclar/istifa-dilekcesi-olusturucu", k: "Araç", d: "Hazır istifa dilekçesi.", x: "dilekçe istifa", w: 0.5 },
];

export function buildSearchIndex(): SearchDoc[] {
  const docs: SearchDoc[] = [...STATIC_PAGES];

  for (const c of CATEGORIES) {
    docs.push({ t: `${c.label} yapay zekâ araçları`, u: `/kategori/${c.slug}`, k: "Kategori", d: c.intro, x: `${c.keywords.join(" ")} en iyi`, w: 0.95 });
    docs.push({
      t: `Ücretsiz ${c.job.toLocaleLowerCase("tr-TR")} yapay zekâları`,
      u: `/ucretsiz-yapay-zeka#${c.slug}`,
      k: "Ücretsiz",
      d: `Para ödemeden kullanılabilen ${c.label.toLocaleLowerCase("tr-TR")} araçları ve kotaları.`,
      x: `bedava free ${c.short}`,
      w: 0.95,
    });
  }

  for (const m of MODELS) {
    const cats = m.categories.map((k) => CATEGORY_BY_KEY[k]?.short).join(" ");
    docs.push({
      t: m.name,
      u: `/ai-araclari/${m.slug}`,
      k: m.status === "kapandi" ? "Model · kapandı" : `Model · ${PRICING_LABEL[m.pricing]}`,
      d: m.tagline,
      x: `${m.vendor} ${m.latestVersion} ${cats} ${m.bestFor.join(" ")} ${m.skills.join(" ")}`,
      w: Math.min(1, m.power / 100),
    });
  }

  for (const g of GUIDES) {
    docs.push({
      t: g.title,
      u: `/egitimler/${g.slug}`,
      k: "Rehber",
      d: g.metaDescription,
      x: `${g.toolName} nasıl kullanılır adım adım ${g.steps.map((s) => s.title).join(" ")}`,
      w: 1,
    });
  }
  for (const t of TUTORIALS.filter((t) => TUTORIAL_BODIES[t.slug])) {
    docs.push({ t: t.title, u: `/egitimler/${t.slug}`, k: "Eğitim", d: t.summary, w: 0.85 });
  }

  for (const term of GLOSSARY) {
    docs.push({ t: `${term.term} nedir?`, u: `/sozluk#${term.id}`, k: "Sözlük", d: term.short, x: term.en, w: 0.7 });
  }

  for (const p of ALL_PROMPTS.slice(0, 80)) {
    docs.push({ t: p.title, u: `/mega-promptlar#${p.id}`, k: "Prompt", d: p.description, x: `${p.tool} ${p.category}`, w: 0.4 });
  }

  return docs;
}
