import { SITE } from "@/lib/site";

/**
 * AdSense onayı için ZORUNLU kurumsal sayfalar (Hakkımızda, İletişim, Gizlilik, Çerez, Kullanım Koşulları).
 * Metinler yayına hazırdır; şirketleşme durumunuza göre unvan/adres bilgisini ve iletişim e-postasını
 * (.env → NEXT_PUBLIC_CONTACT_EMAIL) güncelleyin. Hukuki kesinlik gereken durumlarda bir hukukçuya kontrol ettirin.
 */
export type LegalPage = { title: string; description: string; body: string[] };

const mail = SITE.contactEmail;

export const LEGAL_PAGES: Record<string, LegalPage> = {
  hakkimizda: {
    title: "Hakkımızda",
    description: `${SITE.name} kimdir? Yapay zeka araçlarını Türkçe, tarafsız ve kaynaklı biçimde anlatan bağımsız yayın platformu hakkında bilgi.`,
    body: [
      `${SITE.name}, yapay zekâyı herkes için anlaşılır ve kullanılabilir kılmayı amaçlayan bağımsız bir Türkçe yayın platformudur. Sohbet asistanlarından video, görsel, ses, müzik ve kodlama araçlarına kadar 150'yi aşkın yapay zekâ modelini tek bir yerde, aynı ölçütlerle karşılaştırırız.`,
      "Her model sayfası; ücretsiz kota, ücretli planlar, API/token fiyatı, Türkçe desteği, desteklenen platformlar ve adım adım kullanım bilgisini içerir. Bilgiler sağlayıcıların resmî dokümantasyonu, fiyat sayfaları ve güvenilir kaynaklardan derlenir; kaynak bağlantıları her sayfanın sonunda listelenir.",
      "Editör ekibimiz araçları bizzat dener, kullanım rehberlerini gerçek senaryolarla hazırlar ve veritabanını düzenli olarak günceller. Sıralamalarda hiçbir şirketten ücret, komisyon veya sponsorluk almayız; yayın giderlerimiz sayfalarda gösterilen ve 'Reklam' olarak etiketlenen Google AdSense reklamlarıyla karşılanır.",
      `Bir hata fark ettiyseniz, eklenmesini istediğiniz bir araç varsa veya iş birliği teklifiniz bulunuyorsa ${mail} adresinden bize ulaşabilirsiniz.`,
    ],
  },
  iletisim: {
    title: "İletişim",
    description: `${SITE.name} ile iletişime geçin: düzeltme talepleri, araç ekleme önerileri, reklam ve iş birliği.`,
    body: [
      `Görüş, öneri, düzeltme talepleri ve iş birliği teklifleriniz için e-posta adresimiz: ${mail}`,
      "Düzeltme taleplerinde ilgili sayfanın bağlantısını ve doğru bilginin kaynağını eklemeniz, kontrol sürecini hızlandırır. Doğrulanan düzeltmeleri güncelleme tarihiyle birlikte yayınlarız.",
      "Yeni bir yapay zekâ aracının veritabanına eklenmesini öneriyorsanız aracın adını, resmî web sitesini ve fiyatlandırma sayfasını paylaşın. Ekleme kararı editoryal ilkelerimize göre verilir ve ücret karşılığı yapılmaz.",
      "Kişisel verilerinize ilişkin KVKK kapsamındaki başvurularınızı da aynı adrese, konu satırına 'KVKK Başvurusu' yazarak iletebilirsiniz.",
      "Yanıt süremiz genellikle 2 iş günüdür.",
    ],
  },
  "gizlilik-politikasi": {
    title: "Gizlilik Politikası",
    description: `${SITE.name} gizlilik politikası ve KVKK aydınlatma metni: hangi veriler işlenir, çerezler, Google AdSense ve haklarınız.`,
    body: [
      `Bu politika, ${SITE.url.replace(/^https?:\/\//, "")} adresindeki web sitesini (“Site”) ziyaret ettiğinizde hangi kişisel verilerin, hangi amaçlarla işlendiğini açıklar ve 6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında aydınlatma metni niteliğindedir. Veri sorumlusu ${SITE.name}'dir; iletişim: ${mail}.`,
      "İşlenen veriler: Sitemizde üyelik veya form bulunmaz; adınızı, telefonunuzu ya da adresinizi toplamayız. Ziyaretiniz sırasında tarayıcınızın otomatik olarak ilettiği teknik veriler (IP adresi, tarayıcı ve cihaz türü, ziyaret edilen sayfalar, tarih-saat) güvenlik, hata ayıklama ve istatistik amacıyla barındırma altyapısı tarafından kayıt altına alınabilir. Bize e-posta gönderirseniz e-posta adresiniz ve mesajınız yalnızca yanıt vermek amacıyla işlenir.",
      "Hesaplama araçları: KDV, token ve dilekçe gibi araçlarımıza girdiğiniz veriler yalnızca tarayıcınızda işlenir; sunucularımıza gönderilmez ve saklanmaz.",
      "Reklamlar: Google AdSense dahil üçüncü taraf satıcılar, kullanıcının bu siteye veya diğer sitelere yaptığı önceki ziyaretlere dayalı reklam sunmak için çerez kullanır. Google'ın reklam çerezlerini kullanması, Google ve iş ortaklarının kullanıcılara bu site ve/veya internetteki diğer sitelere yaptıkları ziyaretlere dayalı reklam sunmasına olanak tanır. Kişiselleştirilmiş reklamcılığı Google Reklam Ayarları (adssettings.google.com) üzerinden devre dışı bırakabilirsiniz. Google'ın verileri nasıl kullandığını policies.google.com/technologies/partner-sites adresinden öğrenebilirsiniz.",
      "Analitik: Sitenin nasıl kullanıldığını toplu olarak anlamak için Google Analytics kullanılabilir. Bu hizmet, IP adresinizi kısaltarak anonimleştirilmiş istatistikler üretir.",
      "Hukuki sebep ve aktarım: Veriler KVKK m.5/2-(f) meşru menfaat ve açık rızanızın bulunduğu hallerde (reklam/analitik çerezleri) m.5/1 kapsamında işlenir. Reklam ve analitik hizmet sağlayıcıları (Google LLC) yurt dışında bulunduğundan veriler KVKK m.9 çerçevesinde yurt dışına aktarılabilir.",
      "Avrupa Ekonomik Alanı, Birleşik Krallık ve İsviçre'den gelen ziyaretçilere, kişiselleştirilmiş reklam ve analitik çerezleri çalışmadan önce Google sertifikalı onay yönetim platformu (CMP) üzerinden açık rıza sorulur.",
      `Haklarınız: KVKK m.11 uyarınca verilerinizin işlenip işlenmediğini öğrenme, bilgi talep etme, düzeltilmesini veya silinmesini isteme ve itiraz etme haklarına sahipsiniz. Başvurularınızı ${mail} adresine iletebilirsiniz; en geç 30 gün içinde yanıtlanır.`,
      "Bu politika gerektiğinde güncellenir; güncel sürüm her zaman bu sayfada yayımlanır.",
    ],
  },
  "cerez-politikasi": {
    title: "Çerez Politikası",
    description: `${SITE.name} çerez politikası: zorunlu, analitik ve reklam çerezleri, Google AdSense ve çerez tercihlerinizi yönetme.`,
    body: [
      "Çerezler, ziyaret ettiğiniz sitelerin tarayıcınıza kaydettiği küçük metin dosyalarıdır. Sitemizde üç tür çerez kullanılabilir:",
      "Zorunlu çerezler: Sitenin güvenli ve doğru çalışması için gereklidir (ör. çerez tercihinizin hatırlanması). Bu çerezler kapatılamaz.",
      "Analitik çerezler: Hangi sayfaların ziyaret edildiğini toplu ve anonim olarak ölçmemize yardımcı olur (Google Analytics).",
      "Reklam çerezleri: Google AdSense ve iş ortakları, ilgi alanlarınıza uygun reklam göstermek, aynı reklamın tekrarını sınırlamak ve reklam performansını ölçmek için çerez kullanabilir. Kişiselleştirilmiş reklamları Google Reklam Ayarları (adssettings.google.com) veya aboutads.info üzerinden kapatabilirsiniz.",
      "Avrupa Ekonomik Alanı, Birleşik Krallık ve İsviçre'deki ziyaretçilerimize, reklam ve analitik çerezleri yerleştirilmeden önce Google sertifikalı onay yönetim platformu (CMP) aracılığıyla tercih sorulur; tercihinizi sayfanın altındaki gizlilik bağlantısından istediğiniz zaman değiştirebilirsiniz.",
      "Çerezleri tarayıcı ayarlarınızdan silebilir veya engelleyebilirsiniz. Zorunlu çerezleri engellemeniz durumunda sitenin bazı bölümleri beklendiği gibi çalışmayabilir.",
      `Sorularınız için: ${mail}`,
    ],
  },
  "kullanim-kosullari": {
    title: "Kullanım Koşulları",
    description: `${SITE.name} kullanım koşulları: içeriklerin niteliği, fiyat ve kota bilgilerinin doğrulanması, fikri mülkiyet ve sorumluluk.`,
    body: [
      `Bu siteyi kullanarak aşağıdaki koşulları kabul etmiş sayılırsınız. Koşulları kabul etmiyorsanız lütfen siteyi kullanmayın.`,
      "Sitedeki içerikler genel bilgilendirme amaçlıdır; hukuki, mali, vergi veya tıbbi danışmanlık yerine geçmez.",
      "Yapay zekâ araçlarına ait fiyat, ücretsiz kota ve özellik bilgileri, yayın tarihindeki resmî kaynaklardan derlenir. Sağlayıcılar bu bilgileri önceden haber vermeden değiştirebileceğinden, bir aracı kullanmadan veya satın almadan önce güncel koşulları sağlayıcının sitesinden doğrulamanız gerekir.",
      "Ürün ve şirket adları ilgili sahiplerinin ticari markalarıdır. Sitemiz bu şirketlerle bağlantılı değildir ve onlar tarafından desteklenmez.",
      "Sitedeki özgün metinler, görseller ve yazılım kodu izinsiz olarak kopyalanamaz; kaynak bağlantısı verilerek kısa alıntı yapılabilir.",
      "Hesaplama araçlarının sonuçları tahminidir; resmî işlemlerde yetkili kurumların hesaplamaları esas alınır.",
      "Sitede üçüncü taraf web sitelerine bağlantılar bulunur. Bu sitelerin içeriğinden ve gizlilik uygulamalarından sorumlu değiliz.",
      "Bu koşullar Türkiye Cumhuriyeti kanunlarına tabidir. Uyuşmazlıklarda İstanbul mahkemeleri ve icra daireleri yetkilidir.",
      `İletişim: ${mail}`,
    ],
  },
  "editoryal-ilkeler": {
    title: "Editoryal İlkeler",
    description: `${SITE.name} editoryal ilkeleri: kaynak kullanımı, güç puanı nasıl verilir, reklam-içerik ayrımı ve düzeltme politikası.`,
    body: [
      "Her içerik birincil kaynaklara (resmi dokümantasyon, fiyat sayfaları, hakemli yayınlar, mevzuat) dayanır ve kaynakları sayfanın sonunda listelenir.",
      "İstatistikler yalnızca kaynağı belirtilerek yayınlanır. Yapay zekâ destekli taslaklar mutlaka bir editör tarafından kontrol edilir ve düzeltilir.",
      "Hata bildirimlerini İletişim sayfası üzerinden alır, doğrulanan düzeltmeleri güncelleme tarihiyle birlikte yayınlarız.",
      "Model sayfalarındaki güç puanı (0–100), her modelin kendi kategorisindeki rakiplerine göre çıktı kalitesi, yetenek genişliği, hız, teknik sınırlar ve güncellik dikkate alınarak verilen editoryal bir değerlendirmedir; ücretli bir sıralama değildir.",
      "Sıralamalarda ve önerilerde hiçbir şirketten ücret, komisyon veya sponsorluk almayız. Reklamlar Google AdSense tarafından otomatik gösterilir ve içerikten ayrı olarak 'Reklam' etiketiyle işaretlenir.",
      "Model veritabanı düzenli aralıklarla gözden geçirilir; kapanan hizmetler silinmez, 'hizmet dışı' olarak işaretlenir ve alternatiflere yönlendirilir.",
    ],
  },
};
