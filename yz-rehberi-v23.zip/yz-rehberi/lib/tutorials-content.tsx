import type { ReactNode } from "react";

/**
 * Eğitim içerikleri. Gövdesi (body) tanımlı OLMAYAN eğitimler otomatik olarak
 * `noindex` alır — AdSense incelemesinde "ince/boş sayfa" sayılmamaları için.
 */
export const TUTORIAL_BODIES: Record<string, { quick: string; body: ReactNode }> = {
  "yapay-zeka-nedir": {
    quick:
      "Yapay zekâ, verilerden örüntü öğrenerek metin yazma, soru yanıtlama, görsel üretme veya tahmin yapma gibi işleri yerine getiren yazılımlardır. ChatGPT, Gemini ve Claude, milyarlarca metinle eğitilmiş büyük dil modelleridir (LLM) ve bir sonraki kelimeyi tahmin ederek yanıt üretirler.",
    body: (
      <>
        <h2>Yapay zekâ basitçe nasıl çalışır?</h2>
        <p>
          Günümüzde en çok konuşulan yapay zekâ araçları <strong>büyük dil modelleri</strong> (Large Language Model, LLM) üzerine kuruludur. Bu modeller çok
          büyük miktarda metin üzerinde eğitilir ve bir cümlenin devamında hangi kelimenin gelmesinin en olası olduğunu tahmin etmeyi öğrenir. Bu basit görünen
          yetenek, yeterince büyük ölçekte; özetleme, çeviri, kod yazma ve akıl yürütme gibi karmaşık becerilere dönüşür.
        </p>
        <h3>Bilmeniz gereken 5 temel kavram</h3>
        <ul>
          <li>
            <strong>Model:</strong> Eğitilmiş yapay zekâ sisteminin kendisi (ör. GPT, Gemini, Claude).
          </li>
          <li>
            <strong>Prompt:</strong> Modele verdiğiniz talimat veya soru.
          </li>
          <li>
            <strong>Token:</strong> Modelin metni işlediği küçük parçalar; kabaca bir kelimenin parçası.
          </li>
          <li>
            <strong>Bağlam penceresi:</strong> Modelin tek seferde &quot;hatırlayabildiği&quot; metin miktarı.
          </li>
          <li>
            <strong>Halüsinasyon:</strong> Modelin kendinden emin görünen ama yanlış bilgi üretmesi.
          </li>
        </ul>
        <h2>Yapay zekâ ne yapabilir, ne yapamaz?</h2>
        <p>
          Yapay zekâ; taslak yazmak, uzun metinleri özetlemek, fikir üretmek, kod yazmak ve verileri yorumlamak konusunda son derece hızlıdır. Ancak eğitim
          verisinin bittiği tarihten sonraki olayları (web araması açık değilse) bilemez, bazen yanlış bilgi üretebilir ve sorumluluğu size aittir. Özellikle
          sağlık, hukuk ve finans konularında çıktıları birincil kaynaklardan doğrulamalısınız.
        </p>
        <h2>İlk adım: 5 dakikada başlayın</h2>
        <ol>
          <li>ChatGPT, Gemini veya Claude&apos;dan birinde ücretsiz hesap açın.</li>
          <li>&quot;Bana yapay zekâyı 10 yaşındaki bir çocuğa anlatır gibi açıkla&quot; yazın.</li>
          <li>Yanıtı beğenmezseniz &quot;daha kısa&quot;, &quot;örnekle&quot; gibi takip talimatları verin.</li>
          <li>Günlük bir işinizi (e-posta, liste, plan) yapay zekâyla yapmayı deneyin.</li>
        </ol>
      </>
    ),
  },
  "iyi-prompt-yazma": {
    quick:
      "İyi bir prompt; rol, bağlam, görev, kısıtlar, çıktı biçimi ve örnek içerir. 'Bir e-posta yaz' yerine 'Sen deneyimli bir satış yöneticisisin; müşteriye gecikme için özür dileyen, 120 kelimeyi geçmeyen, net bir teslim tarihi içeren e-posta yaz' demek çok daha iyi sonuç verir.",
    body: (
      <>
        <h2>Kural 1: Rol verin</h2>
        <p>&quot;Sen deneyimli bir mali müşavirsin&quot; gibi bir rol, modelin üslubunu ve bilgi seviyesini doğru ayarlamasını sağlar.</p>
        <h2>Kural 2: Bağlamı anlatın</h2>
        <p>Kim için, ne amaçla, hangi durumda? Model sizin durumunuzu bilmez; ne kadar bağlam verirseniz o kadar isabetli olur.</p>
        <h2>Kural 3: Görevi tek ve net yazın</h2>
        <p>Bir prompta çok sayıda bağımsız iş yüklemek yerine görevi netleştirin veya adımlara bölün.</p>
        <h2>Kural 4: Kısıt koyun</h2>
        <p>Kelime sınırı, ton, kaçınılacak ifadeler ve hedef kitle gibi kısıtlar, çıktıyı istediğiniz çerçevede tutar.</p>
        <h2>Kural 5: Çıktı biçimini belirtin</h2>
        <p>Tablo, madde listesi, JSON veya e-posta formatı gibi açık bir biçim isteyin.</p>
        <h2>Kural 6: Örnek gösterin</h2>
        <p>İstediğiniz sonuca benzeyen kısa bir örnek, uzun açıklamalardan daha etkilidir.</p>
        <h3>Önce / sonra</h3>
        <table>
          <thead>
            <tr>
              <th>Zayıf prompt</th>
              <th>Güçlü prompt</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Instagram gönderisi yaz.</td>
              <td>
                Sen bir kafe için sosyal medya yöneticisisin. Yeni soğuk kahve menümüzü tanıtan, samimi tonda, 3 emoji ve 5 hashtag içeren, 80 kelimelik bir
                Instagram açıklaması yaz.
              </td>
            </tr>
          </tbody>
        </table>
      </>
    ),
  },

  "is-hayatinda-yapay-zeka": {
    quick:
      "İş hayatında yapay zekâ en çok e-posta ve rapor yazımı, toplantı notu çıkarma, uzun belgeleri özetleme, Excel formülü üretme, sunum taslağı hazırlama ve müşteri yanıtlarını hızlandırmada zaman kazandırır. En iyi sonuç için görevi, bağlamı ve istenen çıktı biçimini net yazın; gizli şirket verilerini kurumsal (veri eğitimde kullanılmayan) planlar dışında paylaşmayın.",
    body: (
      <>
        <h2>Neden işte yapay zekâ kullanmalısınız?</h2>
        <p>
          Yapay zekâ asistanları, tekrar eden yazı ve düzenleme işlerinde ilk taslağı saniyeler içinde çıkarır. Sizin işiniz kontrol etmek, düzeltmek ve karar
          vermek olur. Aşağıdaki 15 kullanım; ChatGPT, Claude, Gemini veya Microsoft Copilot gibi herhangi bir sohbet asistanıyla yapılabilir.
        </p>
        <h2>Yazışma ve iletişim</h2>
        <ol>
          <li>
            <strong>E-posta taslağı:</strong> Dağınık notlarınızı yapıştırın, &quot;kibar ama net, 120 kelimeyi geçmesin&quot; deyin.
          </li>
          <li>
            <strong>Zor e-postaya yanıt:</strong> Gelen e-postayı ekleyip &quot;sakin ve çözüm odaklı bir yanıt yaz, şu üç noktaya değin&quot; isteyin.
          </li>
          <li>
            <strong>Ton dönüştürme:</strong> Aynı metni resmî, samimi veya kısa versiyonlara çevirin.
          </li>
          <li>
            <strong>Çeviri ve yerelleştirme:</strong> İngilizce bir teklifi Türkçeye, terimleri koruyarak çevirin.
          </li>
        </ol>
        <h2>Toplantı ve belge işleri</h2>
        <ol start={5}>
          <li>
            <strong>Toplantı notu:</strong> Kayıt dökümünü verip &quot;kararlar, sorumlular ve tarihler&quot; tablosu isteyin.
          </li>
          <li>
            <strong>Uzun rapor özeti:</strong> PDF yükleyin ve &quot;yöneticiye yarım sayfalık özet + 3 risk&quot; isteyin.
          </li>
          <li>
            <strong>Sözleşme ön okuması:</strong> Riskli maddeleri işaretletin — ancak hukuki kararı mutlaka bir uzmana bırakın.
          </li>
          <li>
            <strong>Prosedür yazımı:</strong> Bir süreci anlatın, adım adım bir çalışma talimatına (SOP) dönüştürün.
          </li>
        </ol>
        <h2>Veri ve tablo</h2>
        <ol start={9}>
          <li>
            <strong>Excel formülü:</strong> &quot;B sütununda tarih, C sütununda tutar var; aylara göre toplam için formül yaz&quot; deyin.
          </li>
          <li>
            <strong>Veri temizleme:</strong> Karışık müşteri listesini tek biçime getirtin (ad, telefon, şehir sütunları).
          </li>
          <li>
            <strong>Grafik yorumu:</strong> Satış tablonuzu yükleyip öne çıkan üç eğilimi ve olası nedenleri sorun.
          </li>
        </ol>
        <h2>Sunum, pazarlama ve müşteri</h2>
        <ol start={12}>
          <li>
            <strong>Sunum iskeleti:</strong> 10 slaytlık bir yapı ve her slayt için ana mesaj isteyin; Gamma gibi araçlarla slayta dönüştürün.
          </li>
          <li>
            <strong>Sosyal medya takvimi:</strong> Bir aylık paylaşım planı ve metin önerileri çıkartın.
          </li>
          <li>
            <strong>Müşteri SSS:</strong> Sık gelen soruları verip tutarlı, kısa yanıt şablonları oluşturun.
          </li>
          <li>
            <strong>İş ilanı ve mülakat soruları:</strong> Pozisyonu tarif edin, ilan metni ve 10 yetkinlik sorusu alın.
          </li>
        </ol>
        <h2>Güvenli kullanım için 4 kural</h2>
        <ul>
          <li>Müşteri kişisel verilerini (TC kimlik no, sağlık bilgisi vb.) ücretsiz/kişisel hesaplara yazmayın; KVKK kapsamında sorumluluk sizdedir.</li>
          <li>Şirketiniz izin veriyorsa verilerin model eğitiminde kullanılmadığı kurumsal planları tercih edin.</li>
          <li>Rakam, tarih ve mevzuat bilgisini her zaman birincil kaynaktan doğrulayın.</li>
          <li>Yapay zekâ çıktısını olduğu gibi göndermeyin; kendi üslubunuzla son okumayı yapın.</li>
        </ul>
        <p>
          Hangi aracın işinize uygun olduğundan emin değilseniz <a href="/hangi-yapay-zeka">öneri sihirbazını</a> deneyin veya{" "}
          <a href="/kategori/sohbet-asistanlari">sohbet asistanları sıralamasına</a> göz atın.
        </p>
      </>
    ),
  },
  "gorsel-uretim-rehberi": {
    quick:
      "Sinematik bir yapay zekâ görseli için prompta konu, ortam, ışık, kamera/lens, kompozisyon, stil ve en-boy oranını yazın. Midjourney'de --ar (oran), --stylize ve --style raw gibi parametrelerle sonucu ince ayarlayın; beğendiğiniz görseli Vary ve Upscale ile geliştirin. Aynı formül GPT Image, Nano Banana, FLUX ve Ideogram'da da işe yarar.",
    body: (
      <>
        <h2>Sinematik prompt formülü</h2>
        <p>İyi bir görsel promptu bir film sahnesini tarif eder gibi yazılır. Aşağıdaki sırayı izlemek, hemen her modelde daha tutarlı sonuç verir:</p>
        <ol>
          <li>
            <strong>Konu:</strong> Kim/ne, ne yapıyor? (&quot;yaşlı bir balıkçı ağlarını topluyor&quot;)
          </li>
          <li>
            <strong>Ortam:</strong> Nerede, hangi zaman? (&quot;sisli bir Karadeniz limanı, şafak&quot;)
          </li>
          <li>
            <strong>Işık:</strong> &quot;yumuşak altın saat ışığı&quot;, &quot;neon arka ışık&quot;, &quot;volümetrik sis&quot;
          </li>
          <li>
            <strong>Kamera ve lens:</strong> &quot;35mm, sığ alan derinliği&quot;, &quot;geniş açı, alçak kamera&quot;
          </li>
          <li>
            <strong>Kompozisyon:</strong> &quot;üçte bir kuralı&quot;, &quot;yakın plan&quot;, &quot;simetrik&quot;
          </li>
          <li>
            <strong>Stil:</strong> &quot;belgesel fotoğraf&quot;, &quot;film grenli&quot;, &quot;dijital illüstrasyon&quot;
          </li>
          <li>
            <strong>Oran:</strong> YouTube kapağı için 16:9, Instagram gönderisi için 4:5, hikâye için 9:16
          </li>
        </ol>
        <h3>Örnek</h3>
        <p>
          <code>
            old fisherman pulling nets on a misty Black Sea harbor at dawn, soft golden backlight, volumetric fog, 35mm lens, shallow depth of field,
            documentary photography, film grain --ar 16:9 --style raw
          </code>
        </p>
        <h2>Midjourney parametreleri (en çok kullanılanlar)</h2>
        <table>
          <thead>
            <tr>
              <th>Parametre</th>
              <th>Ne yapar?</th>
              <th>Örnek</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>--ar</td>
              <td>En-boy oranı</td>
              <td>--ar 16:9</td>
            </tr>
            <tr>
              <td>--stylize (--s)</td>
              <td>Midjourney&apos;nin estetik yorum gücü; yüksek değer daha &quot;sanatsal&quot;</td>
              <td>--s 250</td>
            </tr>
            <tr>
              <td>--style raw</td>
              <td>Daha az yorumlu, fotoğrafa yakın sonuç</td>
              <td>--style raw</td>
            </tr>
            <tr>
              <td>--no</td>
              <td>İstenmeyen öğeyi dışlar</td>
              <td>--no text, watermark</td>
            </tr>
            <tr>
              <td>--seed</td>
              <td>Benzer sonuçları tekrar üretmek için sabit başlangıç</td>
              <td>--seed 1234</td>
            </tr>
          </tbody>
        </table>
        <p>Parametre adları ve varsayılan değerler sürümle değişebilir; güncel liste için Midjourney belgelerine bakın.</p>
        <h2>Daha iyi sonuç için 5 ipucu</h2>
        <ul>
          <li>
            Önce 4 farklı sonuç üretin, en iyisini seçip <strong>Vary (Subtle)</strong> ile küçük varyasyonlar alın.
          </li>
          <li>Görsel içinde yazı gerekiyorsa metni tırnak içinde verin; uzun metinler için Ideogram veya GPT Image daha başarılıdır.</li>
          <li>Karakter tutarlılığı için referans görsel kullanın ve aynı tarifi tekrarlayın.</li>
          <li>Gerçek kişilerin, markaların veya telifli karakterlerin taklidinden kaçının.</li>
          <li>Ticari kullanım haklarını aracın plan koşullarından kontrol edin.</li>
        </ul>
        <p>
          Ücretsiz alternatifler için <a href="/ucretsiz-yapay-zeka#gorsel-olusturma">ücretsiz görsel oluşturma araçlarına</a>, adım adım arayüz anlatımı için{" "}
          <a href="/egitimler/midjourney-nasil-kullanilir">animasyonlu Midjourney rehberine</a> bakın.
        </p>
      </>
    ),
  },
  "yapay-zeka-api-entegrasyonu": {
    quick:
      "Web sitenize yapay zekâ eklemek için API anahtarını yalnızca sunucuda (ör. Next.js Route Handler) saklayın, tarayıcıdan doğrudan sağlayıcıya istek atmayın. Kullanıcı girdisini doğrulayın, hız sınırı koyun, yanıtı akış (streaming) ile gönderin ve token kullanımını izleyerek maliyeti kontrol edin.",
    body: (
      <>
        <h2>Mimari: neden sunucu tarafı?</h2>
        <p>
          API anahtarı tarayıcıya giderse herkes görebilir ve sizin hesabınızdan harcama yapabilir. Doğru yapı:{" "}
          <strong>Tarayıcı → sizin sunucunuz (API route) → yapay zekâ sağlayıcısı</strong>. Anahtar yalnızca sunucudaki ortam değişkeninde (
          <code>.env.local</code>) durur.
        </p>
        <h2>Adım 1: Ortam değişkeni</h2>
        <p>
          Sağlayıcının konsolundan bir API anahtarı oluşturun ve <code>AI_API_KEY=...</code> şeklinde <code>.env.local</code> dosyasına ekleyin.
          <code>NEXT_PUBLIC_</code> ön ekini <strong>kullanmayın</strong>; bu ön ek değişkeni tarayıcıya gönderir.
        </p>
        <h2>Adım 2: Route Handler</h2>
        <p>
          <code>app/api/sohbet/route.ts</code> dosyasında bir <code>POST</code> fonksiyonu yazın. Gelen gövdeyi doğrulayın (ör. mesaj boş olmasın, 4.000
          karakteri aşmasın), sonra sağlayıcının resmi SDK&apos;sı veya HTTPS API&apos;si ile isteği gönderin. Sağlayıcıların istek biçimleri farklıdır; model
          adını ve parametreleri kendi belgelerinden alın.
        </p>
        <h2>Adım 3: Akış (streaming)</h2>
        <p>
          Uzun yanıtları kullanıcı beklemeden kelime kelime göstermek için sağlayıcının akış seçeneğini açın ve sunucudan <code>ReadableStream</code> döndürün.
          Bu, algılanan hızı ve etkileşim metriklerini (INP) belirgin şekilde iyileştirir.
        </p>
        <h2>Adım 4: Güvenlik kontrol listesi</h2>
        <ul>
          <li>
            <strong>Hız sınırı:</strong> IP veya oturum başına dakikada istek sınırı koyun (ör. Redis/Upstash ile).
          </li>
          <li>
            <strong>Girdi temizliği:</strong> Uzunluk sınırı, boş istek reddi; kullanıcı metnini asla sistem talimatına doğrudan birleştirmeyin.
          </li>
          <li>
            <strong>Prompt injection:</strong> Model çıktısını güvenilir kabul etmeyin; HTML olarak basmadan önce kaçış uygulayın.
          </li>
          <li>
            <strong>Gizli bilgi:</strong> Sistem talimatına parola, iç URL veya müşteri verisi koymayın.
          </li>
          <li>
            <strong>Kayıt:</strong> Hataları ve token kullanımını loglayın, kişisel verileri maskeleyin.
          </li>
        </ul>
        <h2>Adım 5: Maliyet kontrolü</h2>
        <ul>
          <li>Basit işler için küçük/hızlı modelleri seçin; zor işler için büyük modele yönlendirin.</li>
          <li>Yanıt uzunluğunu (maksimum çıkış token&apos;ı) sınırlayın.</li>
          <li>Tekrarlanan sistem talimatları için önbellek (prompt caching) özelliğini kullanın.</li>
          <li>Sağlayıcı panelinde aylık harcama limiti ve uyarı tanımlayın.</li>
        </ul>
        <p>
          Hangi modelin ne kadar tutacağını görmek için <a href="/araclar/token-hesaplama">token ve API maliyet hesaplayıcısını</a> kullanın; ücretsiz API
          katmanı sunan sağlayıcıları <a href="/kategori/kodlama">kodlama kategorisinde</a> bulabilirsiniz.
        </p>
      </>
    ),
  },
  "guvenli-kullanim": {
    quick:
      "Yapay zekâyı güvenli kullanmak için kişisel ve gizli verileri paylaşmayın, veri eğitimi ayarını kapatın, önemli bilgileri birincil kaynaktan doğrulayın, telif ve kişilik haklarına saygı gösterin ve yapay zekâ ile üretilmiş içeriği gerektiğinde açıkça belirtin. Sahte uygulamalara karşı yalnızca resmi siteleri ve mağaza yayıncılarını kullanın.",
    body: (
      <>
        <h2>1. Kişisel veriyi koruyun</h2>
        <p>
          TC kimlik numarası, banka bilgisi, parola, sağlık kaydı veya müşteri verilerini sohbet asistanlarına yazmayın. Birçok ücretsiz plan, ayarlardan
          kapatılmadıkça konuşmaları model geliştirmede kullanabilir. Ayarlar menüsünde <strong>veri kontrolleri / model eğitimi</strong> seçeneğini kontrol
          edin; hassas işler için &quot;geçici sohbet&quot; modlarını kullanın.
        </p>
        <h2>2. Doğrulamadan kullanmayın (halüsinasyon)</h2>
        <p>
          Dil modelleri olası olanı üretir; bu yüzden kendinden emin görünen yanlış bilgi verebilir. Sağlık, hukuk, finans ve tarih/rakam içeren her bilgiyi
          resmî kaynaktan teyit edin. Kaynak gösteren araçlar (ör. Perplexity, NotebookLM) doğrulamayı kolaylaştırır ama kaynağı açıp okumak yine size düşer.
        </p>
        <h2>3. Telif ve kişilik hakları</h2>
        <ul>
          <li>Başkasının sesini, yüzünü veya eserini izinsiz kopyalayan içerik üretmeyin.</li>
          <li>Ticari kullanımda aracın lisans koşullarını okuyun; bazı ücretsiz planlar ticari hak vermez.</li>
          <li>Ünlü karakterlerin ve markaların taklitlerinden kaçının.</li>
        </ul>
        <h2>4. Şeffaflık</h2>
        <p>
          Okul ödevi, akademik çalışma veya müşteriye teslim edilen işlerde yapay zekâ kullanımını kurumun kurallarına göre belirtin. Pek çok platform yapay
          zekâ ile üretilmiş görsellere görünmez filigran ekler ve bazı platformlar bunun etiketlenmesini zorunlu tutar.
        </p>
        <h2>5. Dolandırıcılık ve sahte uygulamalar</h2>
        <ul>
          <li>Uygulamaları yalnızca resmî sitelerden veya mağazada doğru yayıncıdan indirin.</li>
          <li>&quot;Ücretsiz premium&quot; vaat eden eklentilere ve hesap bilgisi isteyen sitelere güvenmeyin.</li>
          <li>Tanıdık birinin sesiyle gelen acil para taleplerinde (ses klonlama dolandırıcılığı) mutlaka başka bir kanaldan teyit isteyin.</li>
        </ul>
        <h2>6. Çocuklar ve gençler</h2>
        <p>
          Çoğu yapay zekâ hizmeti için yaş sınırı vardır (genellikle 13 veya 18). Ebeveyn kontrolleri ve aile hesaplarını kullanın; çocuklarla yapay zekânın
          hata yapabileceğini ve özel bilgilerin paylaşılmaması gerektiğini konuşun.
        </p>
        <h2>Hızlı kontrol listesi</h2>
        <ol>
          <li>Paylaştığım bilgi kişisel veya gizli mi?</li>
          <li>Veri eğitimi ayarı kapalı mı?</li>
          <li>Önemli bilgiyi kaynağından doğruladım mı?</li>
          <li>Ürettiğim içerik birinin hakkını ihlal ediyor mu?</li>
          <li>Kullandığım uygulama resmî mi?</li>
        </ol>
        <p>
          Kavramların açıklamaları için <a href="/sozluk#halusinasyon">halüsinasyon</a>, <a href="/sozluk#deepfake">deepfake</a> ve{" "}
          <a href="/sozluk#yerel-llm">yerel LLM</a> maddelerine bakabilirsiniz.
        </p>
      </>
    ),
  },
};
