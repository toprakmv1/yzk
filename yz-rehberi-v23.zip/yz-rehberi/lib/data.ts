/**
 * İçerik veri katmanı (prompt seçkisi ve temel eğitimler).
 * Yapay zekâ model verileri: lib/models.ts ← data/models.json
 * Gerçek projede bu dosya bir CMS'e (Sanity, Payload, MDX klasörü vb.) taşınabilir.
 */

export type PromptCategory = "Görsel" | "Video" | "Ses" | "Müzik" | "Kod" | "İş" | "Eğitim" | "YouTube" | "Araştırma" | "Günlük" | "3D";

export type MegaPrompt = {
  id: string;
  title: string;
  category: PromptCategory;
  tool: string;
  description: string;
  prompt: string;
};

export const MEGA_PROMPTS: MegaPrompt[] = [
  {
    id: "youtube-banner",
    title: "YouTube Kanal Banner'ı",
    category: "YouTube",
    tool: "Midjourney / ChatGPT",
    description: "Kanal kimliğinize uygun 2560×1440 güvenli alan uyumlu banner görseli.",
    prompt:
      'Create a YouTube channel banner for a [KANAL KONUSU] channel named "[KANAL ADI]". Ultra-wide cinematic composition, 16:9, key visual centered inside the middle 1546×423 safe area, dark deep-space background with electric blue and neon purple rim lighting, volumetric fog, subtle glassmorphism panel behind the title, bold modern sans-serif typography, high contrast, 8k, crisp details --ar 16:9 --style raw',
  },
  {
    id: "photo-upscale",
    title: "Fotoğraf Kalitesi Artırma",
    category: "Görsel",
    tool: "ChatGPT / Gemini (görsel düzenleme)",
    description: "Bulanık veya düşük çözünürlüklü fotoğrafı doğal görünümü koruyarak iyileştirme.",
    prompt:
      "Bu fotoğrafı yüksek çözünürlüklü, net ve doğal görünecek şekilde iyileştir. Kurallar: 1) Yüz hatlarını, kimliği ve orantıları kesinlikle değiştirme. 2) Gürültüyü azalt ama cilt dokusunu plastikleştirme. 3) Kenar keskinliğini artır, hale (halo) oluşturma. 4) Beyaz dengesini nötrle, renkleri %10'dan fazla doygunlaştırma. 5) Orijinal kadrajı koru. Çıktıyı fotoğrafik gerçekçilikte ver.",
  },
  {
    id: "uiux-code",
    title: "UI/UX Koduna Dönüştürme",
    category: "Kod",
    tool: "Claude / ChatGPT",
    description: "Bir ekran görüntüsünü veya tarifi üretim kalitesinde React + Tailwind koduna çevirir.",
    prompt:
      "Sen kıdemli bir frontend mühendisisin. Ekteki tasarımı (veya aşağıdaki tarifi) React 19 + TypeScript + Tailwind CSS ile üretim kalitesinde koda dönüştür.\n\nGereksinimler:\n- Mobil öncelikli, 360px'den 1440px'e kadar duyarlı\n- Erişilebilirlik: anlamsal HTML, aria etiketleri, klavye ile gezinme, WCAG AA kontrast\n- Bileşenleri tek sorumluluk ilkesine göre böl\n- Sabit metinleri props olarak dışarı al\n- Koyu tema, glassmorphism (bg-white/5, backdrop-blur-xl, border-white/10)\n\nÇıktı: Önce bileşen ağacını madde madde, sonra tam kodu ver. Varsayım yaptığın yerleri yorum satırıyla belirt.\n\nTasarım tarifi: [BURAYA YAZIN]",
  },
  {
    id: "seo-article",
    title: "SEO + GEO Uyumlu Makale Taslağı",
    category: "İş",
    tool: "Claude / ChatGPT / Gemini",
    description: "Arama motorları ve yapay zekâ yanıt motorları için yapılandırılmış makale iskeleti.",
    prompt:
      "\"[ANAHTAR KELİME]\" konusu için Türkçe bir makale taslağı hazırla.\n1. İlk paragraf: soruyu 40-60 kelimede doğrudan yanıtlayan 'Hızlı Cevap'.\n2. H2/H3 hiyerarşisiyle en az 6 bölüm.\n3. Her bölümde doğrulanabilir en az bir veri noktası için [KAYNAK GEREKLİ] etiketi bırak — rakam uydurma.\n4. Bir uzman görüşü için yer tutucu ekle.\n5. Sonda 5 soruluk SSS.\n6. Meta başlık (≤60 karakter) ve açıklama (≤155 karakter) öner.",
  },
  {
    id: "lesson-plan",
    title: "Kişisel Öğrenme Planı",
    category: "Eğitim",
    tool: "Tüm sohbet asistanları",
    description: "Herhangi bir beceriyi haftalık hedeflerle öğrenmek için kişisel müfredat.",
    prompt:
      "Bana [BECERİ] öğrenmek için 4 haftalık bir plan hazırla. Seviyem: [başlangıç/orta]. Günde [X] dakika ayırabiliyorum.\nHer hafta için: hedef, günlük görevler, ücretsiz kaynak önerisi ve hafta sonu mini proje. Sonunda kendimi test edebileceğim 10 soruluk bir quiz ekle. Beni her gün sorumlu tutacak kısa bir kontrol listesi de ver.",
  },
  {
    id: "email-pro",
    title: "Profesyonel E-posta Yeniden Yazımı",
    category: "İş",
    tool: "Tüm sohbet asistanları",
    description: "Dağınık notları net, kibar ve eyleme dönük bir iş e-postasına çevirir.",
    prompt:
      "Aşağıdaki notlarımı profesyonel bir iş e-postasına çevir. Ton: [resmi/samimi-profesyonel]. Alıcı: [KİŞİ/ROL]. Amaç: [AMAÇ].\nKurallar: konu satırı öner, 150 kelimeyi geçme, net bir eylem çağrısı ve tarih içersin, gereksiz özür dileme ifadeleri kullanma.\n\nNotlarım: [BURAYA]",
  },
];

export type Tutorial = {
  slug: string;
  title: string;
  level: "Başlangıç" | "Orta" | "İleri";
  minutes: number;
  summary: string;
};

export const TUTORIALS: Tutorial[] = [
  {
    slug: "yapay-zeka-nedir",
    title: "Yapay Zekâ Nedir? 10 Dakikada Temel Kavramlar",
    level: "Başlangıç",
    minutes: 10,
    summary: "Model, prompt, token, halüsinasyon gibi kavramları sade bir dille öğrenin.",
  },
  {
    slug: "iyi-prompt-yazma",
    title: "İyi Prompt Yazmanın 6 Kuralı",
    level: "Başlangıç",
    minutes: 12,
    summary: "Rol, bağlam, görev, format, örnek ve kısıt — her seferinde daha iyi yanıt alın.",
  },
  {
    slug: "is-hayatinda-yapay-zeka",
    title: "İş Hayatında Yapay Zekâ: 15 Gerçek Kullanım",
    level: "Orta",
    minutes: 18,
    summary: "E-posta, rapor, toplantı notu, Excel formülü ve sunum hazırlığında zaman kazanın.",
  },
  {
    slug: "gorsel-uretim-rehberi",
    title: "Midjourney ile Sinematik Görsel Üretimi",
    level: "Orta",
    minutes: 20,
    summary: "Işık, lens, kompozisyon ve parametrelerle profesyonel görseller üretin.",
  },
  {
    slug: "yapay-zeka-api-entegrasyonu",
    title: "Web Sitenize Yapay Zekâ API'si Entegre Etme",
    level: "İleri",
    minutes: 30,
    summary: "Next.js ile güvenli sunucu tarafı API çağrısı, akış (streaming) ve maliyet kontrolü.",
  },
  {
    slug: "guvenli-kullanim",
    title: "Yapay Zekâyı Güvenli ve Etik Kullanmak",
    level: "Başlangıç",
    minutes: 9,
    summary: "Kişisel veri, telif, doğrulama ve halüsinasyon risklerine karşı pratik kurallar.",
  },
];
