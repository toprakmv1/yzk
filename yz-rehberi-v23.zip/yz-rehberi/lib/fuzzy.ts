/**
 * Türkçe duyarlı, bağımlılıksız bulanık (fuzzy) arama.
 * - Türkçe karakter normalizasyonu (ı/i, ş/s, ğ/g, ü/u, ö/o, ç/c, â/a)
 * - Kelime başı ve önek eşleşmesine yüksek puan
 * - Yazım hatası toleransı (Damerau-Levenshtein ≤ 1–2)
 * - Alt dizi (subsequence) eşleşmesi: "cgpt" → "chatgpt"
 */

export type SearchDoc = {
  /** Başlık */
  t: string;
  /** URL */
  u: string;
  /** Tür etiketi */
  k: string;
  /** Kısa açıklama */
  d: string;
  /** Ek anahtar kelimeler */
  x?: string;
  /** Sıralama ağırlığı (0–1) */
  w?: number;
};

const MAP: Record<string, string> = { ı: "i", İ: "i", ş: "s", Ş: "s", ğ: "g", Ğ: "g", ü: "u", Ü: "u", ö: "o", Ö: "o", ç: "c", Ç: "c", â: "a", î: "i", û: "u" };

export function normalize(s: string) {
  return s
    .replace(/[ıİşŞğĞüÜöÖçÇâîû]/g, (c) => MAP[c] ?? c)
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9.+#\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function editDistance(a: string, b: string, max: number) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  const prev = new Array(b.length + 1);
  const cur = new Array(b.length + 1);
  const prev2 = new Array(b.length + 1).fill(0);
  for (let j = 0; j <= b.length; j++) prev[j] = j;
  for (let i = 1; i <= a.length; i++) {
    cur[0] = i;
    let rowMin = cur[0];
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) cur[j] = Math.min(cur[j], prev2[j - 2] + 1);
      rowMin = Math.min(rowMin, cur[j]);
    }
    if (rowMin > max) return max + 1;
    for (let j = 0; j <= b.length; j++) {
      prev2[j] = prev[j];
      prev[j] = cur[j];
    }
  }
  return prev[b.length];
}

function isSubsequence(q: string, s: string) {
  let i = 0;
  for (let j = 0; j < s.length && i < q.length; j++) if (q[i] === s[j]) i++;
  return i === q.length;
}

export type Prepared = SearchDoc & { _t: string; _tw: string[]; _x: string; _xw: string[]; _d: string; _dw: string[] };

const words = (s: string) => Array.from(new Set(s.split(" ").filter((w) => w.length > 1)));

export function prepare(docs: SearchDoc[]): Prepared[] {
  return docs.map((d) => {
    const _t = normalize(d.t);
    const _x = normalize(d.x ?? "");
    const _d = normalize(`${d.d} ${d.k}`);
    return { ...d, _t, _tw: words(_t), _x, _xw: words(_x), _d, _dw: words(_d) };
  });
}

function fuzzyHit(tok: string, list: string[]) {
  if (tok.length < 4) return -1;
  const max = tok.length >= 7 ? 2 : 1;
  let best = max + 1;
  for (const w of list) {
    if (w.length < 3) continue;
    const d = Math.min(editDistance(tok, w, max), editDistance(tok, w.slice(0, tok.length), max));
    if (d < best) best = d;
    if (best === 0) break;
  }
  return best <= max ? best : -1;
}

/** Alan ağırlıklı puan: başlık > anahtar kelimeler > açıklama */
function scoreToken(tok: string, doc: Prepared): number {
  if (doc._t === tok) return 14;
  if (doc._t.startsWith(tok)) return 10;
  if (doc._tw.some((w) => w.startsWith(tok))) return 8;
  if (doc._t.includes(tok)) return 6;
  if (doc._xw.some((w) => w.startsWith(tok))) return 4;
  if (doc._x.includes(tok)) return 3;
  if (doc._dw.some((w) => w.startsWith(tok))) return 2;
  let f = fuzzyHit(tok, doc._tw);
  if (f >= 0) return 6 - f * 1.5;
  f = fuzzyHit(tok, doc._xw);
  if (f >= 0) return 3 - f;
  if (doc._d.includes(tok)) return 1.2;
  f = fuzzyHit(tok, doc._dw);
  if (f >= 0) return 1.2 - f * 0.4;
  if (tok.length >= 3 && isSubsequence(tok, doc._t.replace(/\s/g, ""))) return 1.5;
  return 0;
}

export function search(index: Prepared[], query: string, limit = 20) {
  const q = normalize(query);
  if (!q) return [];
  const tokens = q.split(" ").filter(Boolean);
  const out: { doc: Prepared; score: number }[] = [];
  for (const doc of index) {
    let total = 0;
    let matched = 0;
    for (const tok of tokens) {
      const s = scoreToken(tok, doc);
      if (s > 0) matched++;
      total += s;
    }
    // Çok kelimeli sorgularda kelimelerin çoğu eşleşmeli
    if (matched === 0 || matched < Math.ceil(tokens.length * 0.6)) continue;
    if (doc._t.includes(q)) total += 6;
    // Tüm kelimeler eşleştiyse bonus; eksik kelime başına ceza
    total += matched === tokens.length ? 3 : -2 * (tokens.length - matched);
    total += (doc.w ?? 0.5) * 2;
    out.push({ doc, score: total });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}
