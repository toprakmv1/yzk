import type { Metadata } from "next";
import { SITE, absoluteUrl } from "@/lib/site";

/**
 * Sayfa metadata üreticisi — her sayfada tutarlı canonical, Open Graph ve Twitter etiketleri.
 *
 * Neden gerekli? Next.js'te alt sayfa `openGraph` veya `twitter` nesnesini tanımlamazsa kök layout'taki
 * değerler AYNEN miras alınır (og:url = ana sayfa, twitter:title = site adı). Bu, sosyal paylaşımlarda ve
 * bazı arama motorlarında tüm sayfaların ana sayfa gibi görünmesine yol açar. Bu yardımcı her sayfaya
 * kendi URL'sini, başlığını ve açıklamasını verir.
 */
export interface PageMetaInput {
  title: string;
  description: string;
  /** Kök göreli yol: "/ai-araclari/chatgpt" */
  path: string;
  type?: "website" | "article";
  keywords?: string[];
  /** Arama sonuçlarında gösterilmemesi gereken sayfalar (ör. site içi arama) */
  noindex?: boolean;
  /** Tam başlık şablonu (| YZ Rehberi) eklenmesin */
  absoluteTitle?: boolean;
  publishedTime?: string;
  modifiedTime?: string;
  section?: string;
}

/** Arama sonucu snippet'i için kelime ortasında kesmeyen kısaltma (Google ≈155–160 karakter gösterir). */
export function clampText(text: string, max = 158) {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  const cut = clean.slice(0, max - 1);
  const lastSpace = cut.lastIndexOf(" ");
  return `${(lastSpace > max * 0.6 ? cut.slice(0, lastSpace) : cut).replace(/[\s,;:·—–-]+$/, "")}…`;
}

export function pageMeta(p: PageMetaInput): Metadata {
  const description = clampText(p.description);
  const url = absoluteUrl(p.path);
  const fullTitle = p.absoluteTitle ? p.title : `${p.title} | ${SITE.name}`;
  return {
    title: p.absoluteTitle ? { absolute: p.title } : p.title,
    description,
    keywords: p.keywords,
    alternates: { canonical: p.path },
    openGraph: {
      type: p.type ?? "website",
      locale: SITE.locale,
      siteName: SITE.name,
      url,
      title: fullTitle,
      description,
      ...(p.type === "article"
        ? {
            publishedTime: p.publishedTime,
            modifiedTime: p.modifiedTime ?? SITE.lastReviewed,
            section: p.section,
            authors: [absoluteUrl(SITE.author.url)],
          }
        : {}),
    },
    twitter: {
      card: "summary_large_image",
      site: SITE.twitter,
      title: fullTitle,
      description,
    },
    robots: p.noindex ? { index: false, follow: true, googleBot: { index: false, follow: true } } : undefined,
  };
}
