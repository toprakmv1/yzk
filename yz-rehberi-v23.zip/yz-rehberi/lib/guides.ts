/**
 * Adım adım (scrollytelling) kullanım rehberleri — data/guides.json
 */
import raw from "@/data/guides.json";

export type MockKind = "browser" | "chat" | "settings" | "upload" | "voice" | "image" | "flow" | "video" | "result";

export type Mock = {
  kind: MockKind;
  label: string;
  items?: string[];
  user?: string;
  ai?: string;
};

export type GuideStep = { title: string; body: string; tip: string; mock?: Mock };

export type Guide = {
  slug: string;
  toolSlug: string;
  toolName: string;
  title: string;
  metaDescription: string;
  quick: string;
  level: "Başlangıç" | "Orta" | "İleri";
  minutes: number;
  intro: string[];
  steps: GuideStep[];
  useCases: { title: string; prompt: string }[];
  mistakes: string[];
  freeVsPaid: string;
  faq: { q: string; a: string }[];
  sources: string[];
};

export const GUIDES: Guide[] = raw as Guide[];

export const getGuide = (slug: string) => GUIDES.find((g) => g.slug === slug);
export const guideForTool = (toolSlug: string) => GUIDES.find((g) => g.toolSlug === toolSlug);
