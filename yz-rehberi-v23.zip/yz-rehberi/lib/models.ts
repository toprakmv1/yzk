/**
 * Yapay zekâ model veritabanı (sunucu tarafı). Kaynak: data/models.json
 * İstemci bileşenleri bunun yerine "@/lib/model-meta" kullanmalıdır.
 */
import raw from "@/data/models.json";
import { CATEGORIES, type CategoryKey, type Model } from "./model-meta";

export * from "./model-meta";

export const MODELS: Model[] = (raw as Model[]).slice().sort((a, b) => b.power - a.power || a.name.localeCompare(b.name, "tr"));

/* ------------------------------------------------------------------ */
/* Sorgular                                                           */
/* ------------------------------------------------------------------ */
export const isActive = (m: Model) => m.status !== "kapandi";
export const hasFreeAccess = (m: Model) => isActive(m) && m.pricing !== "ucretli";

export function getModel(slug: string) {
  return MODELS.find((m) => m.slug === slug);
}

/**
 * Kategori içi sıralama puanı: birincil kategorisi bu olan (uzman) modeller öne çıkar.
 * Ör. "video" sıralamasında Kling/Veo, videoyu yan özellik olarak sunan genel asistanlardan önce gelir.
 */
export const categoryScore = (m: Model, key: CategoryKey) => m.power - (m.primaryCategory === key ? 0 : 12);

const byCategoryScore = (key: CategoryKey) => (a: Model, b: Model) => categoryScore(b, key) - categoryScore(a, key) || b.power - a.power;

export function modelsInCategory(key: CategoryKey, opts: { freeOnly?: boolean } = {}) {
  return MODELS.filter((m) => m.categories.includes(key) && isActive(m) && (!opts.freeOnly || hasFreeAccess(m))).sort(byCategoryScore(key));
}

export function topModels(n = 10, key?: CategoryKey) {
  return key ? modelsInCategory(key).slice(0, n) : MODELS.filter(isActive).slice(0, n);
}

export function newestModels(n = 12) {
  return MODELS.filter((m) => isActive(m) && m.isNew)
    .slice()
    .sort((a, b) => b.released.localeCompare(a.released) || b.power - a.power)
    .slice(0, n);
}

export function freeModels(key?: CategoryKey) {
  return key ? modelsInCategory(key, { freeOnly: true }) : MODELS.filter(hasFreeAccess);
}

/** Aynı birincil kategoriden en yakın alternatifler */
export function alternativesFor(m: Model, n = 6) {
  return MODELS.filter((x) => x.slug !== m.slug && isActive(x) && x.categories.includes(m.primaryCategory))
    .sort((a, b) => Math.abs(a.power - m.power) - Math.abs(b.power - m.power) || b.power - a.power)
    .slice(0, n)
    .sort((a, b) => b.power - a.power);
}

/** Bir kategorideki sıralama (1 tabanlı) */
export function rankInCategory(m: Model, key: CategoryKey = m.primaryCategory) {
  const list = modelsInCategory(key);
  const i = list.findIndex((x) => x.slug === m.slug);
  return i === -1 ? null : { rank: i + 1, of: list.length };
}

/** Veritabanı istatistikleri (trend paneli ve ana sayfa sayaçları) */
export function stats() {
  const active = MODELS.filter(isActive);
  return {
    total: active.length,
    free: active.filter(hasFreeAccess).length,
    open: active.filter((m) => m.openWeights).length,
    isNew: active.filter((m) => m.isNew).length,
    categories: CATEGORIES.length,
    turkishGood: active.filter((m) => m.turkish === "iyi").length,
  };
}

