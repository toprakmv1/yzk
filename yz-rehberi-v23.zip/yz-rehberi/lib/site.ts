/**
 * Site genelinde tek doğruluk kaynağı (Single Source of Truth).
 * Yayına almadan önce SITE.url ve ADSENSE.client değerlerini değiştirin.
 */
export const SITE = {
  name: "YZ Rehberi",
  legalName: "YZ Rehberi Dijital Yayın",
  url: (process.env.NEXT_PUBLIC_SITE_URL || "https://www.yzrehberi.com").replace(/\/+$/, ""),
  locale: "tr_TR",
  description:
    "150 yapay zeka aracını karşılaştırın: ücretsiz olanlar, en güçlüler ve yeni çıkanlar. ChatGPT, Gemini, Claude ve fazlası için Türkçe rehber, kota ve fiyatlar.",
  twitter: "@yzrehberi",
  author: {
    name: "YZ Rehberi Editör Ekibi",
    url: "/hakkimizda",
  },
  /** İletişim adresi — AdSense ve KVKK için sitede görünür bir iletişim kanalı zorunludur. .env: NEXT_PUBLIC_CONTACT_EMAIL */
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "iletisim@yzrehberi.com",
  /** Sosyal profiller (Organization.sameAs → E-E-A-T sinyali). Virgülle ayrılmış URL listesi: NEXT_PUBLIC_SOCIAL_LINKS */
  socials: (process.env.NEXT_PUBLIC_SOCIAL_LINKS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter((s) => /^https:\/\//.test(s)),
  lastReviewed: "2026-10-10",
} as const;

/** Arama motoru doğrulama kodları ve analitik (boşsa etiket basılmaz) */
export const VERIFY = {
  google: process.env.NEXT_PUBLIC_GOOGLE_VERIFICATION || undefined,
  bing: process.env.NEXT_PUBLIC_BING_VERIFICATION || undefined,
  yandex: process.env.NEXT_PUBLIC_YANDEX_VERIFICATION || undefined,
  /** Google Analytics 4 ölçüm kimliği: G-XXXXXXX */
  ga4: /^G-[A-Z0-9]+$/.test(process.env.NEXT_PUBLIC_GA_ID ?? "") ? (process.env.NEXT_PUBLIC_GA_ID as string) : "",
} as const;

/** AdSense yayıncı kimliği. "pub-…" veya "ca-pub-…" biçimlerinin ikisi de kabul edilir. */
const DEFAULT_ADSENSE_PUBLISHER = "ca-pub-6754267783110284";
function normalizeClient(v?: string) {
  const id = (v ?? "").trim().replace(/^(ca-)?pub-/, "");
  return /^\d{10,}$/.test(id) ? `ca-pub-${id}` : "";
}

export const ADSENSE = {
  /** ca-pub-XXXXXXXXXXXXXXXX — .env: NEXT_PUBLIC_ADSENSE_CLIENT */
  client: normalizeClient(process.env.NEXT_PUBLIC_ADSENSE_CLIENT) || DEFAULT_ADSENSE_PUBLISHER,
  /**
   * Reklam slot kimlikleri AdSense panelinden alınır.
   * `fallback`: Tek bir "Görüntülü reklam (duyarlı)" birimi oluşturup kimliğini NEXT_PUBLIC_AD_SLOT_DEFAULT olarak girerseniz,
   * kendi slotu tanımlanmamış TÜM reklam alanları bu birimle çalışır. Böylece sitedeki tüm yerleşimler tek kimlikle aktif olur.
   */
  fallback: process.env.NEXT_PUBLIC_AD_SLOT_DEFAULT ?? "",
  slots: {
    leaderboard: process.env.NEXT_PUBLIC_AD_SLOT_TOP ?? "",
    inArticle: process.env.NEXT_PUBLIC_AD_SLOT_INARTICLE ?? "",
    sidebar: process.env.NEXT_PUBLIC_AD_SLOT_SIDEBAR ?? "",
    mobileAnchor: process.env.NEXT_PUBLIC_AD_SLOT_MOBILE ?? "",
    multiplex: process.env.NEXT_PUBLIC_AD_SLOT_MULTIPLEX ?? "",
    inFeed: process.env.NEXT_PUBLIC_AD_SLOT_INFEED ?? "",
    rectangle: process.env.NEXT_PUBLIC_AD_SLOT_RECTANGLE ?? "",
  },
} as const;

export const NAV = [
  { href: "/ai-araclari", label: "Modeller", mega: true },
  { href: "/ucretsiz-yapay-zeka", label: "Ücretsiz" },
  { href: "/en-guclu-yapay-zeka", label: "En Güçlü" },
  { href: "/yeni-yapay-zeka-modelleri", label: "Yeni" },
  { href: "/egitimler", label: "Rehberler" },
  { href: "/karsilastir", label: "Karşılaştır" },
  { href: "/mega-promptlar", label: "Promptlar" },
] as const;

export const TOOL_LINKS = [
  { href: "/hangi-yapay-zeka", label: "Hangi Yapay Zekâ? (Öneri sihirbazı)" },
  { href: "/karsilastir", label: "Model Karşılaştırma" },
  { href: "/araclar/token-hesaplama", label: "Token ve API Maliyet Hesaplayıcı" },
  { href: "/araclar/kdv-hesaplama", label: "KDV Hesaplama" },
  { href: "/araclar/istifa-dilekcesi-olusturucu", label: "İstifa Dilekçesi Oluşturucu" },
] as const;

export const absoluteUrl = (path = "/") => new URL(path, SITE.url).toString();
