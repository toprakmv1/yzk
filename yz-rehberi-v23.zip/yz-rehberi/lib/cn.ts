/** Koşullu className birleştirici (clsx benzeri, bağımlılıksız). */
export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}
