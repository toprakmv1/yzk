/**
 * Statik karşılaştırma sayfaları için popüler model çiftleri ("chatgpt-vs-claude").
 *
 * 1) Her kategorinin ilk 5 aktif modelinden ikili kombinasyonlar (kategori başına 10 çift)
 * 2) Türkiye'de en çok aranan "X vs Y" kalıpları (elle seçilmiş, kategoriler arası olabilir)
 * Tekrarlar ve ters sıralı kopyalar elenir. Her çift uzun kuyruklu bir arama sorgusunu hedefler
 * ("chatgpt mi gemini mi", "cursor vs copilot" ...).
 */
import { CATEGORIES, getModel, isActive, modelsInCategory } from "@/lib/models";

export type Pair = { slug: string; a: string; b: string };

const PER_CATEGORY = 5;

/** Yüksek arama hacimli elle seçilmiş çiftler (önce yazılan model URL'de önce gelir) */
const CURATED: [string, string][] = [
  ["chatgpt", "gemini"],
  ["chatgpt", "claude"],
  ["claude", "gemini"],
  ["chatgpt", "deepseek"],
  ["gemini", "deepseek"],
  ["chatgpt", "grok"],
  ["chatgpt", "perplexity"],
  ["chatgpt", "microsoft-copilot"],
  ["gemini", "microsoft-copilot"],
  ["claude", "deepseek"],
  ["chatgpt", "meta-ai"],
  ["chatgpt", "qwen-chat"],
  ["perplexity", "gemini"],
  ["cursor", "github-copilot"],
  ["claude-code", "cursor"],
  ["claude-code", "openai-codex"],
  ["cursor", "windsurf"],
  ["github-copilot", "windsurf"],
  ["lovable", "bolt-new"],
  ["v0", "lovable"],
  ["midjourney", "chatgpt-gpt-image"],
  ["midjourney", "flux"],
  ["midjourney", "leonardo-ai"],
  ["midjourney", "ideogram"],
  ["nano-banana", "chatgpt-gpt-image"],
  ["stable-diffusion", "midjourney"],
  ["google-veo", "openai-sora"],
  ["google-veo", "kling"],
  ["kling", "runway"],
  ["kling", "hailuo"],
  ["runway", "pika"],
  ["suno", "udio"],
  ["elevenlabs", "murf"],
  ["heygen", "synthesia"],
  ["gamma", "beautiful-ai"],
  ["notebooklm", "perplexity"],
  ["ollama", "lm-studio"],
  ["zapier", "make"],
  ["n8n", "zapier"],
  ["whisper", "otter-ai"],
];

function build(): Pair[] {
  const seen = new Set<string>();
  const out: Pair[] = [];
  const add = (a: string, b: string) => {
    if (a === b) return;
    const ma = getModel(a);
    const mb = getModel(b);
    if (!ma || !mb || !isActive(ma) || !isActive(mb)) return;
    const key = [a, b].sort().join("|");
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ slug: `${a}-vs-${b}`, a, b });
  };
  for (const [a, b] of CURATED) add(a, b);
  for (const c of CATEGORIES) {
    const top = modelsInCategory(c.key).slice(0, PER_CATEGORY);
    for (let i = 0; i < top.length; i++) {
      for (let j = i + 1; j < top.length; j++) add(top[i].slug, top[j].slug);
    }
  }
  return out;
}

export const PAIRS = build();
export const getPair = (slug: string) => PAIRS.find((p) => p.slug === slug);

/** Bir modelin yer aldığı karşılaştırma sayfaları (iç linkleme için) */
export const pairsFor = (slug: string, n = 6) => PAIRS.filter((p) => p.a === slug || p.b === slug).slice(0, n);
