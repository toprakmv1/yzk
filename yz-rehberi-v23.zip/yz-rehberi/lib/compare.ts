import type { Model } from "@/lib/model-meta";

export type CompareModel = Pick<
  Model,
  | "slug"
  | "name"
  | "vendor"
  | "pricing"
  | "freeTier"
  | "freeQuota"
  | "paidFrom"
  | "apiFree"
  | "latestVersion"
  | "released"
  | "turkish"
  | "platforms"
  | "openWeights"
  | "power"
  | "bestFor"
  | "pros"
  | "cons"
  | "categories"
  | "primaryCategory"
  | "skills"
  | "status"
>;

export function toCompare(m: Model): CompareModel {
  const {
    slug,
    name,
    vendor,
    pricing,
    freeTier,
    freeQuota,
    paidFrom,
    apiFree,
    latestVersion,
    released,
    turkish,
    platforms,
    openWeights,
    power,
    bestFor,
    pros,
    cons,
    categories,
    primaryCategory,
    skills,
    status,
  } = m;
  return {
    slug,
    name,
    vendor,
    pricing,
    freeTier,
    freeQuota,
    paidFrom,
    apiFree,
    latestVersion,
    released,
    turkish,
    platforms,
    openWeights,
    power,
    bestFor,
    pros,
    cons,
    categories,
    primaryCategory,
    skills,
    status,
  };
}
