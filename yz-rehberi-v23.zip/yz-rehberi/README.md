# YZ Rehberi 2.1 — Yapay Zekâ Modelleri, Rehberler ve Araçlar (Next.js 15)

Türkçe yapay zekâ bilgi platformu: **140+ model** (ücretsiz / en güçlü / yeni), kategori sıralamaları, **kaydırmaya bağlı 3D sinematik giriş**,
**animasyonlu (scrollytelling) kullanım rehberleri**, bulanık site araması, karşılaştırma ve öneri araçları. SEO, GEO (yapay zekâ yanıt motorları) ve
AdSense için optimize edilmiştir.

## Kurulum

```bash
npm install
cp .env.example .env.local   # site URL ve AdSense kimliklerini doldurun
npm run dev                  # http://localhost:3000
npm run build && npm start   # üretim
```

Node.js 18.18+ (önerilen 20 veya 22).

## 2.0 ile gelenler

| Alan | Ne eklendi |
| --- | --- |
| **Tasarım** | Turkuaz · açık mavi · yeşil · kırmızı · beyaz neon palet, özel 3D neon ikon seti (`components/icons/NeonIcon.tsx`), ferah koyu lacivert zemin |
| **3D giriş** | `components/hero/CinematicHero.tsx` + `components/three/NeuralScene.ts` — three.js + GSAP ScrollTrigger. Fare tekerleği / ok tuşları / dokunmatik kaydırma ile kamera Z ekseninde YZ çekirdeğinden sinir ağına ve "küresel beyne" uçar. 4 aşamalı metin katmanı. |
| **Model veritabanı** | `data/models.json` (150 kayıt, her biri kaynak bağlantılı) → `lib/models.ts`. Ücretsiz kota, ücretli plan, API/token fiyatı, sürüm, Türkçe desteği, platformlar, skill/entegrasyonlar, örnek prompt, artı/eksi |
| **Yeni sayfalar** | `/ai-araclari` (filtrelenebilir dizin) · `/ai-araclari/[slug]` (150 sayfa) · `/kategori/[slug]` (12) · `/ucretsiz-yapay-zeka` · `/en-guclu-yapay-zeka` · `/yeni-yapay-zeka-modelleri` · `/karsilastir` + `/karsilastir/[a-vs-b]` · `/hangi-yapay-zeka` · `/araclar/token-hesaplama` · `/sozluk` · `/ara` |
| **Rehberler** | En çok kullanılan 10 araç için scrollytelling rehber (`data/guides.json`, `components/guides/*`): sağda yapışkan, kaydırdıkça canlanan ekran maketi + "Video gibi izle" otomatik oynatma. 4 yeni temel eğitim yazıldı. |
| **Arama** | `Ctrl/⌘ + K` veya `/` ile açılan bulanık arama (Türkçe karakter + yazım hatası toleranslı, bağımlılıksız — `lib/fuzzy.ts`). Dizin build'de `/search-index.json` olarak üretilir. |
| **Prompt kütüphanesi** | 6 → 200+ prompt (rehber senaryoları + her modelin örnek promptu), kategori sekmeleri ve sayfalama |
| **Trendler** | Örnek (uydurma) veri kaldırıldı; tüm grafikler gerçek veritabanından hesaplanır, JS'siz CSS çubuk grafikler |
| **SEO / GEO** | Her sayfada Hızlı Cevap, FAQPage, HowTo, SoftwareApplication (+ücretsiz teklif), BreadcrumbList, ItemList, DefinedTermSet şemaları; site araması için SearchAction; model başına otomatik OG görseli; sitemap (≈220 URL), genişletilmiş `/llms.txt` |
| **AdSense** | Yeni `multiplex` birimi, liste aralarında içerik içi birimler, sabit yükseklik rezervasyonu (CLS ≈ 0), sahte yayıncı kimliği filtresi, otomatik `/ads.txt` |
| **Performans** | three.js/GSAP yalnızca tarayıcı boştayken dinamik yüklenir; görünmezken render durur; framer-motion yükü kart/başlık bileşenlerinden kaldırıldı (CSS); büyük listelerde kademeli yükleme; `@react-three/fiber` ve `recharts` bağımlılıkları kaldırıldı |
| **Güvenlik** | HSTS, X-Frame-Options, COOP, AdSense ile uyumlu temel CSP (`frame-ancestors`, `base-uri`, `object-src`, `form-action`), arama girdisi uzunluk/karakter sınırları, karşılaştırma URL parametresi beyaz liste doğrulaması |

## Dosya hiyerarşisi (özet)

```
app/
  page.tsx                         # Sinematik 3D ana sayfa + ücretsiz/en güçlü/yeni panelleri
  ai-araclari/ · [slug]/           # Dizin + 150 model sayfası (+ opengraph-image)
  kategori/[slug]/                 # 12 kategori sıralaması
  ucretsiz-yapay-zeka/ · en-guclu-yapay-zeka/ · yeni-yapay-zeka-modelleri/
  egitimler/ · [slug]/             # Scrollytelling rehberler + temel eğitimler
  karsilastir/ · [pair]/           # Etkileşimli araç + popüler "A vs B" sayfaları
  hangi-yapay-zeka/ · ara/ · sozluk/ · trendler/ · mega-promptlar/
  araclar/token-hesaplama · kdv-hesaplama · istifa-dilekcesi-olusturucu
  search-index.json/ · compare-data.json/ · ads.txt/ · llms.txt/ · sitemap.ts · robots.ts
components/
  hero/ three/ guides/ models/ compare/ search/ tools/ icons/ ads/ seo/ geo/ layout/ ui/ content/
data/   models.json · guides.json
lib/    models.ts · guides.ts · fuzzy.ts · glossary.ts · prompts.ts · search-index.ts · compare*.ts · site.ts · legal.ts
```

## Veriyi güncellemek

- **Model eklemek/güncellemek:** `data/models.json` içine aynı alanlarla bir kayıt ekleyin. `slug` URL olur; `primaryCategory` kategori sıralamasını,
  `isNew` "Yeni" rozetini belirler. Kapanan hizmetleri silmeyin, `"status": "kapandi"` yapın (sayfa alternatiflere yönlendirir).
- **Rehber eklemek:** `data/guides.json` içine yeni bir rehber ekleyin; `mock.kind` değerleri: `browser, chat, settings, upload, voice, image, video, flow, result`.
- Veriyi güncelledikten sonra `lib/site.ts → SITE.lastReviewed` tarihini değiştirin (sitemap ve "son kontrol" etiketleri bunu kullanır).

## 2.1 — SEO, reklam ve yayın hazırlığı (Ekim 2026)

| Alan | Düzeltme / iyileştirme |
| --- | --- |
| **Kritik SEO hatası** | `robots.txt` artık `/_next/` klasörünü engellemiyor (Google CSS/JS'yi okuyamadığı için sayfaları eksik işliyordu). |
| **Meta etiketleri** | Yeni `lib/seo.ts → pageMeta()`: her sayfaya kendi canonical, og:url, og:title, twitter:title değerleri. Önceden alt sayfalar ana sayfanın og:url/twitter etiketlerini miras alıyordu. Kök layout'tan `canonical: "/"` kaldırıldı. |
| **Başlıklar** | Tüm başlıklar arama hacmi yüksek "yapay zeka" yazımıyla ve ≈60 karaktere sığacak şekilde yeniden yazıldı; model sayfalarında uzunluğa göre otomatik kısa varyant. Açıklamalar kelime ortasında kesilmiyor. |
| **Yapısal veri** | SoftwareApplication şemasında `offers` zorunlu alanı (ücretli planlar fiyatıyla), Organization için PNG logo + iletişim noktası + sameAs, yazar türü Organization, Hakkımızda/İletişim için AboutPage/ContactPage + Breadcrumb. |
| **İç linkleme / uzun kuyruk** | Karşılaştırma sayfaları 30 → **140** ("chatgpt vs gemini", "cursor vs copilot", "suno vs udio" …). Model sayfaları kendi karşılaştırma sayfalarına bağlanıyor. |
| **Doğrulama & analitik** | Google, Bing ve **Yandex** doğrulama etiketleri, isteğe bağlı GA4. |
| **Alan adı** | www / www'suz 301 yönlendirmesi, ek kısa yol yönlendirmeleri, JSON uç noktalarına `X-Robots-Tag: noindex`. |
| **PWA / simgeler** | `manifest.webmanifest`, 192/512/maskable simgeler, `apple-touch-icon.png`, `logo.png`. |
| **Reklam** | `NEXT_PUBLIC_AD_SLOT_DEFAULT` ile **tek slot kimliğiyle tüm alanlar** aktif olur. Yeni `rectangle` (300x250) ve `inFeed` birimleri; kenar çubuğuna 300x250 + yapışkan 300x600; model, ana sayfa, kategori, rehber, ücretsizler, yeniler, sözlük, prompt kütüphanesi ve model dizininde ek yerleşimler. Mobil alt panel sabit 320x100 (Better Ads standardı). Canlı modda yer tutucu yazısı artık görünmüyor. |
| **AdSense onayı** | Yasal sayfalardaki tüm `[köşeli parantez]` yer tutucuları kaldırıldı; KVKK aydınlatma metni, çerez politikası ve iletişim sayfası tamamlandı (e-posta tıklanabilir). |

## Yayına alma (adım adım)

1. **Yerelde derleyin:** `npm install && npm run build` — hata çıkmamalı. `npm start` ile http://localhost:3000 üzerinde kontrol edin.
2. **Vercel'e yükleyin** (önerilen): GitHub'a gönderin → vercel.com → "Add New Project" → depoyu seçin. Framework otomatik "Next.js" algılanır.
3. **Ortam değişkenleri** (Vercel → Settings → Environment Variables): `.env.example` dosyasındaki değerleri girin. En az:
   `NEXT_PUBLIC_SITE_URL`, `NEXT_PUBLIC_CONTACT_EMAIL`, `NEXT_PUBLIC_ADSENSE_CLIENT`, `NEXT_PUBLIC_AD_SLOT_DEFAULT`.
4. **Alan adı:** Vercel → Domains → `www.alanadiniz.com` ve `alanadiniz.com` ekleyin, birini "primary" yapın (NEXT_PUBLIC_SITE_URL ile aynı olmalı).
5. **Google Search Console:** Alan adını ekleyin → doğrulama kodunu `NEXT_PUBLIC_GOOGLE_VERIFICATION`'a girin → yeniden dağıtın →
   `https://alanadiniz.com/sitemap.xml` gönderin → ana sayfa, /ucretsiz-yapay-zeka, /en-guclu-yapay-zeka için "Dizine eklenmesini iste".
6. **Bing Webmaster Tools** (Search Console'dan içe aktarabilirsiniz) ve **Yandex Webmaster**: doğrulama kodlarını girin, site haritasını gönderin.
7. **AdSense:** Siteler → siteyi ekleyin → inceleme isteyin. Gizlilik ve mesajlaşma → **Avrupa düzenlemeleri mesajı (CMP)** oluşturun (ücretsiz, Google sertifikalı).
   Onaydan sonra Reklamlar → Reklam birimine göre → "Görüntülü reklam" oluşturun → kimliği `NEXT_PUBLIC_AD_SLOT_DEFAULT` olarak girin.
   İsterseniz "Otomatik reklamlar"ı da açın (manuel alanlarla birlikte çalışır; reklam yükünü "Reklam yükü" kaydırıcısıyla ayarlayın).
8. `/ads.txt` adresinin `google.com, pub-…, DIRECT, f08c47fec0942fa0` döndürdüğünü kontrol edin.
9. Veriyi güncelledikçe `lib/site.ts → SITE.lastReviewed` tarihini değiştirin.

## Notlar

- 3D sahne `prefers-reduced-motion`, veri tasarrufu modu veya çok zayıf cihazlarda yüklenmez; metin içeriği her durumda ilk HTML'de gelir (LCP öğesi başlıktır).
- Rehberlerdeki ekran canlandırmaları markasız, temsilî maketlerdir; gerçek arayüzün kopyası değildir.
- "Güç puanı" editoryal bir değerlendirmedir ve sayfalarda bu şekilde açıklanır.
