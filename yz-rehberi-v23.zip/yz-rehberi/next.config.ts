import type { NextConfig } from "next";

/**
 * Güvenlik başlıkları:
 *  - HSTS: yalnızca HTTPS (2 yıl, alt alan adları dahil)
 *  - CSP: AdSense ve Google Fonts ile uyumlu, kırılmayan "temel sertleştirme" politikası
 *    (frame-ancestors, base-uri, object-src, form-action). Tam bir script-src politikası AdSense'in
 *    dinamik alt alan adları nedeniyle reklamları bozabileceğinden bilinçli olarak eklenmedi.
 *  - X-Frame-Options / COOP: tıklama kaçırma (clickjacking) ve pencere ele geçirme koruması
 */
const securityHeaders = [
  { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "SAMEORIGIN" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), browsing-topics=()" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin-allow-popups" },
  {
    key: "Content-Security-Policy",
    value: ["frame-ancestors 'self'", "base-uri 'self'", "object-src 'none'", "form-action 'self'", "upgrade-insecure-requests"].join("; "),
  },
];

/**
 * Kanonik alan adı yönlendirmesi: NEXT_PUBLIC_SITE_URL "https://www.ornek.com" ise "ornek.com" → "www.ornek.com"
 * (veya tersi) 301 yönlendirilir. Aynı içeriğin iki adreste görünmesi (yinelenen içerik) SEO sinyalini böler.
 */
function hostRedirects() {
  try {
    const host = new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://www.yzrehberi.com").host;
    const alt = host.startsWith("www.") ? host.slice(4) : `www.${host}`;
    if (!host.includes(".") || host.startsWith("localhost")) return [];
    return [
      {
        source: "/:path*",
        has: [{ type: "host" as const, value: alt }],
        destination: `https://${host}/:path*`,
        permanent: true,
      },
    ];
  } catch {
    return [];
  }
}

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  images: {
    formats: ["image/avif", "image/webp"],
  },
  experimental: {
    optimizePackageImports: ["lucide-react", "framer-motion", "gsap"],
  },
  async headers() {
    return [
      { source: "/:path*", headers: securityHeaders },
      {
        // Statik JSON dizinleri uzun süre önbelleğe alınabilir
        source: "/(search-index|compare-data).json",
        headers: [
          { key: "Cache-Control", value: "public, max-age=3600, stale-while-revalidate=86400" },
          { key: "X-Robots-Tag", value: "noindex" },
        ],
      },
      {
        // Statik dosyalar (simgeler, logo) — uzun süreli önbellek
        source: "/:file(logo.png|icon-192.png|icon-512.png|icon-maskable-512.png|apple-touch-icon.png)",
        headers: [{ key: "Cache-Control", value: "public, max-age=604800, stale-while-revalidate=2592000" }],
      },
    ];
  },
  async redirects() {
    return [
      ...hostRedirects(),
      // Eski/alternatif adresler → kanonik sayfalar (SEO sinyali birleşir)
      { source: "/modeller", destination: "/ai-araclari", permanent: true },
      { source: "/ucretsiz", destination: "/ucretsiz-yapay-zeka", permanent: true },
      { source: "/en-iyi-yapay-zeka", destination: "/en-guclu-yapay-zeka", permanent: true },
      { source: "/rehberler", destination: "/egitimler", permanent: true },
      { source: "/araclar", destination: "/ai-araclari", permanent: true },
      { source: "/kategori", destination: "/ai-araclari", permanent: true },
      { source: "/sitemap", destination: "/sitemap.xml", permanent: true },
      { source: "/index.html", destination: "/", permanent: true },
    ];
  },
};

export default nextConfig;
